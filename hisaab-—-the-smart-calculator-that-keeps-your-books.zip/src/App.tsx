import React, { useState, useEffect, useRef } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import Decimal from 'decimal.js';

import {
  ShopProfile,
  UserSettings,
  SheetType,
  Transaction,
  Category,
  DailyRollup,
  PaymentMode,
} from './types/index.ts';

import {
  CalcState,
  INITIAL_CALC_STATE,
  handleCalculatorAction,
} from './engine/calcEngine.ts';
import { runAllCalculatorTests } from './engine/calcEngine.test.ts';

import {
  getProfile,
  saveProfile,
  getSettings,
  saveSettings,
  getCategories,
  saveCategory,
  initCategoriesForShop,
  getDailyRollup,
  addTransaction,
  deleteTransaction,
  restoreTransaction,
  DEFAULT_SETTINGS,
} from './db/repo.ts';

import { playCashInSound, playCashOutSound, playErrorSound, playSuccessChime } from './utils/audio.ts';
import { triggerHaptic } from './utils/haptics.ts';
import { formatMoney, getBusinessDayKeyAndHour } from './utils/formatters.ts';

import { TodayChip } from './components/calculator/TodayChip.tsx';
import { NavCapsule } from './components/calculator/NavCapsule.tsx';
import { CalcDisplay } from './components/calculator/CalcDisplay.tsx';
import { CashRow } from './components/calculator/CashRow.tsx';
import { Keypad } from './components/calculator/Keypad.tsx';
import { FlyingPill } from './components/calculator/FlyingPill.tsx';
import { Toast, ToastData } from './components/common/Toast.tsx';

import { GetStartedScreen } from './components/onboarding/GetStartedScreen.tsx';
import { SetupShopScreen } from './components/onboarding/SetupShopScreen.tsx';

import { CashOutPickerSheet } from './components/sheets/CashOutPickerSheet.tsx';
import { AnalyticsSheet } from './components/sheets/AnalyticsSheet.tsx';
import { GrowingSheet } from './components/sheets/GrowingSheet.tsx';
import { MoneyMadeSheet } from './components/sheets/MoneyMadeSheet.tsx';
import { HistorySheet } from './components/sheets/HistorySheet.tsx';
import { UdharSheet } from './components/sheets/UdharSheet.tsx';
import { CategoriesManagerSheet } from './components/sheets/CategoriesManagerSheet.tsx';
import { ReportsSheet } from './components/sheets/ReportsSheet.tsx';
import { SettingsSheet } from './components/sheets/SettingsSheet.tsx';
import { BillViewSheet } from './components/sheets/BillViewSheet.tsx';
import { UpiQrSheet } from './components/sheets/UpiQrSheet.tsx';
import { ProTipsSheet } from './components/sheets/ProTipsSheet.tsx';

export default function App() {
  // App initialization state
  const [isInitializing, setIsInitializing] = useState(true);
  const [profile, setProfile] = useState<ShopProfile | null>(null);
  const [settings, setSettings] = useState<UserSettings>(DEFAULT_SETTINGS);
  const [onboardingStep, setOnboardingStep] = useState<1 | 2 | 3>(1);

  // Calculator State
  const [calcState, setCalcState] = useState<CalcState>(INITIAL_CALC_STATE);
  const [isTypingRecently, setIsTypingRecently] = useState(false);
  const typingTimerRef = useRef<NodeJS.Timeout | null>(null);

  // Business Day Rollup for Today
  const [todayRollup, setTodayRollup] = useState<DailyRollup>({
    dayKey: new Date().toISOString().slice(0, 10),
    salesMinor: 0,
    expensesMinor: 0,
    customers: 0,
    txCount: 0,
    udharGivenMinor: 0,
    udharReceivedMinor: 0,
    byCategory: {},
    byHour: {},
    byMode: { cash: 0, upi: 0, card: 0, udhar: 0 },
  });

  // Categories
  const [categories, setCategories] = useState<Category[]>([]);

  // Navigation & Sheets
  const [activeSheet, setActiveSheet] = useState<SheetType>(null);
  const [billTargetTx, setBillTargetTx] = useState<Transaction | null>(null);
  const [historyFilterDay, setHistoryFilterDay] = useState<string | undefined>(undefined);

  // Cash In Flight Animation
  const [flyingPill, setFlyingPill] = useState<{ id: string; text: string } | null>(null);

  // Toast
  const [toast, setToast] = useState<ToastData | null>(null);

  // 4s Hold Cash In Hint
  const [showHoldHint, setShowHoldHint] = useState(false);

  // Last successful operation snapshot for one-tap Undo
  const lastOpSnapshotRef = useRef<{
    txId: string;
    prevExpression: string;
    prevResult: string;
  } | null>(null);

  // 1. Initial Load & Test Suite Execution
  useEffect(() => {
    // Run all 25+ calculator math & precedence engine tests
    const testResults = runAllCalculatorTests();
    if (testResults.failed > 0) {
      console.warn('Calculator tests had failures:', testResults.results);
    } else {
      console.log(`✓ All ${testResults.passed} calculator engine test cases passed.`);
    }

    const init = async () => {
      try {
        const storedProfile = await getProfile();
        const storedSettings = await getSettings();

        setSettings(storedSettings);

        if (storedProfile && storedProfile.onboardingDone) {
          setProfile(storedProfile);
          setOnboardingStep(3); // Go straight to Screen 3
          await refreshTodayRollup(storedSettings.dayStartMinutes);
          const cats = await initCategoriesForShop(storedProfile.businessType);
          setCategories(cats);
        } else {
          setOnboardingStep(1);
        }
      } catch (err) {
        console.error('Failed to init local database:', err);
      } finally {
        setIsInitializing(false);
      }
    };

    init();
  }, []);

  // Theme synchronization (Dark Theme Default)
  useEffect(() => {
    document.documentElement.classList.add('dark');
  }, []);

  // Keep screen awake (Wake Lock API)
  useEffect(() => {
    let wakeLock: any = null;
    if (settings.keepAwake && 'wakeLock' in navigator) {
      (navigator as any).wakeLock
        ?.request('screen')
        .then((lock: any) => {
          wakeLock = lock;
        })
        .catch(() => {});
    }
    return () => {
      if (wakeLock) wakeLock.release().catch(() => {});
    };
  }, [settings.keepAwake]);

  // Refresh Today's Rollup
  const refreshTodayRollup = async (dayStartMinutes = settings.dayStartMinutes) => {
    const { dayKey } = getBusinessDayKeyAndHour(Date.now(), dayStartMinutes);
    const rollup = await getDailyRollup(dayKey);
    setTodayRollup(rollup);
  };

  // Mark typing activity (Quiet UI dims chips for 2.5s)
  const notifyTyping = () => {
    setIsTypingRecently(true);
    if (typingTimerRef.current) clearTimeout(typingTimerRef.current);
    typingTimerRef.current = setTimeout(() => {
      setIsTypingRecently(false);
    }, 2500);
  };

  // Calculator Key Press
  const handleKeyPress = (action: string) => {
    notifyTyping();
    setCalcState((prev) => handleCalculatorAction(prev, action));
  };

  // Swipe to delete in display
  const handleSwipeDelete = () => {
    notifyTyping();
    setCalcState((prev) => handleCalculatorAction(prev, '⌫'));
  };

  // Update setting helper
  const handleUpdateSetting = async (key: keyof UserSettings, val: any) => {
    const updated = await saveSettings({ [key]: val });
    setSettings(updated);
  };

  // Check if current answer is valid for recording (> 0)
  const currentAnswerDecimal = new Decimal(calcState.result === 'Error' ? 0 : calcState.result || 0);
  const isAmountValid = !calcState.hasError && currentAnswerDecimal.greaterThan(0);
  const amountMinor = Math.round(currentAnswerDecimal.mul(100).toNumber());

  // Cash In Execution
  const handleCashIn = async (mode: PaymentMode) => {
    if (!isAmountValid) {
      playErrorSound(settings.sounds);
      triggerHaptic('error', settings.haptics);
      return;
    }

    const recordedExpr = calcState.expression || calcState.result;
    const formattedAmt = formatMoney(amountMinor, profile?.currencySymbol || '₹', 'auto', profile?.countryCode || 'IN');

    // 1. Save Transaction
    const newTx = await addTransaction({
      type: 'cash_in',
      amountMinor,
      mode,
      expr: recordedExpr,
      countsAsCustomer: true,
    });

    // 2. Play sound & trigger flight animation
    playCashInSound(settings.sounds);
    triggerHaptic('success', settings.haptics);

    setFlyingPill({
      id: `pill_${Date.now()}`,
      text: `+${formattedAmt}`,
    });

    // Save snapshot for Undo
    lastOpSnapshotRef.current = {
      txId: newTx.id,
      prevExpression: recordedExpr,
      prevResult: calcState.result,
    };

    // Reset Calculator to 0
    setCalcState(INITIAL_CALC_STATE);

    // Refresh rollups
    await refreshTodayRollup();

    // Show Toast
    setToast({
      id: `toast_${Date.now()}`,
      title: `Cash In · ${formattedAmt} recorded`,
      subtitle: `Recorded via ${mode.toUpperCase()}`,
      onUndo: () => handleUndo(),
      onBill: () => {
        setBillTargetTx(newTx);
        setActiveSheet('bill_view');
      },
    });

    // Check if we should show the hold hint (after 3rd cash in)
    if (!settings.hintsShown?.holdCashIn) {
      setShowHoldHint(true);
      setTimeout(() => setShowHoldHint(false), 4000);
      const updated = await saveSettings({
        hintsShown: { ...settings.hintsShown, holdCashIn: true },
      });
      setSettings(updated);
    }
  };

  // Cash Out Click
  const handleCashOutClick = () => {
    if (!isAmountValid) {
      playErrorSound(settings.sounds);
      triggerHaptic('error', settings.haptics);
      return;
    }
    setActiveSheet('cash_out_picker');
  };

  // Cash Out Category Selected
  const handleRecordCashOut = async (categoryId: string, note?: string) => {
    const cat = categories.find((c) => c.id === categoryId);
    const recordedExpr = calcState.expression || calcState.result;
    const formattedAmt = formatMoney(amountMinor, profile?.currencySymbol || '₹', 'auto', profile?.countryCode || 'IN');

    const newTx = await addTransaction({
      type: 'cash_out',
      amountMinor,
      mode: 'cash',
      categoryId,
      categoryName: cat?.name || 'Expense',
      note,
      expr: recordedExpr,
      countsAsCustomer: false,
    });

    playCashOutSound(settings.sounds);
    triggerHaptic('success', settings.haptics);

    // Save snapshot for Undo
    lastOpSnapshotRef.current = {
      txId: newTx.id,
      prevExpression: recordedExpr,
      prevResult: calcState.result,
    };

    // Reset Calculator
    setCalcState(INITIAL_CALC_STATE);
    await refreshTodayRollup();

    setToast({
      id: `toast_${Date.now()}`,
      title: `Cash Out · ${formattedAmt} · ${cat?.name || 'Expense'} recorded`,
      onUndo: () => handleUndo(),
    });
  };

  // Undo Last Transaction
  const handleUndo = async () => {
    if (!lastOpSnapshotRef.current) return;
    const { txId, prevExpression, prevResult } = lastOpSnapshotRef.current;

    await deleteTransaction(txId);
    triggerHaptic('success', settings.haptics);

    // Restore calculator display to previous state
    setCalcState({
      ...INITIAL_CALC_STATE,
      expression: prevExpression,
      displayExpression: prevExpression,
      currentInput: prevResult,
      result: prevResult,
    });

    await refreshTodayRollup();
    lastOpSnapshotRef.current = null;
    setToast(null);
  };

  // Onboarding Handlers
  const handleGetStarted = () => {
    setOnboardingStep(2);
  };

  const handleSetupComplete = async (newProfile: ShopProfile) => {
    await saveProfile(newProfile);
    const cats = await initCategoriesForShop(newProfile.businessType);
    setProfile(newProfile);
    setCategories(cats);
    await refreshTodayRollup();
    setOnboardingStep(3);
  };

  // Category Management Handlers
  const handleAddCategory = async (catData: Omit<Category, 'id' | 'createdAt' | 'recentAmountsMinor' | 'order' | 'archived'>) => {
    const newCat: Category = {
      ...catData,
      id: `cat_${Date.now()}_${Math.random().toString(36).substring(2, 6)}`,
      createdAt: Date.now(),
      recentAmountsMinor: [],
      order: categories.length,
      archived: false,
    };
    await saveCategory(newCat);
    const updated = await getCategories();
    setCategories(updated);
  };

  const handleArchiveCategory = async (catId: string) => {
    const cat = categories.find((c) => c.id === catId);
    if (cat) {
      await saveCategory({ ...cat, archived: true });
      const updated = await getCategories();
      setCategories(updated);
    }
  };

  if (isInitializing) {
    return (
      <div className="min-h-[100dvh] flex items-center justify-center bg-[var(--app-bg)]">
        <div className="w-10 h-10 rounded-full border-2 border-[var(--accent)] border-t-transparent animate-spin" />
      </div>
    );
  }

  // SCREEN 1: Get Started
  if (onboardingStep === 1) {
    return (
      <div className="relative min-h-[100dvh] w-full flex items-center justify-center bg-neutral-950 overflow-hidden font-sans">
        <div className="relative w-full max-w-[430px] h-[100dvh] bg-[var(--app-bg)] overflow-hidden shadow-2xl">
          <GetStartedScreen onGetStarted={handleGetStarted} />
        </div>
      </div>
    );
  }

  // SCREEN 2: Set up your shop
  if (onboardingStep === 2) {
    return (
      <div className="relative min-h-[100dvh] w-full flex items-center justify-center bg-neutral-950 font-sans">
        <div className="relative w-full max-w-[430px] h-[100dvh] max-h-[100dvh] bg-[var(--app-bg)] flex flex-col shadow-2xl overflow-hidden">
          <SetupShopScreen onComplete={handleSetupComplete} />
        </div>
      </div>
    );
  }

  // SCREEN 3: The Calculator & One-Screen Experience
  const currencySymbol = profile?.currencySymbol || '₹';
  const countryCode = profile?.countryCode || 'IN';

  const earningsToday =
    settings.chipMode === 'profit'
      ? todayRollup.salesMinor - todayRollup.expensesMinor
      : todayRollup.salesMinor;

  return (
    <div className="relative min-h-[100dvh] w-full flex items-center justify-center bg-neutral-950 overflow-hidden font-sans">
      {/* 430px Fixed Mobile Column Baseline on Desktop / Fluid on Mobile */}
      <div className="relative w-full max-w-[430px] h-[100dvh] bg-[var(--app-bg)] text-black dark:text-white flex flex-col justify-between overflow-hidden shadow-2xl">
        {/* Flying Amount Pill Animation on Cash In */}
        <FlyingPill
          pill={flyingPill}
          onAnimationComplete={() => setFlyingPill(null)}
        />

        {/* Global Action Toast */}
        <Toast toast={toast} onDismiss={() => setToast(null)} />

        {/* TOP BAR: Today Chip (Left) + Navigation Capsule (Right) */}
        <div className="w-full pt-[calc(env(safe-area-inset-top,12px)+6px)] px-4 flex items-center justify-between z-30 select-none">
          <TodayChip
            customers={todayRollup.customers}
            earningsMinor={earningsToday}
            currencySymbol={currencySymbol}
            countryCode={countryCode}
            isPrivacyBlurred={settings.hideEarnings}
            dailyGoalMinor={settings.dailyGoalMinor}
            dimmed={isTypingRecently}
            reduceMotion={settings.reduceMotion}
          />

          <NavCapsule
            onOpenSheet={(sheet) => {
              setHistoryFilterDay(undefined);
              setActiveSheet(sheet);
            }}
            dimmed={isTypingRecently}
          />
        </div>

        {/* DISPLAY: Flexible expression & large auto-fitting answer */}
        <CalcDisplay
          expression={calcState.displayExpression}
          result={calcState.result}
          hasError={calcState.hasError}
          errorMessage={calcState.errorMessage}
          currencySymbol={currencySymbol}
          countryCode={countryCode}
          onSwipeDelete={handleSwipeDelete}
          reduceMotion={settings.reduceMotion}
        />

        {/* MIDDLE ROW: Cash In (Green) & Cash Out (Red) */}
        <CashRow
          amountValid={isAmountValid}
          onCashIn={handleCashIn}
          onCashOut={handleCashOutClick}
          showHoldHint={showHoldHint}
        />

        {/* KEYPAD: 5 Rows of Apple Liquid Glass Keys */}
        <Keypad
          onKeyPress={handleKeyPress}
          pendingOperator={calcState.pendingOperator}
          enableHaptics={settings.haptics}
        />

        {/* ALL NAVIGATION & FEATURE SHEETS */}

        {/* Cash Out Category Picker Sheet */}
        <CashOutPickerSheet
          isOpen={activeSheet === 'cash_out_picker'}
          onClose={() => setActiveSheet(null)}
          amountMinor={amountMinor}
          formattedAmount={formatMoney(amountMinor, currencySymbol, 'auto', countryCode)}
          categories={categories}
          onSelectCategory={handleRecordCashOut}
          onAddNewCategory={handleAddCategory}
          onArchiveCategory={handleArchiveCategory}
        />

        {/* Analytics Sheet */}
        <AnalyticsSheet
          isOpen={activeSheet === 'analytics'}
          onClose={() => setActiveSheet(null)}
          currencySymbol={currencySymbol}
          countryCode={countryCode}
          todayRollup={todayRollup}
        />

        {/* Is My Business Growing? Sheet */}
        <GrowingSheet
          isOpen={activeSheet === 'growing'}
          onClose={() => setActiveSheet(null)}
          currencySymbol={currencySymbol}
          countryCode={countryCode}
        />

        {/* How Much Money Did I Make? Sheet */}
        <MoneyMadeSheet
          isOpen={activeSheet === 'money_made'}
          onClose={() => setActiveSheet(null)}
          currencySymbol={currencySymbol}
          countryCode={countryCode}
          profile={profile}
        />

        {/* History Sheet */}
        <HistorySheet
          isOpen={activeSheet === 'history'}
          onClose={() => setActiveSheet(null)}
          currencySymbol={currencySymbol}
          countryCode={countryCode}
          initialDayKey={historyFilterDay}
          onOpenBill={(tx) => {
            setBillTargetTx(tx);
            setActiveSheet('bill_view');
          }}
        />

        {/* Udhar Ledger Sheet */}
        <UdharSheet
          isOpen={activeSheet === 'udhar'}
          onClose={() => setActiveSheet(null)}
          currencySymbol={currencySymbol}
          countryCode={countryCode}
          profile={profile}
        />

        {/* Cash Out Options Manager Sheet */}
        <CategoriesManagerSheet
          isOpen={activeSheet === 'categories_manager'}
          onClose={() => setActiveSheet(null)}
          categories={categories}
          onAddCategory={handleAddCategory}
          onArchiveCategory={handleArchiveCategory}
          onReorderCategories={(reordered) => setCategories(reordered)}
        />

        {/* Reports & Backup Sheet */}
        <ReportsSheet
          isOpen={activeSheet === 'reports'}
          onClose={() => setActiveSheet(null)}
          currencySymbol={currencySymbol}
          countryCode={countryCode}
          onDataRestored={() => refreshTodayRollup()}
        />

        {/* Settings Sheet */}
        <SettingsSheet
          isOpen={activeSheet === 'settings'}
          onClose={() => setActiveSheet(null)}
          settings={settings}
          profile={profile}
          onSettingsUpdated={setSettings}
          onProfileUpdated={setProfile}
          onEraseAllData={() => {
            setProfile(null);
            setOnboardingStep(1);
            setCalcState(INITIAL_CALC_STATE);
          }}
          onDataRefresh={() => refreshTodayRollup()}
          onOpenProTips={() => setActiveSheet('pro_tips')}
        />

        {/* Pro Tips Sheet */}
        <ProTipsSheet
          isOpen={activeSheet === 'pro_tips'}
          onClose={() => setActiveSheet('settings')}
          currencySymbol={currencySymbol}
        />

        {/* Bill Receipt View Sheet */}
        <BillViewSheet
          isOpen={activeSheet === 'bill_view'}
          onClose={() => {
            setActiveSheet(null);
            setBillTargetTx(null);
          }}
          transaction={billTargetTx}
          profile={profile}
          currencySymbol={currencySymbol}
          countryCode={countryCode}
        />

        {/* UPI QR Sheet */}
        <UpiQrSheet
          isOpen={activeSheet === 'upi_qr'}
          onClose={() => setActiveSheet(null)}
          amountMinor={amountMinor}
          upiId={profile?.upiId}
          shopName={profile?.shopName}
          currencySymbol={currencySymbol}
          countryCode={countryCode}
          onPaymentReceived={() => handleCashIn('upi')}
        />
      </div>
    </div>
  );
}
