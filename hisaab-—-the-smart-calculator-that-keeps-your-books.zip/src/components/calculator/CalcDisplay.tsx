import React, { useRef, useState } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import { formatIndianNumber } from '../../utils/formatters.ts';
import { triggerHaptic } from '../../utils/haptics.ts';

interface CalcDisplayProps {
  expression: string;
  result: string;
  hasError: boolean;
  errorMessage: string;
  currencySymbol: string;
  countryCode: string;
  onSwipeDelete: () => void;
  reduceMotion?: boolean;
}

export const CalcDisplay: React.FC<CalcDisplayProps> = ({
  expression,
  result,
  hasError,
  errorMessage,
  currencySymbol,
  countryCode,
  onSwipeDelete,
  reduceMotion = false,
}) => {
  const [copiedPill, setCopiedPill] = useState(false);
  const [swipeOffset, setSwipeOffset] = useState(0);

  // Gesture tracking refs
  const startXRef = useRef<number | null>(null);
  const startYRef = useRef<number | null>(null);
  const longPressTimerRef = useRef<NodeJS.Timeout | null>(null);
  const isSwipingRef = useRef(false);

  // Format the result with appropriate grouping (Indian or US)
  const isIndia = countryCode === 'IN' || currencySymbol === '₹';
  const formatResultDisplay = (valStr: string) => {
    if (valStr === 'Error' || hasError) return valStr;
    const parts = valStr.split('.');
    const intPart = parseFloat(parts[0]) || 0;
    const formattedInt = isIndia
      ? formatIndianNumber(intPart)
      : intPart.toLocaleString('en-US');
    return parts.length > 1 ? `${formattedInt}.${parts[1]}` : formattedInt;
  };

  const handleStart = (clientX: number, clientY: number) => {
    startXRef.current = clientX;
    startYRef.current = clientY;
    isSwipingRef.current = false;

    // Start long-press timer for copy
    if (longPressTimerRef.current) clearTimeout(longPressTimerRef.current);
    longPressTimerRef.current = setTimeout(() => {
      if (!isSwipingRef.current && result && result !== 'Error' && !hasError) {
        handleLongPressCopy();
      }
    }, 550);
  };

  const handleMove = (clientX: number, clientY: number) => {
    if (startXRef.current === null || startYRef.current === null) return;
    const deltaX = clientX - startXRef.current;
    const deltaY = Math.abs(clientY - startYRef.current);

    // If movement is detected, cancel long-press
    if (Math.abs(deltaX) > 8 || deltaY > 8) {
      if (longPressTimerRef.current) {
        clearTimeout(longPressTimerRef.current);
        longPressTimerRef.current = null;
      }
    }

    // Provide subtle spring drag feedback when swiping horizontally
    if (Math.abs(deltaX) > 10 && deltaY < 75) {
      isSwipingRef.current = true;
      const damped = Math.sign(deltaX) * Math.min(24, Math.abs(deltaX) * 0.35);
      setSwipeOffset(damped);
    }
  };

  const handleEnd = (clientX: number, clientY: number) => {
    if (longPressTimerRef.current) {
      clearTimeout(longPressTimerRef.current);
      longPressTimerRef.current = null;
    }

    if (startXRef.current !== null && startYRef.current !== null) {
      const deltaX = clientX - startXRef.current;
      const deltaY = Math.abs(clientY - startYRef.current);

      // Natural swipe threshold: at least 22px horizontal, with relaxed vertical tolerance
      const isHorizontalSwipe =
        Math.abs(deltaX) >= 22 && (Math.abs(deltaX) > deltaY * 0.6 || deltaY < 75);

      if (isHorizontalSwipe) {
        triggerHaptic('key');
        onSwipeDelete();
      }
    }

    startXRef.current = null;
    startYRef.current = null;
    isSwipingRef.current = false;
    setSwipeOffset(0);
  };

  const handleCancel = () => {
    if (longPressTimerRef.current) {
      clearTimeout(longPressTimerRef.current);
      longPressTimerRef.current = null;
    }
    startXRef.current = null;
    startYRef.current = null;
    isSwipingRef.current = false;
    setSwipeOffset(0);
  };

  // Pointer event handlers with pointer capture
  const onPointerDown = (e: React.PointerEvent) => {
    try {
      e.currentTarget.setPointerCapture(e.pointerId);
    } catch {
      // Ignore if pointer capture is not supported
    }
    handleStart(e.clientX, e.clientY);
  };

  const onPointerMove = (e: React.PointerEvent) => {
    handleMove(e.clientX, e.clientY);
  };

  const onPointerUp = (e: React.PointerEvent) => {
    handleEnd(e.clientX, e.clientY);
  };

  // Touch event handlers for native mobile webview / Safari compatibility
  const onTouchStart = (e: React.TouchEvent) => {
    const touch = e.touches[0];
    if (touch) handleStart(touch.clientX, touch.clientY);
  };

  const onTouchMove = (e: React.TouchEvent) => {
    const touch = e.touches[0];
    if (touch) handleMove(touch.clientX, touch.clientY);
  };

  const onTouchEnd = (e: React.TouchEvent) => {
    const touch = e.changedTouches[0];
    if (touch) handleEnd(touch.clientX, touch.clientY);
    else handleCancel();
  };

  const handleLongPressCopy = () => {
    if (result && result !== 'Error' && !hasError) {
      navigator.clipboard?.writeText(result);
      triggerHaptic('success');
      setCopiedPill(true);
      setTimeout(() => setCopiedPill(false), 1600);
    }
  };

  // Determine dynamic font size based on length
  const resultLength = result.length;
  const fontSizeClass =
    resultLength > 11
      ? 'text-[38px] sm:text-[42px]'
      : resultLength > 8
      ? 'text-[50px] sm:text-[56px]'
      : 'text-[62px] sm:text-[70px]';

  return (
    <div
      onPointerDown={onPointerDown}
      onPointerMove={onPointerMove}
      onPointerUp={onPointerUp}
      onPointerCancel={handleCancel}
      onTouchStart={onTouchStart}
      onTouchMove={onTouchMove}
      onTouchEnd={onTouchEnd}
      onTouchCancel={handleCancel}
      onContextMenu={(e) => {
        e.preventDefault();
        handleLongPressCopy();
      }}
      style={{ touchAction: 'none' }}
      className="relative flex-1 min-h-[160px] flex flex-col justify-end px-6 pb-2 select-none overflow-hidden cursor-ew-resize"
      title="Swipe left or right to delete digits · Touch & hold to copy"
    >
      {/* Copied Pill Notification */}
      <AnimatePresence>
        {copiedPill && (
          <motion.div
            initial={{ opacity: 0, y: -8, scale: 0.9 }}
            animate={{ opacity: 1, y: 0, scale: 1 }}
            exit={{ opacity: 0, y: -8, scale: 0.9 }}
            className="absolute top-2 left-1/2 -translate-x-1/2 px-3 py-1 rounded-full glass-strong shadow-md text-xs font-semibold text-black dark:text-white pointer-events-none z-30"
          >
            Copied
          </motion.div>
        )}
      </AnimatePresence>

      {/* Expression Line */}
      <div className="w-full text-right overflow-hidden whitespace-nowrap text-ellipsis min-h-[32px] flex items-center justify-end pointer-events-none">
        <span className="text-[22px] sm:text-[26px] font-normal text-black/50 dark:text-white/50 tracking-tight font-mono">
          {expression}
        </span>
      </div>

      {/* Answer Line with Live Swipe Elastic Spring */}
      <motion.div
        animate={{ x: swipeOffset }}
        transition={{ type: 'spring', stiffness: 500, damping: 30 }}
        className="w-full text-right flex items-baseline justify-end gap-1.5 overflow-hidden pointer-events-none"
      >
        {hasError ? (
          <motion.div
            initial={{ x: -10 }}
            animate={{ x: [0, -8, 8, -6, 6, 0] }}
            transition={{ duration: 0.4 }}
            className="text-[28px] font-medium text-[#FF3B30] dark:text-[#FF453A]"
          >
            {errorMessage || "Can't divide by zero"}
          </motion.div>
        ) : (
          <>
            {/* Currency Symbol: 40% size, secondary color */}
            <span className="text-[26px] sm:text-[32px] font-light text-black/40 dark:text-white/40 leading-none pb-1 select-none">
              {currencySymbol}
            </span>

            {/* Answer digits with auto-fit spring and smooth entry */}
            <motion.div
              layout
              transition={{ type: 'spring', stiffness: 280, damping: 28 }}
              className={`font-light tracking-tight text-black dark:text-white tabular-nums leading-none select-none ${fontSizeClass}`}
            >
              {formatResultDisplay(result)}
            </motion.div>
          </>
        )}
      </motion.div>
    </div>
  );
};
