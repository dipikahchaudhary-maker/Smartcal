import React from 'react';
import { motion } from 'motion/react';
import { Users } from 'lucide-react';
import { Odometer } from '../common/Odometer.tsx';
import { formatTodayChipDate, formatCompactMoney } from '../../utils/formatters.ts';

interface TodayChipProps {
  customers: number;
  earningsMinor: number;
  currencySymbol: string;
  countryCode: string;
  isPrivacyBlurred: boolean;
  onTogglePrivacy?: () => void;
  onTap?: () => void;
  dailyGoalMinor?: number | null;
  dimmed?: boolean;
  reduceMotion?: boolean;
}

export const TodayChip: React.FC<TodayChipProps> = ({
  customers,
  earningsMinor,
  currencySymbol,
  countryCode,
  isPrivacyBlurred,
  dailyGoalMinor,
  dimmed = false,
  reduceMotion = false,
}) => {
  const formattedEarnings = isPrivacyBlurred
    ? '••••'
    : formatCompactMoney(earningsMinor, currencySymbol, countryCode);

  // Daily goal calculation
  const goalProgress =
    dailyGoalMinor && dailyGoalMinor > 0
      ? Math.min(1, Math.max(0, earningsMinor / dailyGoalMinor))
      : null;

  return (
    <motion.div
      animate={{ opacity: dimmed ? 0.55 : 1 }}
      transition={{ duration: 0.2 }}
      aria-label={`${customers} customers today, ${earningsMinor / 100} in earnings.`}
      className="relative h-11 px-3.5 flex flex-col justify-center rounded-2xl glass shadow-sm border border-[var(--glass-stroke)] text-left select-none max-w-[55%] min-w-[112px] cursor-default pointer-events-none"
    >
      {/* Top micro caption */}
      <span className="text-[10px] font-semibold tracking-wider text-black/50 dark:text-white/50 uppercase leading-tight truncate">
        {formatTodayChipDate()}
      </span>

      {/* Second line: customer count + hairline + earnings */}
      <div className="flex items-center gap-1.5 mt-0.5">
        {/* Customer icon with optional goal ring */}
        <div className="relative flex items-center justify-center w-4 h-4">
          {goalProgress !== null && (
            <svg className="absolute -inset-0.5 w-5 h-5 -rotate-90 pointer-events-none">
              <circle
                cx="10"
                cy="10"
                r="8"
                fill="none"
                stroke="currentColor"
                className="text-black/10 dark:text-white/10"
                strokeWidth="1.5"
              />
              <circle
                cx="10"
                cy="10"
                r="8"
                fill="none"
                stroke="#007AFF"
                strokeWidth={1.75}
                strokeDasharray="50.2"
                strokeDashoffset={50.2 * (1 - goalProgress)}
                strokeLinecap="round"
              />
            </svg>
          )}
          <Users size={12} className="text-black/70 dark:text-white/70" strokeWidth={2.2} />
        </div>

        {/* Customer count */}
        <Odometer
          value={String(customers)}
          className="text-sm font-semibold text-black dark:text-white"
          reduceMotion={reduceMotion}
        />

        {/* Hairline vertical divider */}
        <span className="w-[1px] h-3 bg-black/15 dark:bg-white/20 mx-0.5" />

        {/* Earnings */}
        <span className="text-sm font-semibold text-black dark:text-white truncate">
          {formattedEarnings}
        </span>
      </div>
    </motion.div>
  );
};
