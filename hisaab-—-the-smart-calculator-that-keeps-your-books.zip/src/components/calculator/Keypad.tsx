import React, { useEffect, useRef } from 'react';
import { motion } from 'motion/react';
import { Delete } from 'lucide-react';
import { Operator } from '../../engine/calcEngine.ts';
import { triggerHaptic } from '../../utils/haptics.ts';

interface KeypadProps {
  onKeyPress: (action: string) => void;
  pendingOperator: Operator | null;
  enableHaptics?: boolean;
}

export const Keypad: React.FC<KeypadProps> = ({
  onKeyPress,
  pendingOperator,
  enableHaptics = true,
}) => {
  const backspaceTimerRef = useRef<NodeJS.Timeout | null>(null);
  const backspaceIntervalRef = useRef<NodeJS.Timeout | null>(null);

  // Desktop keyboard event listener
  useEffect(() => {
    const handleKeyDown = (e: KeyboardEvent) => {
      // Avoid if user is in an input or textarea
      if (['INPUT', 'TEXTAREA'].includes((e.target as HTMLElement)?.tagName)) {
        return;
      }

      if (e.key >= '0' && e.key <= '9') {
        e.preventDefault();
        onKeyPress(e.key);
      } else if (e.key === '.') {
        e.preventDefault();
        onKeyPress('.');
      } else if (e.key === '+') {
        e.preventDefault();
        onKeyPress('+');
      } else if (e.key === '-') {
        e.preventDefault();
        onKeyPress('−');
      } else if (e.key === '*') {
        e.preventDefault();
        onKeyPress('×');
      } else if (e.key === '/') {
        e.preventDefault();
        onKeyPress('÷');
      } else if (e.key === '%') {
        e.preventDefault();
        onKeyPress('%');
      } else if (e.key === 'Enter' || e.key === '=') {
        e.preventDefault();
        onKeyPress('=');
      } else if (e.key === 'Backspace') {
        e.preventDefault();
        onKeyPress('⌫');
      } else if (e.key === 'Escape') {
        e.preventDefault();
        onKeyPress('AC');
      }
    };

    window.addEventListener('keydown', handleKeyDown);
    return () => window.removeEventListener('keydown', handleKeyDown);
  }, [onKeyPress]);

  const handleKeyTap = (action: string) => {
    if (enableHaptics) triggerHaptic('key');
    onKeyPress(action);
  };

  // Auto-repeating accelerating backspace
  const handleBackspaceDown = () => {
    handleKeyTap('⌫');
    let speed = 200;
    backspaceTimerRef.current = setTimeout(() => {
      backspaceIntervalRef.current = setInterval(() => {
        handleKeyTap('⌫');
        // Accelerate
        if (speed > 60) {
          speed -= 20;
        }
      }, speed);
    }, 400);
  };

  const handleBackspaceUp = () => {
    if (backspaceTimerRef.current) clearTimeout(backspaceTimerRef.current);
    if (backspaceIntervalRef.current) clearInterval(backspaceIntervalRef.current);
  };

  const rows = [
    [
      { label: 'AC', action: 'AC', type: 'fn', aria: 'All Clear' },
      { label: '⌫', action: '⌫', type: 'backspace', aria: 'Backspace' },
      { label: '%', action: '%', type: 'fn', aria: 'Percent' },
      { label: '÷', action: '÷', type: 'op', aria: 'Divide' },
    ],
    [
      { label: '7', action: '7', type: 'num', aria: 'Seven' },
      { label: '8', action: '8', type: 'num', aria: 'Eight' },
      { label: '9', action: '9', type: 'num', aria: 'Nine' },
      { label: '×', action: '×', type: 'op', aria: 'Multiply' },
    ],
    [
      { label: '4', action: '4', type: 'num', aria: 'Four' },
      { label: '5', action: '5', type: 'num', aria: 'Five' },
      { label: '6', action: '6', type: 'num', aria: 'Six' },
      { label: '−', action: '−', type: 'op', aria: 'Minus' },
    ],
    [
      { label: '1', action: '1', type: 'num', aria: 'One' },
      { label: '2', action: '2', type: 'num', aria: 'Two' },
      { label: '3', action: '3', type: 'num', aria: 'Three' },
      { label: '+', action: '+', type: 'op', aria: 'Plus' },
    ],
    [
      { label: '00', action: '00', type: 'num', aria: 'Double zero' },
      { label: '0', action: '0', type: 'num', aria: 'Zero' },
      { label: '.', action: '.', type: 'num', aria: 'Decimal point' },
      { label: '=', action: '=', type: 'equals', aria: 'Equals' },
    ],
  ];

  return (
    <div className="w-full px-4 pb-[calc(env(safe-area-inset-bottom,16px)+22px)] pt-1 select-none">
      <div className="grid grid-rows-5 gap-2.5 sm:gap-3">
        {rows.map((row, rIdx) => (
          <div key={rIdx} className="grid grid-cols-4 gap-2.5 sm:gap-3 h-[clamp(52px,7.4dvh,68px)]">
            {row.map((btn) => {
              const isPending = btn.type === 'op' && pendingOperator === btn.action;
              const isEquals = btn.type === 'equals';

              let btnClasses = '';
              let labelClasses = '';

              if (isEquals) {
                // Flat solid accent, white label
                btnClasses =
                  'bg-[#007AFF] dark:bg-[#0A84FF] text-white shadow-md active:bg-[#0062CC] border border-white/20';
                labelClasses = 'text-[34px] font-medium leading-none';
              } else if (isPending) {
                // Pending operator: solid accent with white label like iOS
                btnClasses =
                  'bg-[#007AFF] dark:bg-[#0A84FF] text-white shadow-md border border-white/20';
                labelClasses = 'text-[34px] font-medium leading-none';
              } else if (btn.type === 'op') {
                // Accent-tinted glass
                btnClasses =
                  'bg-[rgba(0,122,255,0.15)] dark:bg-[rgba(10,132,255,0.22)] border-[0.5px] border-[#007AFF]/30 text-[#007AFF] dark:text-[#0A84FF]';
                labelClasses = 'text-[34px] font-normal leading-none';
              } else if (btn.type === 'fn') {
                // AC, % : slightly stronger neutral glass
                btnClasses =
                  'glass-key-fn text-black dark:text-white font-medium hover:bg-black/5 dark:hover:bg-white/10';
                labelClasses = 'text-[24px] font-medium leading-none';
              } else if (btn.type === 'backspace') {
                btnClasses =
                  'glass-key-fn text-black dark:text-white font-medium hover:bg-black/5 dark:hover:bg-white/10';
              } else {
                // Digits: neutral glass without backdrop blur for 60fps
                btnClasses =
                  'glass-key text-black dark:text-white font-normal hover:bg-black/5 dark:hover:bg-white/10';
                labelClasses = 'text-[32px] font-normal leading-none';
              }

              if (btn.type === 'backspace') {
                return (
                  <motion.button
                    key={btn.action}
                    type="button"
                    aria-label={btn.aria}
                    whileTap={{ scale: 0.94 }}
                    transition={{ type: 'spring', stiffness: 520, damping: 34, mass: 0.9 }}
                    onPointerDown={handleBackspaceDown}
                    onPointerUp={handleBackspaceUp}
                    onPointerCancel={handleBackspaceUp}
                    className={`relative rounded-[30px] flex items-center justify-center cursor-pointer transition-colors ${btnClasses}`}
                  >
                    <Delete size={24} strokeWidth={2} />
                  </motion.button>
                );
              }

              return (
                <motion.button
                  key={btn.action}
                  type="button"
                  aria-label={btn.aria}
                  whileTap={{ scale: 0.94 }}
                  transition={{ type: 'spring', stiffness: 520, damping: 34, mass: 0.9 }}
                  onClick={() => handleKeyTap(btn.action)}
                  className={`relative rounded-[30px] flex items-center justify-center cursor-pointer transition-colors ${btnClasses}`}
                >
                  <span className={labelClasses}>{btn.label}</span>
                </motion.button>
              );
            })}
          </div>
        ))}
      </div>
    </div>
  );
};
