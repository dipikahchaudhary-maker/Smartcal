import React, { useState } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import {
  BarChart3,
  Clock,
  LayoutGrid,
  TrendingUp,
  Coins,
  CreditCard,
  Sliders,
  FileSpreadsheet,
  Settings as SettingsIcon,
  X,
} from 'lucide-react';
import { SheetType } from '../../types/index.ts';
import { triggerHaptic } from '../../utils/haptics.ts';
import { APP_NAME } from '../../constants/strings.en.ts';

interface NavCapsuleProps {
  onOpenSheet: (sheet: SheetType) => void;
  dimmed?: boolean;
}

export const NavCapsule: React.FC<NavCapsuleProps> = ({ onOpenSheet, dimmed = false }) => {
  const [isMenuOpen, setIsMenuOpen] = useState(false);

  const menuItems: Array<{
    sheet: SheetType;
    icon: any;
    title: string;
    subtitle: string;
    color: string;
    bgColor: string;
  }> = [
    {
      sheet: 'analytics',
      icon: BarChart3,
      title: 'Analytics',
      subtitle: 'Sales, expenses & customers',
      color: '#007AFF',
      bgColor: 'rgba(0, 122, 255, 0.12)',
    },
    {
      sheet: 'growing',
      icon: TrendingUp,
      title: 'Is my business growing?',
      subtitle: 'Compare with last period',
      color: '#34C759',
      bgColor: 'rgba(52, 199, 89, 0.12)',
    },
    {
      sheet: 'money_made',
      icon: Coins,
      title: 'How much money did I make?',
      subtitle: 'Revenue, expenses & profit',
      color: '#FF9500',
      bgColor: 'rgba(255, 149, 0, 0.12)',
    },
    {
      sheet: 'history',
      icon: Clock,
      title: 'History',
      subtitle: 'Every Cash In and Cash Out',
      color: '#5856D6',
      bgColor: 'rgba(88, 86, 214, 0.12)',
    },
    {
      sheet: 'udhar',
      icon: CreditCard,
      title: 'Udhar',
      subtitle: 'Who owes you money',
      color: '#30B0C7',
      bgColor: 'rgba(48, 176, 199, 0.12)',
    },
    {
      sheet: 'categories_manager',
      icon: Sliders,
      title: 'Cash Out options',
      subtitle: 'Salary, light bill, packing…',
      color: '#AF52DE',
      bgColor: 'rgba(175, 82, 222, 0.12)',
    },
    {
      sheet: 'reports',
      icon: FileSpreadsheet,
      title: 'Reports & Backup',
      subtitle: 'Export, share, restore',
      color: '#FF2D55',
      bgColor: 'rgba(255, 45, 85, 0.12)',
    },
    {
      sheet: 'settings',
      icon: SettingsIcon,
      title: 'Settings',
      subtitle: 'Profile, theme, currency',
      color: '#8E8E93',
      bgColor: 'rgba(142, 142, 147, 0.15)',
    },
  ];

  return (
    <>
      {/* Morphing Capsule */}
      <motion.div
        layoutId="nav-capsule-container"
        animate={{ opacity: dimmed && !isMenuOpen ? 0.55 : 1 }}
        transition={{ type: 'spring', stiffness: 520, damping: 34, mass: 0.9 }}
        className="relative z-30"
      >
        {!isMenuOpen ? (
          <div className="h-11 px-1.5 flex items-center gap-1 rounded-full glass shadow-sm border border-[var(--glass-stroke)]">
            {/* Analytics button */}
            <button
              type="button"
              onClick={() => {
                triggerHaptic('selection');
                onOpenSheet('analytics');
              }}
              title="Analytics"
              className="w-8 h-8 rounded-full flex items-center justify-center text-black/80 dark:text-white/80 hover:bg-black/5 dark:hover:bg-white/10 active:scale-95 transition-all cursor-pointer"
            >
              <BarChart3 size={18} strokeWidth={1.9} />
            </button>

            {/* History button */}
            <button
              type="button"
              onClick={() => {
                triggerHaptic('selection');
                onOpenSheet('history');
              }}
              title="History"
              className="w-8 h-8 rounded-full flex items-center justify-center text-black/80 dark:text-white/80 hover:bg-black/5 dark:hover:bg-white/10 active:scale-95 transition-all cursor-pointer"
            >
              <Clock size={18} strokeWidth={1.9} />
            </button>

            {/* Menu button */}
            <button
              type="button"
              onClick={() => {
                triggerHaptic('selection');
                setIsMenuOpen(true);
              }}
              title="Menu"
              className="w-8 h-8 rounded-full flex items-center justify-center text-black/80 dark:text-white/80 hover:bg-black/5 dark:hover:bg-white/10 active:scale-95 transition-all cursor-pointer"
            >
              <LayoutGrid size={18} strokeWidth={1.9} />
            </button>
          </div>
        ) : null}
      </motion.div>

      {/* Dropdown Menu Modal with Shared Layout Transition */}
      <AnimatePresence>
        {isMenuOpen && (
          <div className="fixed inset-0 z-50 flex items-start justify-end p-4 pointer-events-auto">
            {/* Dimmed backdrop */}
            <motion.div
              initial={{ opacity: 0 }}
              animate={{ opacity: 1 }}
              exit={{ opacity: 0 }}
              onClick={() => setIsMenuOpen(false)}
              className="fixed inset-0 bg-black/30 backdrop-blur-sm"
            />

            {/* Morphing Glass Panel */}
            <motion.div
              layoutId="nav-capsule-container"
              initial={{ scale: 0.95, opacity: 0, y: -10 }}
              animate={{ scale: 1, opacity: 1, y: 0 }}
              exit={{ scale: 0.95, opacity: 0, y: -10 }}
              transition={{ type: 'spring', stiffness: 450, damping: 32 }}
              className="relative w-full max-w-[320px] rounded-3xl glass-strong shadow-2xl border border-[var(--glass-stroke)] p-4 pt-3 flex flex-col z-50 mt-1 max-h-[85dvh] overflow-hidden"
            >
              {/* Header */}
              <div className="flex items-center justify-between pb-3 border-b border-[var(--separator)]">
                <span className="text-sm font-bold tracking-tight text-black dark:text-white">
                  {APP_NAME} Menu
                </span>
                <button
                  type="button"
                  onClick={() => setIsMenuOpen(false)}
                  className="w-7 h-7 rounded-full flex items-center justify-center bg-black/5 dark:bg-white/10 text-black/70 dark:text-white/70 hover:opacity-100 cursor-pointer"
                >
                  <X size={15} />
                </button>
              </div>

              {/* Items List */}
              <div className="flex-1 overflow-y-auto py-2 space-y-1 no-scrollbar">
                {menuItems.map((item, idx) => {
                  const Icon = item.icon;
                  return (
                    <motion.button
                      key={item.sheet}
                      initial={{ opacity: 0, y: 10 }}
                      animate={{ opacity: 1, y: 0 }}
                      transition={{ delay: idx * 0.025 }}
                      type="button"
                      onClick={() => {
                        triggerHaptic('selection');
                        setIsMenuOpen(false);
                        onOpenSheet(item.sheet);
                      }}
                      className="w-full flex items-center gap-3 p-2.5 rounded-2xl hover:bg-black/5 dark:hover:bg-white/5 active:scale-[0.98] transition-all text-left cursor-pointer select-none"
                    >
                      <div
                        className="w-10 h-10 rounded-xl flex items-center justify-center flex-shrink-0"
                        style={{ backgroundColor: item.bgColor, color: item.color }}
                      >
                        <Icon size={20} strokeWidth={2} />
                      </div>
                      <div className="flex-1 min-w-0">
                        <p className="text-[15px] font-semibold text-black dark:text-white truncate">
                          {item.title}
                        </p>
                        <p className="text-xs text-black/50 dark:text-white/50 truncate">
                          {item.subtitle}
                        </p>
                      </div>
                    </motion.button>
                  );
                })}
              </div>

              {/* Footer */}
              <div className="pt-2 border-t border-[var(--separator)] text-center">
                <span className="text-[11px] font-medium text-black/40 dark:text-white/40">
                  {APP_NAME} · v1.0
                </span>
              </div>
            </motion.div>
          </div>
        )}
      </AnimatePresence>
    </>
  );
};
