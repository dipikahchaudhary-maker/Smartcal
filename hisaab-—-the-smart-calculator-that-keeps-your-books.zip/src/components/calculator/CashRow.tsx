import React, { useRef, useState } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import { ArrowDownLeft, ArrowUpRight, QrCode, CreditCard, UserCheck } from 'lucide-react';
import { PaymentMode } from '../../types/index.ts';
import { triggerHaptic } from '../../utils/haptics.ts';

interface CashRowProps {
  amountValid: boolean;
  onCashIn: (mode: PaymentMode) => void;
  onCashOut: () => void;
  showHoldHint?: boolean;
}

export const CashRow: React.FC<CashRowProps> = ({
  amountValid,
  onCashIn,
  onCashOut,
  showHoldHint = false,
}) => {
  const [showModePopover, setShowModePopover] = useState(false);
  const holdTimer = useRef<NodeJS.Timeout | null>(null);
  const isLongPress = useRef(false);

  const handleCashInPointerDown = () => {
    if (!amountValid) return;
    isLongPress.current = false;
    holdTimer.current = setTimeout(() => {
      isLongPress.current = true;
      triggerHaptic('warning');
      setShowModePopover(true);
    }, 450);
  };

  const handleCashInPointerUp = () => {
    if (holdTimer.current) {
      clearTimeout(holdTimer.current);
      holdTimer.current = null;
    }
    if (!isLongPress.current && amountValid && !showModePopover) {
      triggerHaptic('key');
      onCashIn('cash');
    }
  };

  const handleModeSelect = (mode: PaymentMode) => {
    setShowModePopover(false);
    triggerHaptic('key');
    onCashIn(mode);
  };

  return (
    <div className="relative w-full px-4 my-2 z-20">
      {/* 4s Hint Pill if applicable */}
      <AnimatePresence>
        {showHoldHint && (
          <motion.div
            initial={{ opacity: 0, y: 10, scale: 0.95 }}
            animate={{ opacity: 1, y: 0, scale: 1 }}
            exit={{ opacity: 0, y: -6, scale: 0.95 }}
            className="absolute -top-10 left-6 px-3 py-1.5 rounded-full glass-strong shadow-lg text-xs font-semibold text-black dark:text-white pointer-events-none z-30"
          >
            Hold Cash In for UPI, Card or Udhar
          </motion.div>
        )}
      </AnimatePresence>

      {/* Popover for UPI / Card / Udhar */}
      <AnimatePresence>
        {showModePopover && (
          <>
            <div
              className="fixed inset-0 z-40"
              onClick={() => setShowModePopover(false)}
            />
            <motion.div
              initial={{ opacity: 0, y: 10, scale: 0.9 }}
              animate={{ opacity: 1, y: 0, scale: 1 }}
              exit={{ opacity: 0, y: 10, scale: 0.9 }}
              transition={{ type: 'spring', stiffness: 520, damping: 34 }}
              className="absolute -top-16 left-4 z-50 flex items-center gap-1.5 p-1.5 rounded-2xl glass-strong shadow-xl border border-[var(--glass-stroke)]"
            >
              <button
                type="button"
                onClick={() => handleModeSelect('upi')}
                className="flex items-center gap-1 px-3 py-2 rounded-xl bg-black/5 dark:bg-white/10 hover:bg-black/10 active:scale-95 text-xs font-semibold text-black dark:text-white cursor-pointer"
              >
                <QrCode size={14} className="text-[#007AFF]" />
                UPI
              </button>
              <button
                type="button"
                onClick={() => handleModeSelect('card')}
                className="flex items-center gap-1 px-3 py-2 rounded-xl bg-black/5 dark:bg-white/10 hover:bg-black/10 active:scale-95 text-xs font-semibold text-black dark:text-white cursor-pointer"
              >
                <CreditCard size={14} className="text-[#5856D6]" />
                Card
              </button>
              <button
                type="button"
                onClick={() => handleModeSelect('udhar')}
                className="flex items-center gap-1 px-3 py-2 rounded-xl bg-black/5 dark:bg-white/10 hover:bg-black/10 active:scale-95 text-xs font-semibold text-black dark:text-white cursor-pointer"
              >
                <UserCheck size={14} className="text-[#FF9500]" />
                Udhar
              </button>
            </motion.div>
          </>
        )}
      </AnimatePresence>

      {/* Cash In & Cash Out Row */}
      <div className="grid grid-cols-2 gap-3 h-[58px]">
        {/* Cash In Button (Green Tinted Glass) */}
        <motion.button
          type="button"
          disabled={!amountValid}
          animate={{ opacity: amountValid ? 1 : 0.4, scale: amountValid ? 1 : 0.98 }}
          whileTap={amountValid ? { scale: 0.96 } : undefined}
          transition={{ type: 'spring', stiffness: 520, damping: 34, mass: 0.9 }}
          onPointerDown={handleCashInPointerDown}
          onPointerUp={handleCashInPointerUp}
          onPointerCancel={() => {
            if (holdTimer.current) clearTimeout(holdTimer.current);
          }}
          className="relative flex items-center justify-center gap-2 rounded-full bg-[rgba(52,199,89,0.18)] dark:bg-[rgba(48,209,88,0.22)] border border-[#34C759]/40 text-[#1E8E3E] dark:text-[#30D158] select-none cursor-pointer active:brightness-110 shadow-sm disabled:cursor-not-allowed"
        >
          <ArrowDownLeft size={22} strokeWidth={2.5} />
          <span className="text-[17px] font-semibold tracking-tight">Cash In</span>
        </motion.button>

        {/* Cash Out Button (Red Tinted Glass) */}
        <motion.button
          type="button"
          disabled={!amountValid}
          animate={{ opacity: amountValid ? 1 : 0.4, scale: amountValid ? 1 : 0.98 }}
          whileTap={amountValid ? { scale: 0.96 } : undefined}
          transition={{ type: 'spring', stiffness: 520, damping: 34, mass: 0.9 }}
          onClick={() => {
            if (!amountValid) return;
            triggerHaptic('key');
            onCashOut();
          }}
          className="relative flex items-center justify-center gap-2 rounded-full bg-[rgba(255,59,48,0.18)] dark:bg-[rgba(255,69,58,0.22)] border border-[#FF3B30]/40 text-[#D70015] dark:text-[#FF453A] select-none cursor-pointer active:brightness-110 shadow-sm disabled:cursor-not-allowed"
        >
          <ArrowUpRight size={22} strokeWidth={2.5} />
          <span className="text-[17px] font-semibold tracking-tight">Cash Out</span>
        </motion.button>
      </div>
    </div>
  );
};
