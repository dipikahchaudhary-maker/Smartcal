import React from 'react';
import { motion, AnimatePresence } from 'motion/react';

interface FlyingPillProps {
  pill: { id: string; text: string } | null;
  onAnimationComplete: () => void;
}

export const FlyingPill: React.FC<FlyingPillProps> = ({ pill, onAnimationComplete }) => {
  return (
    <AnimatePresence>
      {pill && (
        <motion.div
          key={pill.id}
          initial={{
            left: '50%',
            top: '42%',
            x: '-50%',
            y: '-50%',
            scale: 1,
            opacity: 1,
          }}
          animate={{
            left: '22%',
            top: '5%',
            x: '-50%',
            y: '-50%',
            scale: 0.35,
            opacity: [1, 0.9, 0],
          }}
          transition={{
            duration: 0.52,
            ease: [0.16, 1, 0.3, 1], // ease-out curve
          }}
          onAnimationComplete={onAnimationComplete}
          className="fixed z-50 pointer-events-none px-4 py-2 rounded-full bg-[rgba(52,199,89,0.92)] text-white font-semibold text-lg shadow-xl backdrop-blur-md flex items-center justify-center border border-white/40"
        >
          {pill.text}
        </motion.div>
      )}
    </AnimatePresence>
  );
};
