import React, { useState } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import { Check, Store, ChevronRight, Sparkles } from 'lucide-react';
import { ShopProfile } from '../../types/index.ts';
import { triggerHaptic } from '../../utils/haptics.ts';
import { SUPPORTED_CURRENCIES, COUNTRY_DEFAULTS } from '../../constants/currencies.ts';

interface SetupShopScreenProps {
  onComplete: (profile: ShopProfile) => void;
}

const BUSINESS_TYPES = [
  'Grocery / Kirana',
  'General Store',
  'Restaurant / Café',
  'Bakery & Sweets',
  'Clothing & Fashion',
  'Pharmacy',
  'Electronics & Mobile',
  'Salon & Beauty',
  'Vegetables & Fruits',
  'Stationery & Books',
  'Hardware',
  'Other',
];

export const SetupShopScreen: React.FC<SetupShopScreenProps> = ({ onComplete }) => {
  const [name, setName] = useState('');
  const [age, setAge] = useState('');
  const [shopName, setShopName] = useState('');
  const [businessType, setBusinessType] = useState('Grocery / Kirana');
  const [mobile, setMobile] = useState('');
  const [country, setCountry] = useState('India');
  const [countryCode, setCountryCode] = useState('IN');
  const [stateName, setStateName] = useState('Maharashtra');
  const [city, setCity] = useState('Mumbai');
  const [currency, setCurrency] = useState('INR');
  const [currencySymbol, setCurrencySymbol] = useState('₹');
  const [address, setAddress] = useState('');
  const [upiId, setUpiId] = useState('');

  // Setting up state
  const [isSubmitting, setIsSubmitting] = useState(false);
  const [isDoneCheckmark, setIsDoneCheckmark] = useState(false);
  const [errorField, setErrorField] = useState<string | null>(null);

  const isValid =
    name.trim().length > 0 &&
    parseInt(age, 10) >= 10 &&
    parseInt(age, 10) <= 99 &&
    shopName.trim().length > 0 &&
    mobile.trim().length >= 7 &&
    country.trim().length > 0 &&
    stateName.trim().length > 0 &&
    city.trim().length > 0;

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!name.trim()) return setErrorField('name');
    const ageNum = parseInt(age, 10);
    if (isNaN(ageNum) || ageNum < 10 || ageNum > 99) return setErrorField('age');
    if (!shopName.trim()) return setErrorField('shopName');
    if (!mobile.trim()) return setErrorField('mobile');
    if (!stateName.trim()) return setErrorField('state');
    if (!city.trim()) return setErrorField('city');

    triggerHaptic('success');
    setIsSubmitting(true);

    const profile: ShopProfile = {
      name: name.trim(),
      age: ageNum,
      shopName: shopName.trim(),
      businessType,
      mobileE164: mobile.trim(),
      country,
      countryCode,
      state: stateName.trim(),
      city: city.trim(),
      currency,
      currencySymbol,
      address: address.trim() || undefined,
      upiId: upiId.trim() || undefined,
      createdAt: Date.now(),
      onboardingDone: true,
    };

    // 600ms morphing setup state
    setTimeout(() => {
      setIsDoneCheckmark(true);
      setTimeout(() => {
        onComplete(profile);
      }, 550);
    }, 600);
  };

  const handleCountryChange = (c: string) => {
    setCountry(c);
    const defaults = COUNTRY_DEFAULTS[c];
    if (defaults) {
      setCountryCode(defaults.countryCode);
      setCurrency(defaults.currency);
      setCurrencySymbol(defaults.symbol);
      setStateName(defaults.state);
      setCity(defaults.city);
    }
  };

  const handleCurrencyChange = (currCode: string) => {
    const found = SUPPORTED_CURRENCIES.find((item) => item.code === currCode);
    if (found) {
      setCurrency(found.code);
      setCurrencySymbol(found.symbol);
    }
  };

  return (
    <div className="relative h-full h-[100dvh] max-h-[100dvh] flex flex-col justify-between p-5 max-w-[430px] w-full mx-auto select-none bg-[var(--app-bg)] overflow-hidden">
      {/* Loading & Morphing Overlay */}
      <AnimatePresence>
        {isSubmitting && (
          <motion.div
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            exit={{ opacity: 0 }}
            className="fixed inset-0 z-50 flex items-center justify-center p-6 bg-black/60 backdrop-blur-md"
          >
            <motion.div
              layout
              transition={{ type: 'spring', stiffness: 400, damping: 28 }}
              className="w-full max-w-[280px] p-6 rounded-3xl glass-strong shadow-2xl flex flex-col items-center text-center space-y-3"
            >
              {!isDoneCheckmark ? (
                <>
                  <div className="w-12 h-12 rounded-full border-2 border-[var(--accent)] border-t-transparent animate-spin" />
                  <p className="text-sm font-semibold text-black dark:text-white">
                    Setting up your shop…
                  </p>
                </>
              ) : (
                <>
                  <motion.div
                    initial={{ scale: 0 }}
                    animate={{ scale: 1 }}
                    transition={{ type: 'spring', stiffness: 500, damping: 25 }}
                    className="w-12 h-12 rounded-full bg-[#34C759] text-white flex items-center justify-center shadow-lg"
                  >
                    <Check size={28} strokeWidth={3} />
                  </motion.div>
                  <p className="text-sm font-bold text-black dark:text-white">
                    Ready to keep Hisaab!
                  </p>
                </>
              )}
            </motion.div>
          </motion.div>
        )}
      </AnimatePresence>

      {/* Header (Fixed at top) */}
      <div className="pt-2 pb-2 flex-shrink-0">
        <h1 className="text-[30px] font-bold text-black dark:text-white tracking-tight leading-tight">
          Set up your shop
        </h1>
        <p className="text-[14px] text-black/60 dark:text-white/60 mt-0.5">
          Takes about 30 seconds.
        </p>
      </div>

      {/* Form Container with scrollable cards area and sticky Continue button */}
      <form onSubmit={handleSubmit} className="flex-1 flex flex-col min-h-0 overflow-hidden">
        <div
          className="flex-1 overflow-y-auto space-y-3 py-2 pr-1 overscroll-contain no-scrollbar"
          style={{ touchAction: 'pan-y', WebkitOverflowScrolling: 'touch' }}
        >
          <div className="p-4 rounded-3xl glass space-y-3">
            {/* 1. Name */}
          <div>
            <label className="text-xs text-black/60 dark:text-white/60 block mb-1">
              Your Name *
            </label>
            <input
              type="text"
              placeholder="e.g. Rahul Sharma"
              value={name}
              onChange={(e) => {
                setName(e.target.value);
                if (errorField === 'name') setErrorField(null);
              }}
              className="w-full h-11 px-3.5 rounded-xl bg-black/5 dark:bg-white/10 text-sm text-black dark:text-white font-medium focus:ring-1 focus:ring-[var(--accent)]"
            />
            {errorField === 'name' && (
              <p className="text-[12px] text-[#FF3B30] mt-1">Please enter your name</p>
            )}
          </div>

          {/* 2. Age */}
          <div>
            <label className="text-xs text-black/60 dark:text-white/60 block mb-1">
              Age (10–99) *
            </label>
            <input
              type="number"
              placeholder="e.g. 32"
              value={age}
              onChange={(e) => {
                setAge(e.target.value);
                if (errorField === 'age') setErrorField(null);
              }}
              min="10"
              max="99"
              className="w-full h-11 px-3.5 rounded-xl bg-black/5 dark:bg-white/10 text-sm text-black dark:text-white font-medium focus:ring-1 focus:ring-[var(--accent)]"
            />
            {errorField === 'age' && (
              <p className="text-[12px] text-[#FF3B30] mt-1">Please enter a valid age (10–99)</p>
            )}
          </div>

          {/* 3. Shop Name */}
          <div>
            <label className="text-xs text-black/60 dark:text-white/60 block mb-1">
              Shop Name *
            </label>
            <input
              type="text"
              placeholder="e.g. Sharma Kirana & General Store"
              value={shopName}
              onChange={(e) => {
                setShopName(e.target.value);
                if (errorField === 'shopName') setErrorField(null);
              }}
              className="w-full h-11 px-3.5 rounded-xl bg-black/5 dark:bg-white/10 text-sm text-black dark:text-white font-medium focus:ring-1 focus:ring-[var(--accent)]"
            />
            {errorField === 'shopName' && (
              <p className="text-[12px] text-[#FF3B30] mt-1">Please enter your shop name</p>
            )}
          </div>

          {/* 4. Business Type */}
          <div>
            <label className="text-xs text-black/60 dark:text-white/60 block mb-1">
              Business Type *
            </label>
            <select
              value={businessType}
              onChange={(e) => setBusinessType(e.target.value)}
              className="w-full h-11 px-3 rounded-xl bg-black/5 dark:bg-white/10 text-sm text-black dark:text-white font-medium focus:ring-1 focus:ring-[var(--accent)] outline-none cursor-pointer"
            >
              {BUSINESS_TYPES.map((bt) => (
                <option key={bt} value={bt} className="bg-white dark:bg-neutral-900 text-black dark:text-white">
                  {bt}
                </option>
              ))}
            </select>
          </div>

          {/* 5. Mobile Number */}
          <div>
            <label className="text-xs text-black/60 dark:text-white/60 block mb-1">
              Mobile Number *
            </label>
            <div className="flex gap-2">
              <span className="h-11 px-3 rounded-xl bg-black/5 dark:bg-white/10 flex items-center justify-center text-xs font-semibold text-black/60 dark:text-white/60">
                {countryCode === 'IN' ? '+91' : countryCode === 'US' || countryCode === 'CA' ? '+1' : countryCode === 'GB' ? '+44' : '+971'}
              </span>
              <input
                type="tel"
                placeholder="Mobile number"
                value={mobile}
                onChange={(e) => {
                  setMobile(e.target.value);
                  if (errorField === 'mobile') setErrorField(null);
                }}
                className="flex-1 h-11 px-3.5 rounded-xl bg-black/5 dark:bg-white/10 text-sm text-black dark:text-white font-medium focus:ring-1 focus:ring-[var(--accent)]"
              />
            </div>
            {errorField === 'mobile' && (
              <p className="text-[12px] text-[#FF3B30] mt-1">Please enter a valid mobile number</p>
            )}
          </div>
        </div>

        {/* Location & Currency Group */}
        <div className="p-4 rounded-3xl glass space-y-3">
          {/* 6. Country */}
          <div>
            <label className="text-xs text-black/60 dark:text-white/60 block mb-1">
              Country *
            </label>
            <select
              value={country}
              onChange={(e) => handleCountryChange(e.target.value)}
              className="w-full h-11 px-3 rounded-xl bg-black/5 dark:bg-white/10 text-sm text-black dark:text-white font-medium focus:ring-1 focus:ring-[var(--accent)] outline-none cursor-pointer"
            >
              <option value="India" className="bg-white dark:bg-neutral-900">🇮🇳 India</option>
              <option value="United States" className="bg-white dark:bg-neutral-900">🇺🇸 United States</option>
              <option value="Canada" className="bg-white dark:bg-neutral-900">🇨🇦 Canada</option>
              <option value="United Kingdom" className="bg-white dark:bg-neutral-900">🇬🇧 United Kingdom</option>
              <option value="United Arab Emirates" className="bg-white dark:bg-neutral-900">🇦🇪 United Arab Emirates</option>
            </select>
          </div>

          {/* 7 & 8. State and City */}
          <div className="grid grid-cols-2 gap-2">
            <div>
              <label className="text-xs text-black/60 dark:text-white/60 block mb-1">
                State / Province *
              </label>
              <input
                type="text"
                value={stateName}
                onChange={(e) => setStateName(e.target.value)}
                className="w-full h-11 px-3 rounded-xl bg-black/5 dark:bg-white/10 text-xs text-black dark:text-white font-medium"
                required
              />
            </div>
            <div>
              <label className="text-xs text-black/60 dark:text-white/60 block mb-1">
                City / Town *
              </label>
              <input
                type="text"
                value={city}
                onChange={(e) => setCity(e.target.value)}
                className="w-full h-11 px-3 rounded-xl bg-black/5 dark:bg-white/10 text-xs text-black dark:text-white font-medium"
                required
              />
            </div>
          </div>

          {/* 9. Currency (Editable with Symbol) */}
          <div>
            <label className="text-xs text-black/60 dark:text-white/60 block mb-1">
              Currency *
            </label>
            <select
              value={currency}
              onChange={(e) => handleCurrencyChange(e.target.value)}
              className="w-full h-11 px-3 rounded-xl bg-black/5 dark:bg-white/10 text-sm text-black dark:text-white font-semibold focus:ring-1 focus:ring-[var(--accent)] outline-none cursor-pointer"
            >
              {SUPPORTED_CURRENCIES.map((curr) => (
                <option
                  key={curr.code}
                  value={curr.code}
                  className="bg-white dark:bg-neutral-900 text-black dark:text-white"
                >
                  {curr.flag} {curr.code} — {curr.symbol} ({curr.name})
                </option>
              ))}
            </select>
            <span className="text-[11px] text-black/40 dark:text-white/40 block mt-1">
              Auto-filled from Country, or choose any currency.
            </span>
          </div>

          {/* 10. Shop Address */}
          <div>
            <label className="text-xs text-black/60 dark:text-white/60 block mb-1">
              Shop Address (Optional)
            </label>
            <input
              type="text"
              placeholder="e.g. Shop #4, Market Road"
              value={address}
              onChange={(e) => setAddress(e.target.value)}
              className="w-full h-11 px-3.5 rounded-xl bg-black/5 dark:bg-white/10 text-xs text-black dark:text-white"
            />
          </div>

          {/* 11. UPI ID (if India) */}
          {countryCode === 'IN' && (
            <div>
              <label className="text-xs text-black/60 dark:text-white/60 block mb-1">
                UPI ID (Optional)
              </label>
              <input
                type="text"
                placeholder="e.g. shopname@upi"
                value={upiId}
                onChange={(e) => setUpiId(e.target.value)}
                className="w-full h-11 px-3.5 rounded-xl bg-black/5 dark:bg-white/10 text-xs text-black dark:text-white font-mono"
              />
              <span className="text-[11px] text-black/40 dark:text-white/40 block mt-1">
                Used to show a payment QR. You can skip this.
              </span>
            </div>
          )}
        </div>
      </div>

      {/* Sticky Continue Button above safe area */}
      <div className="pt-3 pb-[calc(env(safe-area-inset-bottom,16px)+4px)] flex-shrink-0">
        <button
          type="submit"
          disabled={!isValid}
          className="w-full h-14 rounded-full bg-[#007AFF] dark:bg-[#0A84FF] text-white text-[17px] font-semibold flex items-center justify-center shadow-lg active:scale-98 transition-all cursor-pointer disabled:opacity-40 disabled:cursor-not-allowed"
        >
          Continue
        </button>
      </div>
    </form>
  </div>
  );
};
