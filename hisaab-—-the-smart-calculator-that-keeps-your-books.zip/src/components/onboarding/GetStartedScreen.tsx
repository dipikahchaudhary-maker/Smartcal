import React from 'react';
import { motion } from 'motion/react';
import { ArrowDownLeft, BarChart2, ShieldCheck } from 'lucide-react';
import { ThreeDMark } from '../common/ThreeDMark.tsx';
import { APP_NAME, APP_TAGLINE } from '../../constants/strings.en.ts';
import { triggerHaptic } from '../../utils/haptics.ts';

interface GetStartedScreenProps {
  onGetStarted: () => void;
}

export const GetStartedScreen: React.FC<GetStartedScreenProps> = ({ onGetStarted }) => {
  const handlePress = () => {
    triggerHaptic('key');
    onGetStarted();
  };

  const benefits = [
    {
      icon: ArrowDownLeft,
      text: 'Tap Cash In or Cash Out — we keep the hisaab.',
      color: '#34C759',
    },
    {
      icon: BarChart2,
      text: 'See sales, expenses and customers at a glance.',
      color: '#007AFF',
    },
    {
      icon: ShieldCheck,
      text: 'Private to you. Works without internet.',
      color: '#5856D6',
    },
  ];

  return (
    <div className="relative h-full h-[100dvh] flex flex-col justify-between p-6 max-w-[430px] mx-auto select-none bg-[var(--app-bg)] overflow-hidden">
      {/* Top spacing */}
      <div className="pt-8" />

      {/* Center Hero */}
      <div className="flex flex-col items-center text-center space-y-6">
        {/* Interactive 3D Apple Liquid Glass Token Mark */}
        <motion.div
          initial={{ scale: 0.9, opacity: 0 }}
          animate={{ scale: 1, opacity: 1 }}
          transition={{ type: 'spring', stiffness: 320, damping: 28 }}
        >
          <ThreeDMark size={118} interactive />
        </motion.div>

        {/* Title & Tagline */}
        <div className="space-y-2">
          <motion.h1
            initial={{ opacity: 0, y: 10 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ delay: 0.15 }}
            className="text-[34px] font-bold tracking-tight text-black dark:text-white"
          >
            {APP_NAME}
          </motion.h1>
          <motion.p
            initial={{ opacity: 0, y: 10 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ delay: 0.22 }}
            className="text-[17px] text-black/60 dark:text-white/60 font-normal max-w-[280px] leading-snug"
          >
            {APP_TAGLINE}
          </motion.p>
        </div>

        {/* Three Staggered Value Propositions */}
        <div className="w-full max-w-[320px] space-y-4 pt-4 text-left">
          {benefits.map((b, idx) => {
            const Icon = b.icon;
            return (
              <motion.div
                key={idx}
                initial={{ opacity: 0, x: -12 }}
                animate={{ opacity: 1, x: 0 }}
                transition={{ delay: 0.35 + idx * 0.1 }}
                className="flex items-center gap-3.5"
              >
                <div
                  className="w-10 h-10 rounded-2xl flex items-center justify-center flex-shrink-0"
                  style={{ backgroundColor: `${b.color}15`, color: b.color }}
                >
                  <Icon size={20} strokeWidth={2.2} />
                </div>
                <p className="text-sm text-black/80 dark:text-white/80 font-medium leading-snug">
                  {b.text}
                </p>
              </motion.div>
            );
          })}
        </div>
      </div>

      {/* Bottom Capsule CTA */}
      <motion.div
        initial={{ opacity: 0, y: 20 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ delay: 0.65 }}
        className="w-full pb-[env(safe-area-inset-bottom,16px)] pt-6 flex flex-col items-center space-y-2"
      >
        <button
          type="button"
          onClick={handlePress}
          className="w-full h-14 rounded-full bg-[#007AFF] dark:bg-[#0A84FF] text-white text-[17px] font-semibold flex items-center justify-center shadow-lg active:scale-98 transition-all cursor-pointer"
        >
          Get Started
        </button>
        <span className="text-xs text-black/40 dark:text-white/40">
          No account needed.
        </span>
      </motion.div>
    </div>
  );
};
