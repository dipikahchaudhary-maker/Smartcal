import React, { useState } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import * as LucideIcons from 'lucide-react';
import { Category } from '../../types/index.ts';
import { COLOR_OPTIONS } from '../../constants/categories.ts';
import { triggerHaptic } from '../../utils/haptics.ts';

interface CashOutPickerSheetProps {
  isOpen: boolean;
  onClose: () => void;
  amountMinor: number;
  formattedAmount: string;
  categories: Category[];
  onSelectCategory: (categoryId: string, note?: string) => void;
  onAddNewCategory: (category: Omit<Category, 'id' | 'createdAt' | 'recentAmountsMinor' | 'order' | 'archived'>) => void;
  onArchiveCategory: (id: string) => void;
}

export const CashOutPickerSheet: React.FC<CashOutPickerSheetProps> = ({
  isOpen,
  onClose,
  amountMinor,
  formattedAmount,
  categories,
  onSelectCategory,
  onAddNewCategory,
  onArchiveCategory,
}) => {
  const [isEditMode, setIsEditMode] = useState(false);
  const [noteExpanded, setNoteExpanded] = useState(false);
  const [noteText, setNoteText] = useState('');
  const [showAddModal, setShowAddModal] = useState(false);
  const [newCatName, setNewCatName] = useState('');
  const [newCatIcon, setNewCatIcon] = useState('ShoppingBag');
  const [newCatColor, setNewCatColor] = useState('teal');

  // Smart ordering:
  // Sort by matching past amount first ("Usual"), then by lastUsedAt
  const sortedCategories = [...categories].sort((a, b) => {
    const aHasUsual = (a.recentAmountsMinor || []).includes(amountMinor);
    const bHasUsual = (b.recentAmountsMinor || []).includes(amountMinor);
    if (aHasUsual && !bHasUsual) return -1;
    if (!aHasUsual && bHasUsual) return 1;
    return (b.lastUsedAt || 0) - (a.lastUsedAt || 0);
  });

  const getIconComponent = (iconName: string) => {
    const Component = (LucideIcons as any)[iconName] || LucideIcons.Folder;
    return Component;
  };

  const getColorConfig = (colorId: string) => {
    return COLOR_OPTIONS.find((c) => c.id === colorId) || COLOR_OPTIONS[0];
  };

  const handleTileClick = (cat: Category) => {
    if (isEditMode) return;
    triggerHaptic('key');
    onSelectCategory(cat.id, noteText.trim() || undefined);
    onClose();
    setNoteText('');
    setNoteExpanded(false);
  };

  const handleCreateNew = (e: React.FormEvent) => {
    e.preventDefault();
    if (!newCatName.trim()) return;
    onAddNewCategory({
      name: newCatName.trim(),
      icon: newCatIcon,
      color: newCatColor,
    });
    setNewCatName('');
    setShowAddModal(false);
  };

  return (
    <AnimatePresence>
      {isOpen && (
        <div className="fixed inset-0 z-50 flex items-end justify-center pointer-events-auto">
          {/* Dimmed backdrop */}
          <motion.div
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            exit={{ opacity: 0 }}
            onClick={onClose}
            className="fixed inset-0 bg-black/40 backdrop-blur-sm"
          />

          {/* Sheet Container (~62% height) */}
          <motion.div
            initial={{ y: '100%' }}
            animate={{ y: 0 }}
            exit={{ y: '100%' }}
            drag="y"
            dragConstraints={{ top: 0 }}
            dragElastic={0.2}
            onDragEnd={(_, info) => {
              if (info.offset.y > 100 || info.velocity.y > 400) {
                onClose();
              }
            }}
            transition={{ type: 'spring', stiffness: 300, damping: 32 }}
            className="relative w-full max-w-[430px] h-[64dvh] rounded-t-[36px] glass-strong shadow-2xl flex flex-col overflow-hidden border-t border-[var(--glass-stroke)]"
          >
            {/* Grabber */}
            <div className="w-full flex items-center justify-center pt-3 pb-1 cursor-grab">
              <div className="w-10 h-1.5 rounded-full bg-black/25 dark:bg-white/30" />
            </div>

            {/* Header */}
            <div className="flex items-center justify-between px-5 pt-2 pb-3">
              <div className="flex items-center gap-2.5">
                <span className="px-3 py-1 rounded-full bg-[rgba(255,59,48,0.18)] dark:bg-[rgba(255,69,58,0.22)] text-[#D70015] dark:text-[#FF453A] font-semibold text-sm">
                  −{formattedAmount}
                </span>
                <h2 className="text-lg font-semibold text-black dark:text-white">
                  What was this for?
                </h2>
              </div>

              <button
                type="button"
                onClick={() => {
                  triggerHaptic('selection');
                  setIsEditMode(!isEditMode);
                }}
                className="text-sm font-semibold text-[var(--accent)] hover:opacity-80 active:scale-95 transition-all cursor-pointer px-2 py-1"
              >
                {isEditMode ? 'Done' : 'Edit'}
              </button>
            </div>

            {/* Optional Collapsible Note Row */}
            <div className="px-5 pb-3">
              {!noteExpanded ? (
                <button
                  type="button"
                  onClick={() => setNoteExpanded(true)}
                  className="text-xs font-medium text-black/50 dark:text-white/50 hover:text-black dark:hover:text-white flex items-center gap-1 cursor-pointer"
                >
                  + Add a note
                </button>
              ) : (
                <div className="relative">
                  <input
                    type="text"
                    value={noteText}
                    onChange={(e) => setNoteText(e.target.value)}
                    placeholder="E.g. Electricity bill for October"
                    className="w-full h-9 px-3 text-xs rounded-xl bg-black/5 dark:bg-white/10 text-black dark:text-white placeholder-black/40 dark:placeholder-white/40 focus:outline-none focus:ring-1 focus:ring-[var(--accent)]"
                    autoFocus
                  />
                </div>
              )}
            </div>

            {/* Category Grid (3 Columns) */}
            <div className="flex-1 overflow-y-auto px-5 pb-6 no-scrollbar">
              <div className="grid grid-cols-3 gap-3">
                {sortedCategories.map((cat, idx) => {
                  const Icon = getIconComponent(cat.icon);
                  const colorConfig = getColorConfig(cat.color);
                  const isUsual = (cat.recentAmountsMinor || []).includes(amountMinor);

                  return (
                    <motion.div
                      key={cat.id}
                      animate={
                        isEditMode
                          ? {
                              rotate: idx % 2 === 0 ? [-1.2, 1.2, -1.2] : [1.2, -1.2, 1.2],
                            }
                          : { rotate: 0 }
                      }
                      transition={
                        isEditMode
                          ? { repeat: Infinity, duration: 0.24, ease: 'easeInOut' }
                          : {}
                      }
                      className="relative"
                    >
                      {/* Delete badge in edit mode */}
                      {isEditMode && (
                        <button
                          type="button"
                          onClick={() => {
                            triggerHaptic('warning');
                            onArchiveCategory(cat.id);
                          }}
                          className="absolute -top-1.5 -left-1.5 z-20 w-6 h-6 rounded-full bg-[#FF3B30] text-white flex items-center justify-center shadow-md text-xs font-bold active:scale-90"
                        >
                          −
                        </button>
                      )}

                      <button
                        type="button"
                        onClick={() => handleTileClick(cat)}
                        className="relative w-full h-[96px] rounded-[22px] glass p-2 flex flex-col items-center justify-center text-center hover:bg-black/5 dark:hover:bg-white/10 active:scale-95 transition-all cursor-pointer"
                      >
                        {/* Usual tag */}
                        {isUsual && !isEditMode && (
                          <span className="absolute top-1.5 right-1.5 px-1.5 py-0.5 rounded-full bg-[var(--accent)] text-white text-[9px] font-bold">
                            Usual
                          </span>
                        )}

                        {/* Flat muted hue icon disc */}
                        <div
                          className="w-10 h-10 rounded-full flex items-center justify-center mb-1.5"
                          style={{
                            backgroundColor: colorConfig.lightBg,
                            color: colorConfig.lightColor,
                          }}
                        >
                          <Icon size={20} strokeWidth={2} />
                        </div>

                        {/* Name (13 pt, max 2 lines) */}
                        <span className="text-[12px] sm:text-[13px] font-semibold text-black dark:text-white leading-tight line-clamp-2">
                          {cat.name}
                        </span>
                      </button>
                    </motion.div>
                  );
                })}

                {/* + New Option Tile (Dashed Outline) */}
                <button
                  type="button"
                  onClick={() => {
                    triggerHaptic('selection');
                    setShowAddModal(true);
                  }}
                  className="w-full h-[96px] rounded-[22px] border-2 border-dashed border-black/20 dark:border-white/20 hover:border-[var(--accent)] flex flex-col items-center justify-center text-center p-2 text-black/60 dark:text-white/60 hover:text-[var(--accent)] active:scale-95 transition-all cursor-pointer"
                >
                  <LucideIcons.Plus size={22} strokeWidth={2} />
                  <span className="text-[13px] font-semibold mt-1">+ New</span>
                </button>
              </div>
            </div>

            {/* Quick Add Category Modal */}
            <AnimatePresence>
              {showAddModal && (
                <div className="absolute inset-0 z-50 flex items-center justify-center p-4 bg-black/60 backdrop-blur-md">
                  <motion.div
                    initial={{ scale: 0.9, opacity: 0 }}
                    animate={{ scale: 1, opacity: 1 }}
                    exit={{ scale: 0.9, opacity: 0 }}
                    className="w-full max-w-[320px] rounded-3xl glass-strong shadow-2xl p-5 border border-[var(--glass-stroke)]"
                  >
                    <h3 className="text-base font-bold text-black dark:text-white mb-3">
                      Add New Expense Option
                    </h3>
                    <form onSubmit={handleCreateNew} className="space-y-4">
                      <input
                        type="text"
                        placeholder="Option Name (e.g. Daily Milk)"
                        value={newCatName}
                        onChange={(e) => setNewCatName(e.target.value)}
                        className="w-full h-11 px-3 text-sm rounded-xl bg-black/5 dark:bg-white/10 text-black dark:text-white placeholder-black/40 focus:outline-none focus:ring-2 focus:ring-[var(--accent)]"
                        autoFocus
                      />

                      {/* Color Selector */}
                      <div>
                        <label className="text-xs text-black/60 dark:text-white/60 block mb-1">
                          Color
                        </label>
                        <div className="flex gap-2 justify-between">
                          {COLOR_OPTIONS.slice(0, 6).map((c) => (
                            <button
                              key={c.id}
                              type="button"
                              onClick={() => setNewCatColor(c.id)}
                              className={`w-7 h-7 rounded-full flex items-center justify-center ${
                                newCatColor === c.id ? 'ring-2 ring-black dark:ring-white scale-110' : ''
                              }`}
                              style={{ backgroundColor: c.lightColor }}
                            />
                          ))}
                        </div>
                      </div>

                      <div className="flex gap-2 pt-2">
                        <button
                          type="button"
                          onClick={() => setShowAddModal(false)}
                          className="flex-1 h-10 rounded-xl bg-black/10 dark:bg-white/10 text-xs font-semibold text-black dark:text-white"
                        >
                          Cancel
                        </button>
                        <button
                          type="submit"
                          disabled={!newCatName.trim()}
                          className="flex-1 h-10 rounded-xl bg-[var(--accent)] text-white text-xs font-semibold disabled:opacity-40"
                        >
                          Add
                        </button>
                      </div>
                    </form>
                  </motion.div>
                </div>
              )}
            </AnimatePresence>
          </motion.div>
        </div>
      )}
    </AnimatePresence>
  );
};
