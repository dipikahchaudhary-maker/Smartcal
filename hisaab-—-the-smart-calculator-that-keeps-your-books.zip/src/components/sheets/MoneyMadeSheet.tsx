import React, { useState, useEffect, useRef } from 'react';
import { Share2, ChevronLeft, ChevronRight, AlertCircle } from 'lucide-react';
import { toPng } from 'html-to-image';
import { Sheet } from '../common/Sheet.tsx';
import { SegmentedControl } from '../common/SegmentedControl.tsx';
import { DailyRollup, ShopProfile, Category } from '../../types/index.ts';
import { getRollupsRange, getCategories, getUdharCustomers } from '../../db/repo.ts';
import {
  formatFullDate,
  formatMonthYear,
  formatYearOnly,
  formatMoney,
} from '../../utils/formatters.ts';
import { triggerHaptic } from '../../utils/haptics.ts';

interface MoneyMadeSheetProps {
  isOpen: boolean;
  onClose: () => void;
  currencySymbol: string;
  countryCode: string;
  profile: ShopProfile | null;
}

type Period = 'day' | 'month' | 'year';

export const MoneyMadeSheet: React.FC<MoneyMadeSheetProps> = ({
  isOpen,
  onClose,
  currencySymbol,
  countryCode,
  profile,
}) => {
  const [period, setPeriod] = useState<Period>('month');
  const [currentDate, setCurrentDate] = useState<Date>(new Date());
  const [rollups, setRollups] = useState<DailyRollup[]>([]);
  const [categories, setCategories] = useState<Category[]>([]);
  const [totalUdharPending, setTotalUdharPending] = useState(0);
  const [showAllExpenses, setShowAllExpenses] = useState(false);
  const shareCardRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    if (!isOpen) return;
    loadData();
  }, [isOpen, period, currentDate]);

  const loadData = async () => {
    const cats = await getCategories();
    setCategories(cats);

    const udhars = await getUdharCustomers();
    const pendingTotal = udhars.reduce((acc, u) => acc + (u.pendingMinor || 0), 0);
    setTotalUdharPending(pendingTotal);

    if (period === 'day') {
      const dk = currentDate.toISOString().slice(0, 10);
      const data = await getRollupsRange(dk, dk);
      setRollups(data);
    } else if (period === 'month') {
      const prefix = currentDate.toISOString().slice(0, 7);
      const data = await getRollupsRange(`${prefix}-01`, `${prefix}-31`);
      setRollups(data);
    } else {
      const yr = currentDate.toISOString().slice(0, 4);
      const data = await getRollupsRange(`${yr}-01-01`, `${yr}-12-31`);
      setRollups(data);
    }
  };

  let totalSalesMinor = 0;
  let totalExpensesMinor = 0;
  const categoryTotals: Record<string, number> = {};

  rollups.forEach((r) => {
    totalSalesMinor += r.salesMinor;
    totalExpensesMinor += r.expensesMinor;
    Object.entries(r.byCategory || {}).forEach(([catId, amt]) => {
      categoryTotals[catId] = (categoryTotals[catId] || 0) + amt;
    });
  });

  const profitMinor = totalSalesMinor - totalExpensesMinor;
  const profitMargin = totalSalesMinor > 0 ? (profitMinor / totalSalesMinor) * 100 : 0;

  const catMap = new Map(categories.map((c) => [c.id, c.name]));
  const expenseRanked = Object.entries(categoryTotals)
    .map(([catId, amt]) => ({
      name: catMap.get(catId) || 'Other',
      amountMinor: amt,
      percent: totalExpensesMinor > 0 ? (amt / totalExpensesMinor) * 100 : 0,
    }))
    .sort((a, b) => b.amountMinor - a.amountMinor);

  const displayedExpenses = showAllExpenses ? expenseRanked : expenseRanked.slice(0, 5);

  const handleShareSummary = async () => {
    triggerHaptic('success');
    if (!shareCardRef.current) return;
    try {
      const dataUrl = await toPng(shareCardRef.current, {
        quality: 0.95,
        skipFonts: true,
        cacheBust: true,
      });
      const blob = await (await fetch(dataUrl)).blob();
      const file = new File([blob], `hisaab_summary_${Date.now()}.png`, { type: 'image/png' });

      if (navigator.share && navigator.canShare && navigator.canShare({ files: [file] })) {
        await navigator.share({
          title: `${profile?.shopName || 'Hisaab'} - Business Summary`,
          files: [file],
        });
      } else {
        const link = document.createElement('a');
        link.download = `hisaab_summary_${Date.now()}.png`;
        link.href = dataUrl;
        link.click();
      }
    } catch (err) {
      console.error('Sharing failed', err);
    }
  };

  const periodLabel =
    period === 'day'
      ? formatFullDate(currentDate)
      : period === 'month'
      ? formatMonthYear(currentDate)
      : formatYearOnly(currentDate);

  return (
    <Sheet isOpen={isOpen} onClose={onClose} title="How much money did I make?">
      <div className="space-y-6 pb-12">
        <SegmentedControl<Period>
          value={period}
          onChange={setPeriod}
          options={[
            { id: 'day', label: 'Day' },
            { id: 'month', label: 'Month' },
            { id: 'year', label: 'Year' },
          ]}
        />

        {/* Date Navigator */}
        <div className="flex items-center justify-between px-2 text-sm font-semibold text-black dark:text-white">
          <button
            type="button"
            onClick={() => {
              triggerHaptic('selection');
              const next = new Date(currentDate);
              if (period === 'day') next.setDate(next.getDate() - 1);
              else if (period === 'month') next.setMonth(next.getMonth() - 1);
              else next.setFullYear(next.getFullYear() - 1);
              setCurrentDate(next);
            }}
            className="p-1 rounded-full text-black/60 dark:text-white/60 hover:bg-black/5"
          >
            <ChevronLeft size={20} />
          </button>
          <span>{periodLabel}</span>
          <button
            type="button"
            onClick={() => {
              triggerHaptic('selection');
              const next = new Date(currentDate);
              if (period === 'day') next.setDate(next.getDate() + 1);
              else if (period === 'month') next.setMonth(next.getMonth() + 1);
              else next.setFullYear(next.getFullYear() + 1);
              setCurrentDate(next);
            }}
            className="p-1 rounded-full text-black/60 dark:text-white/60 hover:bg-black/5"
          >
            <ChevronRight size={20} />
          </button>
        </div>

        {/* Hero Card: Huge Profit Number */}
        <div ref={shareCardRef} className="p-6 rounded-3xl glass text-center space-y-1">
          <span className="text-xs font-semibold tracking-wider text-black/50 dark:text-white/50 uppercase">
            {profile?.shopName ? `${profile.shopName} · ` : ''}You made
          </span>
          <h1
            className={`text-5xl font-bold tabular-nums tracking-tight ${
              profitMinor >= 0 ? 'text-[#34C759]' : 'text-[#FF3B30]'
            }`}
          >
            {formatMoney(profitMinor, currencySymbol, 'auto', countryCode)}
          </h1>
          {profitMinor < 0 && (
            <p className="text-xs text-[#FF3B30] font-medium pt-1">
              You spent more than you earned
            </p>
          )}
          <p className="text-xs text-black/50 dark:text-white/50 pt-1">
            {periodLabel}
          </p>
        </div>

        {/* Three Rows: Money In · Money Out · You Kept */}
        <div className="p-4 rounded-3xl glass divide-y divide-[var(--separator)]">
          <div className="py-2.5 flex items-center justify-between text-xs">
            <span className="text-black/60 dark:text-white/60 font-medium">Money in (Sales)</span>
            <span className="font-bold text-sm text-black dark:text-white tabular-nums">
              {formatMoney(totalSalesMinor, currencySymbol, 'auto', countryCode)}
            </span>
          </div>
          <div className="py-2.5 flex items-center justify-between text-xs">
            <span className="text-black/60 dark:text-white/60 font-medium">Money out (Expenses)</span>
            <span className="font-bold text-sm text-[#FF3B30] dark:text-[#FF453A] tabular-nums">
              {formatMoney(totalExpensesMinor, currencySymbol, 'auto', countryCode)}
            </span>
          </div>
          <div className="py-2.5 flex items-center justify-between text-xs">
            <div>
              <span className="font-bold text-sm text-black dark:text-white block">You kept (Profit)</span>
              <span className="text-[11px] text-black/50 dark:text-white/50">
                Margin: {profitMargin.toFixed(1)}%
              </span>
            </div>
            <span
              className={`font-bold text-sm tabular-nums ${
                profitMinor >= 0 ? 'text-[#34C759]' : 'text-[#FF3B30]'
              }`}
            >
              {formatMoney(profitMinor, currencySymbol, 'auto', countryCode)}
            </span>
          </div>
        </div>

        {/* Flat Split Bar: Sales into Expenses and Profit */}
        {totalSalesMinor > 0 && (
          <div className="space-y-1 px-1">
            <div className="w-full h-3 rounded-full flex overflow-hidden">
              <div
                style={{
                  width: `${Math.min(100, (totalExpensesMinor / totalSalesMinor) * 100)}%`,
                }}
                className="bg-[#FF3B30] h-full"
              />
              <div
                style={{
                  width: `${Math.max(0, (profitMinor / totalSalesMinor) * 100)}%`,
                }}
                className="bg-[#34C759] h-full"
              />
            </div>
            <div className="flex justify-between text-[11px] text-black/50 dark:text-white/50">
              <span>Expenses: {((totalExpensesMinor / totalSalesMinor) * 100).toFixed(0)}%</span>
              <span>Profit: {Math.max(0, profitMargin).toFixed(0)}%</span>
            </div>
          </div>
        )}

        {/* Where the Money Went (Top 5 / Expand) */}
        {expenseRanked.length > 0 && (
          <div className="p-4 rounded-3xl glass space-y-3">
            <div className="flex items-center justify-between">
              <h4 className="text-xs font-bold text-black/50 dark:text-white/50 tracking-wider uppercase">
                Where the money went
              </h4>
              {expenseRanked.length > 5 && (
                <button
                  type="button"
                  onClick={() => setShowAllExpenses(!showAllExpenses)}
                  className="text-xs text-[var(--accent)] font-semibold"
                >
                  {showAllExpenses ? 'Show less' : 'See all'}
                </button>
              )}
            </div>
            <div className="space-y-2">
              {displayedExpenses.map((e) => (
                <div key={e.name} className="flex justify-between text-xs py-1">
                  <span className="font-medium text-black dark:text-white">{e.name}</span>
                  <span className="tabular-nums font-semibold text-black/80 dark:text-white/80">
                    {formatMoney(e.amountMinor, currencySymbol, 'auto', countryCode)}
                  </span>
                </div>
              ))}
            </div>
          </div>
        )}

        {/* Note when relevant: Udhar pending */}
        {totalUdharPending > 0 && (
          <div className="flex items-center gap-2 p-3.5 rounded-2xl bg-[#007AFF]/10 text-xs font-medium text-[#007AFF]">
            <AlertCircle size={16} />
            <span>
              {formatMoney(totalUdharPending, currencySymbol, 'auto', countryCode)} is still pending in Udhar.
            </span>
          </div>
        )}

        {/* Share Summary Button */}
        <div className="pt-2">
          <button
            type="button"
            onClick={handleShareSummary}
            className="w-full h-12 rounded-2xl bg-[var(--accent)] text-white font-semibold flex items-center justify-center gap-2 active:scale-95 transition-all cursor-pointer shadow-md"
          >
            <Share2 size={18} />
            Share Summary
          </button>
        </div>
      </div>
    </Sheet>
  );
};
