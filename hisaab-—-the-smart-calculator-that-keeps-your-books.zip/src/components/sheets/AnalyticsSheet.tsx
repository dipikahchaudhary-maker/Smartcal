import React, { useState, useEffect } from 'react';
import { motion } from 'motion/react';
import {
  LineChart,
  Line,
  BarChart,
  Bar,
  PieChart,
  Pie,
  Cell,
  XAxis,
  YAxis,
  Tooltip,
  ResponsiveContainer,
} from 'recharts';
import {
  ChevronLeft,
  ChevronRight,
  TrendingUp,
  TrendingDown,
  DollarSign,
  Users,
  CreditCard,
  Download,
} from 'lucide-react';
import { Sheet } from '../common/Sheet.tsx';
import { SegmentedControl } from '../common/SegmentedControl.tsx';
import { DailyRollup, Category } from '../../types/index.ts';
import { getRollupsRange, getCategories } from '../../db/repo.ts';
import {
  formatFullDate,
  formatMonthYear,
  formatYearOnly,
  formatMoney,
  formatCompactMoney,
} from '../../utils/formatters.ts';
import { triggerHaptic } from '../../utils/haptics.ts';

interface AnalyticsSheetProps {
  isOpen: boolean;
  onClose: () => void;
  currencySymbol: string;
  countryCode: string;
  todayRollup: DailyRollup;
}

type Period = 'daily' | 'monthly' | 'yearly';

export const AnalyticsSheet: React.FC<AnalyticsSheetProps> = ({
  isOpen,
  onClose,
  currencySymbol,
  countryCode,
  todayRollup,
}) => {
  const [period, setPeriod] = useState<Period>('daily');
  const [currentDate, setCurrentDate] = useState<Date>(new Date());
  const [compareEnabled, setCompareEnabled] = useState(false);
  const [rollups, setRollups] = useState<DailyRollup[]>([]);
  const [prevRollups, setPrevRollups] = useState<DailyRollup[]>([]);
  const [categories, setCategories] = useState<Category[]>([]);
  const [snapshotData, setSnapshotData] = useState<{
    today: { customers: number; sales: number };
    month: { customers: number; sales: number };
    year: { customers: number; sales: number };
  }>({
    today: { customers: 0, sales: 0 },
    month: { customers: 0, sales: 0 },
    year: { customers: 0, sales: 0 },
  });

  useEffect(() => {
    if (!isOpen) return;
    loadCategoriesAndSnapshot();
    loadPeriodData();
  }, [isOpen, period, currentDate, compareEnabled]);

  const loadCategoriesAndSnapshot = async () => {
    const cats = await getCategories();
    setCategories(cats);

    // Load Snapshot data
    const now = new Date();
    const todayKey = now.toISOString().slice(0, 10);
    const monthPrefix = todayKey.slice(0, 7);
    const yearPrefix = todayKey.slice(0, 4);

    const monthRollups = await getRollupsRange(`${monthPrefix}-01`, `${monthPrefix}-31`);
    const yearRollups = await getRollupsRange(`${yearPrefix}-01-01`, `${yearPrefix}-12-31`);

    let mSales = 0, mCust = 0;
    monthRollups.forEach((r) => {
      mSales += r.salesMinor;
      mCust += r.customers;
    });

    let ySales = 0, yCust = 0;
    yearRollups.forEach((r) => {
      ySales += r.salesMinor;
      yCust += r.customers;
    });

    setSnapshotData({
      today: { customers: todayRollup.customers, sales: todayRollup.salesMinor },
      month: { customers: mCust, sales: mSales },
      year: { customers: yCust, sales: ySales },
    });
  };

  const loadPeriodData = async () => {
    if (period === 'daily') {
      const dayKey = currentDate.toISOString().slice(0, 10);
      const data = await getRollupsRange(dayKey, dayKey);
      setRollups(data);

      if (compareEnabled) {
        const prev = new Date(currentDate);
        prev.setDate(prev.getDate() - 1);
        const prevKey = prev.toISOString().slice(0, 10);
        const pData = await getRollupsRange(prevKey, prevKey);
        setPrevRollups(pData);
      }
    } else if (period === 'monthly') {
      const monthPrefix = currentDate.toISOString().slice(0, 7);
      const data = await getRollupsRange(`${monthPrefix}-01`, `${monthPrefix}-31`);
      setRollups(data);

      if (compareEnabled) {
        const prev = new Date(currentDate);
        prev.setMonth(prev.getMonth() - 1);
        const prevPrefix = prev.toISOString().slice(0, 7);
        const pData = await getRollupsRange(`${prevPrefix}-01`, `${prevPrefix}-31`);
        setPrevRollups(pData);
      }
    } else {
      const yearPrefix = currentDate.toISOString().slice(0, 4);
      const data = await getRollupsRange(`${yearPrefix}-01-01`, `${yearPrefix}-12-31`);
      setRollups(data);

      if (compareEnabled) {
        const prev = new Date(currentDate);
        prev.setFullYear(prev.getFullYear() - 1);
        const prevYear = prev.toISOString().slice(0, 4);
        const pData = await getRollupsRange(`${prevYear}-01-01`, `${prevYear}-12-31`);
        setPrevRollups(pData);
      }
    }
  };

  const handlePrevDate = () => {
    triggerHaptic('selection');
    const next = new Date(currentDate);
    if (period === 'daily') next.setDate(next.getDate() - 1);
    else if (period === 'monthly') next.setMonth(next.getMonth() - 1);
    else next.setFullYear(next.getFullYear() - 1);
    setCurrentDate(next);
  };

  const handleNextDate = () => {
    triggerHaptic('selection');
    const next = new Date(currentDate);
    if (period === 'daily') next.setDate(next.getDate() + 1);
    else if (period === 'monthly') next.setMonth(next.getMonth() + 1);
    else next.setFullYear(next.getFullYear() + 1);
    setCurrentDate(next);
  };

  // Aggregated KPIs
  let totalSalesMinor = 0;
  let totalExpensesMinor = 0;
  let totalCustomers = 0;
  const categoryTotals: Record<string, number> = {};
  const modeTotals = { cash: 0, upi: 0, card: 0, udhar: 0 };

  rollups.forEach((r) => {
    totalSalesMinor += r.salesMinor;
    totalExpensesMinor += r.expensesMinor;
    totalCustomers += r.customers;
    Object.entries(r.byCategory || {}).forEach(([catId, amt]) => {
      categoryTotals[catId] = (categoryTotals[catId] || 0) + amt;
    });
    if (r.byMode) {
      modeTotals.cash += r.byMode.cash || 0;
      modeTotals.upi += r.byMode.upi || 0;
      modeTotals.card += r.byMode.card || 0;
      modeTotals.udhar += r.byMode.udhar || 0;
    }
  });

  const netProfitMinor = totalSalesMinor - totalExpensesMinor;
  const avgBillMinor = totalCustomers > 0 ? Math.round(totalSalesMinor / totalCustomers) : 0;

  // Comparison totals
  let prevSalesMinor = 0;
  let prevExpensesMinor = 0;
  let prevCustomers = 0;
  prevRollups.forEach((r) => {
    prevSalesMinor += r.salesMinor;
    prevExpensesMinor += r.expensesMinor;
    prevCustomers += r.customers;
  });

  const calcChangePercent = (current: number, prev: number) => {
    if (prev === 0) return 'New';
    const pct = ((current - prev) / Math.abs(prev)) * 100;
    return `${pct > 0 ? '+' : ''}${pct.toFixed(1)}%`;
  };

  // Build chart points
  let chartData: any[] = [];
  if (period === 'daily') {
    const single = rollups[0];
    const prevSingle = prevRollups[0];
    for (let h = 8; h <= 22; h++) {
      const sales = (single?.byHour?.[h]?.salesMinor || 0) / 100;
      const prevSales = (prevSingle?.byHour?.[h]?.salesMinor || 0) / 100;
      const cust = single?.byHour?.[h]?.customers || 0;
      chartData.push({
        label: `${h > 12 ? h - 12 : h}${h >= 12 ? 'pm' : 'am'}`,
        sales,
        prevSales,
        expenses: 0,
        customers: cust,
      });
    }
  } else if (period === 'monthly') {
    const daysInMonth = new Date(currentDate.getFullYear(), currentDate.getMonth() + 1, 0).getDate();
    const map = new Map(rollups.map((r) => [parseInt(r.dayKey.slice(8, 10), 10), r]));
    for (let d = 1; d <= daysInMonth; d++) {
      const r = map.get(d);
      chartData.push({
        label: String(d),
        sales: (r?.salesMinor || 0) / 100,
        expenses: (r?.expensesMinor || 0) / 100,
        customers: r?.customers || 0,
      });
    }
  } else {
    // Yearly
    const months = ['Jan', 'Feb', 'Mar', 'Apr', 'May', 'Jun', 'Jul', 'Aug', 'Sep', 'Oct', 'Nov', 'Dec'];
    const monthlySales: Record<number, number> = {};
    const monthlyExpenses: Record<number, number> = {};
    const monthlyCust: Record<number, number> = {};

    rollups.forEach((r) => {
      const m = parseInt(r.dayKey.slice(5, 7), 10) - 1;
      monthlySales[m] = (monthlySales[m] || 0) + r.salesMinor / 100;
      monthlyExpenses[m] = (monthlyExpenses[m] || 0) + r.expensesMinor / 100;
      monthlyCust[m] = (monthlyCust[m] || 0) + r.customers;
    });

    chartData = months.map((m, idx) => ({
      label: m,
      sales: monthlySales[idx] || 0,
      expenses: monthlyExpenses[idx] || 0,
      customers: monthlyCust[idx] || 0,
    }));
  }

  // Expense Donut & Ranking
  const donutColors = ['#5856D6', '#30B0C7', '#AF52DE', '#FF9500', '#FF2D55', '#E5B800', '#00B5AD', '#007AFF'];
  const catNameMap = new Map(categories.map((c) => [c.id, c.name]));
  const expenseRanked = Object.entries(categoryTotals)
    .map(([catId, amt]) => ({
      name: catNameMap.get(catId) || 'Other',
      amountMinor: amt,
      percent: totalExpensesMinor > 0 ? (amt / totalExpensesMinor) * 100 : 0,
    }))
    .sort((a, b) => b.amountMinor - a.amountMinor);

  // Export CSV
  const handleExportCsv = () => {
    let csv = 'Day,Sales,Expenses,Customers,Transactions\n';
    rollups.forEach((r) => {
      csv += `${r.dayKey},${r.salesMinor / 100},${r.expensesMinor / 100},${r.customers},${r.txCount}\n`;
    });
    const blob = new Blob([csv], { type: 'text/csv;charset=utf-8;' });
    const url = URL.createObjectURL(blob);
    const link = document.createElement('a');
    link.setAttribute('href', url);
    link.setAttribute('download', `hisaab_analytics_${period}_${Date.now()}.csv`);
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);
  };

  const periodLabel =
    period === 'daily'
      ? formatFullDate(currentDate)
      : period === 'monthly'
      ? formatMonthYear(currentDate)
      : formatYearOnly(currentDate);

  return (
    <Sheet isOpen={isOpen} onClose={onClose} title="Analytics">
      <div className="space-y-6 pb-12">
        {/* Segmented Control */}
        <SegmentedControl<Period>
          value={period}
          onChange={setPeriod}
          options={[
            { id: 'daily', label: 'Daily' },
            { id: 'monthly', label: 'Monthly' },
            { id: 'yearly', label: 'Yearly' },
          ]}
        />

        {/* Date Navigator + Compare Toggle */}
        <div className="flex items-center justify-between px-1">
          <div className="flex items-center gap-2">
            <button
              type="button"
              onClick={handlePrevDate}
              className="p-1 rounded-full text-black/60 dark:text-white/60 hover:bg-black/5 dark:hover:bg-white/10"
            >
              <ChevronLeft size={20} />
            </button>
            <span className="text-sm font-semibold text-black dark:text-white">
              {periodLabel}
            </span>
            <button
              type="button"
              onClick={handleNextDate}
              className="p-1 rounded-full text-black/60 dark:text-white/60 hover:bg-black/5 dark:hover:bg-white/10"
            >
              <ChevronRight size={20} />
            </button>
          </div>

          <label className="flex items-center gap-1.5 text-xs text-black/60 dark:text-white/60 cursor-pointer">
            <input
              type="checkbox"
              checked={compareEnabled}
              onChange={(e) => setCompareEnabled(e.target.checked)}
              className="rounded text-[var(--accent)]"
            />
            Compare
          </label>
        </div>

        {/* Snapshot Card (Always visible, independent of selection) */}
        <div className="p-4 rounded-3xl glass space-y-3">
          <h4 className="text-xs font-bold text-black/50 dark:text-white/50 tracking-wider uppercase">
            Snapshot
          </h4>
          <div className="divide-y divide-[var(--separator)]">
            <div className="flex justify-between py-2 text-xs">
              <span className="text-black/60 dark:text-white/60">Today · {formatFullDate(new Date())}</span>
              <span className="font-semibold text-black dark:text-white tabular-nums">
                {snapshotData.today.customers} customers · {formatMoney(snapshotData.today.sales, currencySymbol, 'auto', countryCode)}
              </span>
            </div>
            <div className="flex justify-between py-2 text-xs">
              <span className="text-black/60 dark:text-white/60">This month · {formatMonthYear(new Date())}</span>
              <span className="font-semibold text-black dark:text-white tabular-nums">
                {snapshotData.month.customers} customers · {formatMoney(snapshotData.month.sales, currencySymbol, 'auto', countryCode)}
              </span>
            </div>
            <div className="flex justify-between py-2 text-xs">
              <span className="text-black/60 dark:text-white/60">This year · {formatYearOnly(new Date())}</span>
              <span className="font-semibold text-black dark:text-white tabular-nums">
                {snapshotData.year.customers} customers · {formatMoney(snapshotData.year.sales, currencySymbol, 'auto', countryCode)}
              </span>
            </div>
          </div>
        </div>

        {/* KPI Snap Carousel */}
        <div className="flex gap-3 overflow-x-auto pb-2 snap-x no-scrollbar">
          {/* Sales Card */}
          <div className="min-w-[145px] flex-1 p-4 rounded-3xl glass snap-center">
            <span className="text-xs text-black/50 dark:text-white/50 font-medium">Sales</span>
            <p className="text-xl font-bold text-black dark:text-white tabular-nums mt-1">
              {formatMoney(totalSalesMinor, currencySymbol, 'auto', countryCode)}
            </p>
            {compareEnabled && (
              <span className="text-[11px] font-semibold text-[#34C759] mt-1 inline-block">
                {calcChangePercent(totalSalesMinor, prevSalesMinor)} vs prev
              </span>
            )}
          </div>

          {/* Expenses Card */}
          <div className="min-w-[145px] flex-1 p-4 rounded-3xl glass snap-center">
            <span className="text-xs text-black/50 dark:text-white/50 font-medium">Expenses</span>
            <p className="text-xl font-bold text-[#FF3B30] dark:text-[#FF453A] tabular-nums mt-1">
              {formatMoney(totalExpensesMinor, currencySymbol, 'auto', countryCode)}
            </p>
            {compareEnabled && (
              <span className="text-[11px] font-semibold text-black/50 dark:text-white/50 mt-1 inline-block">
                {calcChangePercent(totalExpensesMinor, prevExpensesMinor)}
              </span>
            )}
          </div>

          {/* Customers Card */}
          <div className="min-w-[130px] flex-1 p-4 rounded-3xl glass snap-center">
            <span className="text-xs text-black/50 dark:text-white/50 font-medium">Customers</span>
            <p className="text-xl font-bold text-black dark:text-white tabular-nums mt-1">
              {totalCustomers}
            </p>
            {compareEnabled && (
              <span className="text-[11px] font-semibold text-[#007AFF] mt-1 inline-block">
                {calcChangePercent(totalCustomers, prevCustomers)}
              </span>
            )}
          </div>

          {/* Profit Card */}
          <div className="min-w-[140px] flex-1 p-4 rounded-3xl glass snap-center">
            <span className="text-xs text-black/50 dark:text-white/50 font-medium">Profit</span>
            <p
              className={`text-xl font-bold tabular-nums mt-1 ${
                netProfitMinor >= 0 ? 'text-[#34C759]' : 'text-[#FF3B30]'
              }`}
            >
              {formatMoney(netProfitMinor, currencySymbol, 'auto', countryCode)}
            </p>
          </div>
        </div>

        {/* Sales vs Expenses Monotone Curves Chart with 3D Depth-Plane Lift */}
        <div className="p-4 rounded-3xl glass space-y-2 overflow-hidden" style={{ perspective: '1100px' }}>
          <div className="flex items-center justify-between">
            <h4 className="text-xs font-bold text-black/50 dark:text-white/50 tracking-wider uppercase">
              Sales vs Expenses
            </h4>
            <span className="text-[10px] text-black/40 dark:text-white/40 font-medium">
              3D Depth Lift
            </span>
          </div>
          <motion.div
            key={`line-3d-stage-${period}-${currentDate.toISOString()}-${compareEnabled}`}
            initial={{
              opacity: 0,
              transform: 'perspective(1100px) rotateX(16deg) translateZ(-85px) translateY(24px) scale(0.96)',
            }}
            animate={{
              opacity: 1,
              transform: 'perspective(1100px) rotateX(0deg) translateZ(0px) translateY(0px) scale(1)',
            }}
            transition={{
              type: 'spring',
              stiffness: 280,
              damping: 26,
              mass: 0.9,
            }}
            style={{ transformStyle: 'preserve-3d' }}
            className="h-48 w-full pt-2"
          >
            <ResponsiveContainer width="100%" height="100%">
              <LineChart data={chartData}>
                <XAxis dataKey="label" stroke="#8E8E93" fontSize={10} tickLine={false} />
                <YAxis stroke="#8E8E93" fontSize={10} tickLine={false} axisLine={false} />
                <Tooltip
                  contentStyle={{
                    backgroundColor: 'rgba(255,255,255,0.85)',
                    backdropFilter: 'blur(16px)',
                    borderRadius: 16,
                    border: '0.5px solid rgba(255,255,255,0.5)',
                    boxShadow: '0 4px 16px rgba(0,0,0,0.1)',
                  }}
                />
                <Line
                  type="monotone"
                  dataKey="sales"
                  stroke="#34C759"
                  strokeWidth={2.5}
                  dot={false}
                  isAnimationActive={true}
                  animationDuration={850}
                  animationEasing="ease-out"
                />
                <Line
                  type="monotone"
                  dataKey="expenses"
                  stroke="#FF3B30"
                  strokeWidth={2}
                  dot={false}
                  isAnimationActive={true}
                  animationDuration={850}
                  animationEasing="ease-out"
                />
                {compareEnabled && (
                  <Line
                    type="monotone"
                    dataKey="prevSales"
                    stroke="#8E8E93"
                    strokeWidth={1.5}
                    strokeDasharray="4 4"
                    dot={false}
                    isAnimationActive={true}
                    animationDuration={850}
                    animationEasing="ease-out"
                  />
                )}
              </LineChart>
            </ResponsiveContainer>
          </motion.div>
        </div>

        {/* Customers Blue Bar Chart with 3D Depth-Plane Lift and Custom Animated Bars */}
        <div className="p-4 rounded-3xl glass space-y-2 overflow-hidden" style={{ perspective: '1100px' }}>
          <div className="flex items-center justify-between">
            <h4 className="text-xs font-bold text-black/50 dark:text-white/50 tracking-wider uppercase">
              Number of Persons Who Bought
            </h4>
            <span className="text-[10px] text-black/40 dark:text-white/40 font-medium">
              Z-Axis Spring
            </span>
          </div>
          <motion.div
            key={`bar-3d-stage-${period}-${currentDate.toISOString()}`}
            initial={{
              opacity: 0,
              transform: 'perspective(1100px) rotateX(20deg) translateZ(-95px) translateY(28px) scale(0.95)',
            }}
            animate={{
              opacity: 1,
              transform: 'perspective(1100px) rotateX(0deg) translateZ(0px) translateY(0px) scale(1)',
            }}
            transition={{
              type: 'spring',
              stiffness: 280,
              damping: 26,
              mass: 0.9,
              delay: 0.05,
            }}
            style={{ transformStyle: 'preserve-3d' }}
            className="h-36 w-full pt-2"
          >
            <ResponsiveContainer width="100%" height="100%">
              <BarChart data={chartData}>
                <XAxis dataKey="label" stroke="#8E8E93" fontSize={10} tickLine={false} />
                <YAxis stroke="#8E8E93" fontSize={10} tickLine={false} axisLine={false} />
                <Tooltip
                  contentStyle={{
                    backgroundColor: 'rgba(255,255,255,0.85)',
                    borderRadius: 14,
                  }}
                />
                <Bar
                  dataKey="customers"
                  fill="#007AFF"
                  radius={[6, 6, 0, 0]}
                  isAnimationActive={true}
                  animationDuration={750}
                  animationEasing="ease-out"
                />
              </BarChart>
            </ResponsiveContainer>
          </motion.div>
        </div>

        {/* Where the money went: Expense Ranking */}
        {expenseRanked.length > 0 && (
          <div className="p-4 rounded-3xl glass space-y-3">
            <h4 className="text-xs font-bold text-black/50 dark:text-white/50 tracking-wider uppercase">
              Where the money went
            </h4>
            <div className="space-y-2.5">
              {expenseRanked.map((exp, idx) => (
                <div key={exp.name} className="space-y-1">
                  <div className="flex justify-between text-xs">
                    <span className="font-semibold text-black dark:text-white">{exp.name}</span>
                    <span className="tabular-nums text-black/70 dark:text-white/70">
                      {formatMoney(exp.amountMinor, currencySymbol, 'auto', countryCode)} ({exp.percent.toFixed(0)}%)
                    </span>
                  </div>
                  <div className="w-full h-1.5 rounded-full bg-black/5 dark:bg-white/10 overflow-hidden">
                    <div
                      className="h-full rounded-full"
                      style={{
                        width: `${exp.percent}%`,
                        backgroundColor: donutColors[idx % donutColors.length],
                      }}
                    />
                  </div>
                </div>
              ))}
            </div>
          </div>
        )}

        {/* Payment Methods Stacked Breakdown */}
        <div className="p-4 rounded-3xl glass space-y-3">
          <h4 className="text-xs font-bold text-black/50 dark:text-white/50 tracking-wider uppercase">
            Payment Methods
          </h4>
          {totalSalesMinor > 0 ? (
            <div className="space-y-2">
              <div className="w-full h-3 rounded-full flex overflow-hidden">
                <div
                  style={{ width: `${(modeTotals.cash / totalSalesMinor) * 100}%` }}
                  className="bg-[#34C759] h-full"
                />
                <div
                  style={{ width: `${(modeTotals.upi / totalSalesMinor) * 100}%` }}
                  className="bg-[#007AFF] h-full"
                />
                <div
                  style={{ width: `${(modeTotals.card / totalSalesMinor) * 100}%` }}
                  className="bg-[#5856D6] h-full"
                />
                <div
                  style={{ width: `${(modeTotals.udhar / totalSalesMinor) * 100}%` }}
                  className="bg-[#FF9500] h-full"
                />
              </div>

              <div className="flex justify-between text-[11px] text-black/60 dark:text-white/60 pt-1">
                <span className="flex items-center gap-1">
                  <span className="w-2 h-2 rounded-full bg-[#34C759]" /> Cash
                </span>
                <span className="flex items-center gap-1">
                  <span className="w-2 h-2 rounded-full bg-[#007AFF]" /> UPI
                </span>
                <span className="flex items-center gap-1">
                  <span className="w-2 h-2 rounded-full bg-[#5856D6]" /> Card
                </span>
                <span className="flex items-center gap-1">
                  <span className="w-2 h-2 rounded-full bg-[#FF9500]" /> Udhar
                </span>
              </div>
            </div>
          ) : (
            <p className="text-xs text-black/40 dark:text-white/40">No sales in this period</p>
          )}
        </div>

        {/* Footer & CSV Export */}
        <div className="pt-2 text-center space-y-2">
          <button
            type="button"
            onClick={handleExportCsv}
            className="inline-flex items-center gap-1.5 text-xs font-semibold text-[var(--accent)] hover:underline cursor-pointer"
          >
            <Download size={14} />
            Export this view (CSV)
          </button>
        </div>
      </div>
    </Sheet>
  );
};
