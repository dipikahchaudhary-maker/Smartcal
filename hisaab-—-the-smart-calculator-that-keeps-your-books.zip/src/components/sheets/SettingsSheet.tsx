import React, { useState, useRef } from 'react';
import {
  Moon,
  Volume2,
  Vibrate,
  Eye,
  Trash2,
  Database,
  Sparkles,
  AlertTriangle,
  Lightbulb,
  ChevronRight,
} from 'lucide-react';
import { Sheet } from '../common/Sheet.tsx';
import { UserSettings, ShopProfile } from '../../types/index.ts';
import { saveSettings, saveProfile, generateSampleData, removeSampleData, eraseAllData } from '../../db/repo.ts';
import { triggerHaptic } from '../../utils/haptics.ts';
import { APP_NAME } from '../../constants/strings.en.ts';
import { SUPPORTED_CURRENCIES } from '../../constants/currencies.ts';

interface SettingsSheetProps {
  isOpen: boolean;
  onClose: () => void;
  settings: UserSettings;
  profile: ShopProfile | null;
  onSettingsUpdated: (updated: UserSettings) => void;
  onProfileUpdated: (updated: ShopProfile) => void;
  onEraseAllData: () => void;
  onDataRefresh: () => void;
  onOpenProTips?: () => void;
}

export const SettingsSheet: React.FC<SettingsSheetProps> = ({
  isOpen,
  onClose,
  settings,
  profile,
  onSettingsUpdated,
  onProfileUpdated,
  onEraseAllData,
  onDataRefresh,
  onOpenProTips,
}) => {
  const [showEraseModal, setShowEraseModal] = useState(false);
  const [eraseProgress, setEraseProgress] = useState(0);
  const [isSampleLoaded, setIsSampleLoaded] = useState(false);
  const eraseTimerRef = useRef<NodeJS.Timeout | null>(null);

  // Shop Profile state
  const [shopName, setShopName] = useState(profile?.shopName || '');
  const [ownerName, setOwnerName] = useState(profile?.name || '');
  const [upiId, setUpiId] = useState(profile?.upiId || '');
  const [dailyGoal, setDailyGoal] = useState(settings.dailyGoalMinor ? (settings.dailyGoalMinor / 100).toString() : '');

  const handleUpdateSetting = async (key: keyof UserSettings, val: any) => {
    triggerHaptic('selection');
    const updated = await saveSettings({ [key]: val });
    onSettingsUpdated(updated);
  };

  const handleSaveProfile = async () => {
    if (!profile) return;
    const updated: ShopProfile = {
      ...profile,
      shopName: shopName.trim() || profile.shopName,
      name: ownerName.trim() || profile.name,
      upiId: upiId.trim() || undefined,
    };
    await saveProfile(updated);
    onProfileUpdated(updated);
  };

  const handleCurrencyChange = async (currCode: string) => {
    if (!profile) return;
    const found = SUPPORTED_CURRENCIES.find((c) => c.code === currCode);
    if (!found) return;
    triggerHaptic('selection');
    const updated: ShopProfile = {
      ...profile,
      currency: found.code.split('_')[0],
      currencySymbol: found.symbol,
      countryCode: found.defaultCountryCode || profile.countryCode,
    };
    await saveProfile(updated);
    onProfileUpdated(updated);
  };

  const handleSymbolChange = async (newSymbol: string) => {
    if (!profile) return;
    const updated: ShopProfile = {
      ...profile,
      currencySymbol: newSymbol,
    };
    await saveProfile(updated);
    onProfileUpdated(updated);
  };

  const handleSaveGoal = async () => {
    const parsed = parseFloat(dailyGoal);
    const goalMinor = !isNaN(parsed) && parsed > 0 ? Math.round(parsed * 100) : null;
    await handleUpdateSetting('dailyGoalMinor', goalMinor);
  };

  const handleToggleSampleData = async () => {
    if (!profile) return;
    triggerHaptic('selection');
    if (!isSampleLoaded) {
      await generateSampleData(profile);
      setIsSampleLoaded(true);
    } else {
      await removeSampleData();
      setIsSampleLoaded(false);
    }
    onDataRefresh();
  };

  // Erase all data with 1.5s hold protection
  const handleErasePointerDown = () => {
    let p = 0;
    setEraseProgress(0);
    const interval = 50;
    eraseTimerRef.current = setInterval(() => {
      p += interval / 1500;
      if (p >= 1) {
        clearInterval(eraseTimerRef.current!);
        eraseTimerRef.current = null;
        triggerHaptic('warning');
        executeErase();
      } else {
        setEraseProgress(p);
      }
    }, interval);
  };

  const handleErasePointerUp = () => {
    if (eraseTimerRef.current) {
      clearInterval(eraseTimerRef.current);
      eraseTimerRef.current = null;
    }
    setEraseProgress(0);
  };

  const executeErase = async () => {
    await eraseAllData();
    setShowEraseModal(false);
    onEraseAllData();
  };

  return (
    <Sheet isOpen={isOpen} onClose={onClose} title="Settings">
      <div className="space-y-6 pb-12">
        {/* 1. Shop Profile */}
        <div className="space-y-2">
          <h4 className="text-xs font-bold text-black/50 dark:text-white/50 tracking-wider uppercase px-1">
            Shop & Profile
          </h4>
          <div className="p-4 rounded-3xl glass space-y-3">
            <div>
              <label className="text-xs text-black/60 dark:text-white/60 block mb-1">
                Shop Name
              </label>
              <input
                type="text"
                value={shopName}
                onChange={(e) => setShopName(e.target.value)}
                onBlur={handleSaveProfile}
                className="w-full h-10 px-3 rounded-xl bg-black/5 dark:bg-white/10 text-xs text-black dark:text-white font-medium"
              />
            </div>

            <div>
              <label className="text-xs text-black/60 dark:text-white/60 block mb-1">
                Your Name
              </label>
              <input
                type="text"
                value={ownerName}
                onChange={(e) => setOwnerName(e.target.value)}
                onBlur={handleSaveProfile}
                className="w-full h-10 px-3 rounded-xl bg-black/5 dark:bg-white/10 text-xs text-black dark:text-white font-medium"
              />
            </div>

            {profile?.countryCode === 'IN' && (
              <div>
                <label className="text-xs text-black/60 dark:text-white/60 block mb-1">
                  UPI ID (Used for payment QR)
                </label>
                <input
                  type="text"
                  placeholder="e.g. yourshop@okhdfcbank"
                  value={upiId}
                  onChange={(e) => setUpiId(e.target.value)}
                  onBlur={handleSaveProfile}
                  className="w-full h-10 px-3 rounded-xl bg-black/5 dark:bg-white/10 text-xs text-black dark:text-white font-mono"
                />
              </div>
            )}
          </div>
        </div>

        {/* 2. Appearance */}
        <div className="space-y-2">
          <h4 className="text-xs font-bold text-black/50 dark:text-white/50 tracking-wider uppercase px-1">
            Appearance
          </h4>
          <div className="p-4 rounded-3xl glass flex items-center justify-between">
            <div className="flex items-center gap-2">
              <Moon size={16} className="text-[var(--accent)]" />
              <span className="text-xs font-medium text-black dark:text-white">Theme</span>
            </div>
            <div className="px-3 py-1 rounded-full bg-white/10 text-white text-xs font-semibold flex items-center gap-1.5 shadow-sm">
              <span className="w-2 h-2 rounded-full bg-[#30D158]" />
              <span>Dark (Default)</span>
            </div>
          </div>
        </div>

        {/* 3. Money & Today Chip Mode */}
        <div className="space-y-2">
          <h4 className="text-xs font-bold text-black/50 dark:text-white/50 tracking-wider uppercase px-1">
            Money & Counter
          </h4>
          <div className="p-4 rounded-3xl glass divide-y divide-[var(--separator)]">
            <div className="py-2.5 flex items-center justify-between text-xs">
              <span className="text-black dark:text-white font-medium">Currency</span>
              <select
                value={profile?.currency || 'INR'}
                onChange={(e) => handleCurrencyChange(e.target.value)}
                className="bg-transparent text-[var(--accent)] font-semibold outline-none cursor-pointer"
              >
                {SUPPORTED_CURRENCIES.map((curr) => (
                  <option
                    key={curr.code}
                    value={curr.code}
                    className="bg-white dark:bg-neutral-900 text-black dark:text-white"
                  >
                    {curr.flag} {curr.code.split('_')[0]} ({curr.symbol})
                  </option>
                ))}
              </select>
            </div>

            <div className="py-2.5 flex items-center justify-between text-xs">
              <span className="text-black dark:text-white font-medium">Currency Symbol</span>
              <input
                type="text"
                value={profile?.currencySymbol || '$'}
                onChange={(e) => handleSymbolChange(e.target.value)}
                className="w-16 h-8 px-2 rounded-lg bg-black/5 dark:bg-white/10 text-xs text-center text-black dark:text-white font-bold"
              />
            </div>

            <div className="py-2.5 flex items-center justify-between text-xs">
              <span className="text-black dark:text-white font-medium">Today chip shows</span>
              <select
                value={settings.chipMode}
                onChange={(e) => handleUpdateSetting('chipMode', e.target.value)}
                className="bg-transparent text-[var(--accent)] font-semibold outline-none cursor-pointer"
              >
                <option value="sales">Sales (Money In)</option>
                <option value="profit">Net Profit</option>
              </select>
            </div>

            <div className="py-2.5 flex items-center justify-between text-xs">
              <span className="text-black dark:text-white font-medium">Daily Sales Goal</span>
              <div className="flex items-center gap-1.5">
                <input
                  type="number"
                  placeholder="e.g. 5000"
                  value={dailyGoal}
                  onChange={(e) => setDailyGoal(e.target.value)}
                  onBlur={handleSaveGoal}
                  className="w-24 h-8 px-2 rounded-lg bg-black/5 dark:bg-white/10 text-xs text-right text-black dark:text-white font-bold"
                />
              </div>
            </div>
          </div>
        </div>

        {/* 4. Feel & Controls */}
        <div className="space-y-2">
          <h4 className="text-xs font-bold text-black/50 dark:text-white/50 tracking-wider uppercase px-1">
            Feel & Haptics
          </h4>
          <div className="p-4 rounded-3xl glass divide-y divide-[var(--separator)]">
            <label className="py-2.5 flex items-center justify-between text-xs cursor-pointer">
              <div className="flex items-center gap-2 text-black dark:text-white">
                <Vibrate size={16} />
                <span>Haptic feedback</span>
              </div>
              <input
                type="checkbox"
                checked={settings.haptics}
                onChange={(e) => handleUpdateSetting('haptics', e.target.checked)}
                className="rounded text-[var(--accent)]"
              />
            </label>

            <label className="py-2.5 flex items-center justify-between text-xs cursor-pointer">
              <div className="flex items-center gap-2 text-black dark:text-white">
                <Volume2 size={16} />
                <span>Confirmation sounds</span>
              </div>
              <input
                type="checkbox"
                checked={settings.sounds}
                onChange={(e) => handleUpdateSetting('sounds', e.target.checked)}
                className="rounded text-[var(--accent)]"
              />
            </label>

            <label className="py-2.5 flex items-center justify-between text-xs cursor-pointer">
              <div className="flex items-center gap-2 text-black dark:text-white">
                <Eye size={16} />
                <span>Reduce motion</span>
              </div>
              <input
                type="checkbox"
                checked={settings.reduceMotion}
                onChange={(e) => handleUpdateSetting('reduceMotion', e.target.checked)}
                className="rounded text-[var(--accent)]"
              />
            </label>
          </div>
        </div>

        {/* 5. Pro Tips & Shortcuts */}
        <div className="space-y-2">
          <h4 className="text-xs font-bold text-black/50 dark:text-white/50 tracking-wider uppercase px-1">
            Tips & Tricks
          </h4>
          <div className="p-4 rounded-3xl glass space-y-2">
            <button
              type="button"
              onClick={() => {
                triggerHaptic('selection');
                if (onOpenProTips) onOpenProTips();
              }}
              className="w-full h-12 px-4 rounded-2xl bg-[var(--accent)]/12 hover:bg-[var(--accent)]/18 text-[var(--accent)] text-xs font-semibold flex items-center justify-between active:scale-98 transition-all cursor-pointer"
            >
              <div className="flex items-center gap-2.5">
                <Lightbulb size={18} strokeWidth={2.4} />
                <span className="text-sm font-semibold">Pro Tips & Shortcuts</span>
              </div>
              <ChevronRight size={16} />
            </button>
            <p className="text-[11px] text-black/50 dark:text-white/50 px-1 leading-snug">
              Learn swipe-to-delete, 4s hold cash-in trick, instant WhatsApp reminders, and counter shortcuts.
            </p>
          </div>
        </div>

        {/* 6. Demo & Danger Zone */}
        <div className="space-y-2">
          <h4 className="text-xs font-bold text-black/50 dark:text-white/50 tracking-wider uppercase px-1">
            Data & Privacy
          </h4>
          <div className="p-4 rounded-3xl glass space-y-3">
            <button
              type="button"
              onClick={handleToggleSampleData}
              className="w-full h-11 rounded-2xl bg-black/5 dark:bg-white/10 hover:bg-black/10 text-black dark:text-white text-xs font-semibold flex items-center justify-center gap-2 active:scale-95"
            >
              <Sparkles size={16} className="text-[#FF9500]" />
              {isSampleLoaded ? 'Remove Sample Data' : 'Load Sample Data (120 Days)'}
            </button>

            <button
              type="button"
              onClick={() => setShowEraseModal(true)}
              className="w-full h-11 rounded-2xl bg-[#FF3B30]/10 hover:bg-[#FF3B30]/15 text-[#FF3B30] text-xs font-semibold flex items-center justify-center gap-2 active:scale-95"
            >
              <Trash2 size={16} />
              Erase All Data
            </button>
          </div>
        </div>

        {/* Erase All Data Confirmation Modal */}
        {showEraseModal && (
          <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/60 backdrop-blur-md">
            <div className="w-full max-w-[340px] rounded-3xl glass-strong p-6 border border-[#FF3B30]/40 space-y-4 text-center">
              <AlertTriangle size={36} className="text-[#FF3B30] mx-auto" />
              <h3 className="text-lg font-bold text-black dark:text-white">
                Erase All Data?
              </h3>
              <p className="text-xs text-black/70 dark:text-white/70 leading-relaxed">
                This will permanently delete all sales, expenses, categories, Udhar ledgers and reset your shop. This action cannot be undone.
              </p>

              {/* 1.5s Press and Hold Button */}
              <div className="pt-2">
                <button
                  type="button"
                  onPointerDown={handleErasePointerDown}
                  onPointerUp={handleErasePointerUp}
                  onPointerCancel={handleErasePointerUp}
                  className="relative w-full h-12 rounded-2xl bg-[#FF3B30] text-white text-xs font-bold overflow-hidden active:scale-98 select-none"
                >
                  <div
                    className="absolute inset-0 bg-black/30 origin-left transition-all"
                    style={{ width: `${eraseProgress * 100}%` }}
                  />
                  <span className="relative z-10">
                    {eraseProgress > 0 ? 'Hold to Erase…' : 'Press & Hold (1.5s) to Erase'}
                  </span>
                </button>
              </div>

              <button
                type="button"
                onClick={() => setShowEraseModal(false)}
                className="w-full h-9 rounded-xl text-xs font-semibold text-black/60 dark:text-white/60"
              >
                Cancel
              </button>
            </div>
          </div>
        )}

        {/* About & PWA */}
        <div className="pt-2 text-center space-y-1 text-black/40 dark:text-white/40">
          <p className="text-xs font-semibold text-black/70 dark:text-white/70">
            {APP_NAME} · Built for Shopkeepers
          </p>
          <p className="text-[11px]">
            To install as an app: tap Share in Safari / Chrome → Add to Home Screen.
          </p>
          <p className="text-[10px] pt-1">
            Private & offline-first. No third party data sharing.
          </p>
        </div>
      </div>
    </Sheet>
  );
};
