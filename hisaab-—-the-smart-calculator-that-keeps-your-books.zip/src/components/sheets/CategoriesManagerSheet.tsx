import React, { useState } from 'react';
import * as LucideIcons from 'lucide-react';
import { Sheet } from '../common/Sheet.tsx';
import { Category } from '../../types/index.ts';
import { COLOR_OPTIONS, AVAILABLE_ICONS } from '../../constants/categories.ts';
import { formatFullDate } from '../../utils/formatters.ts';
import { triggerHaptic } from '../../utils/haptics.ts';

interface CategoriesManagerSheetProps {
  isOpen: boolean;
  onClose: () => void;
  categories: Category[];
  onAddCategory: (cat: Omit<Category, 'id' | 'createdAt' | 'recentAmountsMinor' | 'order' | 'archived'>) => void;
  onArchiveCategory: (id: string) => void;
  onReorderCategories: (categories: Category[]) => void;
}

export const CategoriesManagerSheet: React.FC<CategoriesManagerSheetProps> = ({
  isOpen,
  onClose,
  categories,
  onAddCategory,
  onArchiveCategory,
  onReorderCategories,
}) => {
  const [showAddModal, setShowAddModal] = useState(false);
  const [name, setName] = useState('');
  const [icon, setIcon] = useState('ShoppingBag');
  const [color, setColor] = useState('teal');

  const getIconComponent = (iconName: string) => {
    return (LucideIcons as any)[iconName] || LucideIcons.Folder;
  };

  const getColorConfig = (colorId: string) => {
    return COLOR_OPTIONS.find((c) => c.id === colorId) || COLOR_OPTIONS[0];
  };

  const handleCreate = (e: React.FormEvent) => {
    e.preventDefault();
    if (!name.trim()) return;
    onAddCategory({
      name: name.trim(),
      icon,
      color,
    });
    setName('');
    setShowAddModal(false);
  };

  return (
    <Sheet
      isOpen={isOpen}
      onClose={onClose}
      title="Cash Out Options"
      rightAction={
        <button
          type="button"
          onClick={() => {
            triggerHaptic('selection');
            setShowAddModal(true);
          }}
          className="text-[17px] font-semibold text-[var(--accent)] hover:opacity-80 active:scale-95"
        >
          + Add
        </button>
      }
    >
      <div className="space-y-4 pb-12">
        <p className="text-xs text-black/60 dark:text-white/60 px-1">
          Customise the expense categories shown when you tap Cash Out. Archived categories keep their past history intact.
        </p>

        {/* Categories List */}
        <div className="rounded-3xl glass divide-y divide-[var(--separator)] overflow-hidden">
          {categories.map((cat) => {
            const Icon = getIconComponent(cat.icon);
            const colorConfig = getColorConfig(cat.color);

            return (
              <div
                key={cat.id}
                className="p-3.5 flex items-center justify-between hover:bg-black/5 dark:hover:bg-white/5 transition-colors"
              >
                <div className="flex items-center gap-3">
                  <div
                    className="w-10 h-10 rounded-2xl flex items-center justify-center flex-shrink-0"
                    style={{
                      backgroundColor: colorConfig.lightBg,
                      color: colorConfig.lightColor,
                    }}
                  >
                    <Icon size={20} strokeWidth={2} />
                  </div>
                  <div>
                    <p className="text-sm font-semibold text-black dark:text-white">
                      {cat.name}
                    </p>
                    <p className="text-[11px] text-black/50 dark:text-white/50">
                      {cat.lastUsedAt ? `Last used: ${formatFullDate(cat.lastUsedAt)}` : 'Never used'}
                    </p>
                  </div>
                </div>

                <button
                  type="button"
                  onClick={() => {
                    triggerHaptic('warning');
                    onArchiveCategory(cat.id);
                  }}
                  className="px-3 py-1 rounded-xl bg-black/5 dark:bg-white/10 text-xs font-semibold text-[#FF3B30] hover:bg-black/10"
                >
                  Remove
                </button>
              </div>
            );
          })}
        </div>

        {/* Add Category Modal */}
        {showAddModal && (
          <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/60 backdrop-blur-md">
            <div className="w-full max-w-[340px] rounded-3xl glass-strong p-5 border border-[var(--glass-stroke)] space-y-4">
              <h3 className="text-base font-bold text-black dark:text-white">
                New Cash Out Option
              </h3>
              <form onSubmit={handleCreate} className="space-y-4">
                <div>
                  <label className="text-xs text-black/60 dark:text-white/60 block mb-1">
                    Option Name
                  </label>
                  <input
                    type="text"
                    placeholder="e.g. Electricity Bill, Milk…"
                    value={name}
                    onChange={(e) => setName(e.target.value)}
                    className="w-full h-11 px-3 rounded-xl bg-black/5 dark:bg-white/10 text-sm text-black dark:text-white focus:ring-1 focus:ring-[var(--accent)]"
                    required
                    autoFocus
                  />
                </div>

                {/* Color Selector */}
                <div>
                  <label className="text-xs text-black/60 dark:text-white/60 block mb-1">
                    Color
                  </label>
                  <div className="flex gap-2">
                    {COLOR_OPTIONS.map((c) => (
                      <button
                        key={c.id}
                        type="button"
                        onClick={() => setColor(c.id)}
                        className={`w-7 h-7 rounded-full transition-transform ${
                          color === c.id ? 'ring-2 ring-black dark:ring-white scale-110' : ''
                        }`}
                        style={{ backgroundColor: c.lightColor }}
                      />
                    ))}
                  </div>
                </div>

                {/* Icon Selector (Sample 12 icons) */}
                <div>
                  <label className="text-xs text-black/60 dark:text-white/60 block mb-1">
                    Icon
                  </label>
                  <div className="grid grid-cols-6 gap-2 max-h-32 overflow-y-auto p-1">
                    {AVAILABLE_ICONS.slice(0, 18).map((iconName) => {
                      const IconComp = getIconComponent(iconName);
                      return (
                        <button
                          key={iconName}
                          type="button"
                          onClick={() => setIcon(iconName)}
                          className={`w-9 h-9 rounded-xl flex items-center justify-center ${
                            icon === iconName
                              ? 'bg-[var(--accent)] text-white'
                              : 'bg-black/5 dark:bg-white/10 text-black dark:text-white'
                          }`}
                        >
                          <IconComp size={18} />
                        </button>
                      );
                    })}
                  </div>
                </div>

                <div className="flex gap-2 pt-2">
                  <button
                    type="button"
                    onClick={() => setShowAddModal(false)}
                    className="flex-1 h-10 rounded-xl bg-black/10 dark:bg-white/10 text-xs font-semibold text-black dark:text-white"
                  >
                    Cancel
                  </button>
                  <button
                    type="submit"
                    className="flex-1 h-10 rounded-xl bg-[var(--accent)] text-white text-xs font-semibold"
                  >
                    Save
                  </button>
                </div>
              </form>
            </div>
          </div>
        )}
      </div>
    </Sheet>
  );
};
