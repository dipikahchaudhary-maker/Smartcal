import React, { useRef } from 'react';
import { Share2, Download, Printer } from 'lucide-react';
import { toPng } from 'html-to-image';
import { jsPDF } from 'jspdf';
import { Sheet } from '../common/Sheet.tsx';
import { Transaction, ShopProfile } from '../../types/index.ts';
import {
  formatFullDate,
  formatTimeOfDay,
  formatMoney,
} from '../../utils/formatters.ts';
import { triggerHaptic } from '../../utils/haptics.ts';

interface BillViewSheetProps {
  isOpen: boolean;
  onClose: () => void;
  transaction: Transaction | null;
  profile: ShopProfile | null;
  currencySymbol: string;
  countryCode: string;
}

export const BillViewSheet: React.FC<BillViewSheetProps> = ({
  isOpen,
  onClose,
  transaction,
  profile,
  currencySymbol,
  countryCode,
}) => {
  const receiptRef = useRef<HTMLDivElement>(null);

  if (!transaction) return null;

  // Generate unique formatted Bill number: HB-YYYYMMDD-XXX
  const d = new Date(transaction.ts);
  const yyyy = d.getFullYear();
  const mm = String(d.getMonth() + 1).padStart(2, '0');
  const dd = String(d.getDate()).padStart(2, '0');
  const billId = `HB-${yyyy}${mm}${dd}-${transaction.id.slice(-4).toUpperCase()}`;

  // Parse additive parts of typed expression for line items
  // e.g. "120 + 45 + 300" -> items [120, 45, 300]
  let lineItems: Array<{ desc: string; amount: number }> = [];
  if (transaction.expr && transaction.expr.includes('+')) {
    const parts = transaction.expr.split('+').map((p) => parseFloat(p.trim())).filter((n) => !isNaN(n));
    if (parts.length > 1) {
      lineItems = parts.map((amt, idx) => ({
        desc: `Item #${idx + 1}`,
        amount: Math.round(amt * 100),
      }));
    }
  }

  if (lineItems.length === 0) {
    lineItems = [{ desc: transaction.note || 'Items / Counter Sale', amount: transaction.amountMinor }];
  }

  const handleShare = async () => {
    triggerHaptic('success');
    if (!receiptRef.current) return;
    try {
      const dataUrl = await toPng(receiptRef.current, {
        quality: 1,
        pixelRatio: 2,
        skipFonts: true,
        cacheBust: true,
      });
      const blob = await (await fetch(dataUrl)).blob();
      const file = new File([blob], `${billId}.png`, { type: 'image/png' });

      if (navigator.share && navigator.canShare && navigator.canShare({ files: [file] })) {
        await navigator.share({
          title: `Receipt from ${profile?.shopName || 'Hisaab'}`,
          files: [file],
        });
      } else {
        const link = document.createElement('a');
        link.download = `${billId}.png`;
        link.href = dataUrl;
        link.click();
      }
    } catch (err) {
      console.error('Failed to share bill image:', err);
    }
  };

  const handleDownloadPdf = async () => {
    triggerHaptic('success');
    if (!receiptRef.current) return;
    try {
      const dataUrl = await toPng(receiptRef.current, {
        quality: 1,
        pixelRatio: 2,
        skipFonts: true,
        cacheBust: true,
      });
      const doc = new jsPDF({
        orientation: 'portrait',
        unit: 'mm',
        format: [80, 160], // Receipt thermal slip aspect
      });
      doc.addImage(dataUrl, 'PNG', 0, 0, 80, 160);
      doc.save(`${billId}.pdf`);
    } catch (err) {
      console.error('Failed to export PDF:', err);
    }
  };

  return (
    <Sheet isOpen={isOpen} onClose={onClose} title="Receipt">
      <div className="space-y-6 pb-12">
        {/* Apple Wallet / Clean Monochrome Thermal Receipt Card */}
        <div
          ref={receiptRef}
          className="w-full max-w-[340px] mx-auto p-6 rounded-3xl bg-white text-black shadow-xl border border-black/10 select-none space-y-4 font-mono"
        >
          {/* Header */}
          <div className="text-center space-y-1 pb-3 border-b border-black/15">
            <h2 className="text-lg font-bold uppercase tracking-wider">
              {profile?.shopName || 'HISAAB STORE'}
            </h2>
            {profile?.address && <p className="text-[11px] text-black/70">{profile.address}</p>}
            {profile?.mobileE164 && (
              <p className="text-[11px] text-black/70">Tel: {profile.mobileE164}</p>
            )}
            <p className="text-[10px] text-black/50 pt-1">Bill No: {billId}</p>
            <p className="text-[10px] text-black/50">
              {formatFullDate(transaction.ts)} · {formatTimeOfDay(transaction.ts)}
            </p>
          </div>

          {/* Line Items */}
          <div className="space-y-2 py-2 border-b border-black/15 text-xs">
            {lineItems.map((item, idx) => (
              <div key={idx} className="flex justify-between">
                <span>{item.desc}</span>
                <span className="tabular-nums font-semibold">
                  {formatMoney(item.amount, currencySymbol, 'auto', countryCode)}
                </span>
              </div>
            ))}
          </div>

          {/* Total */}
          <div className="flex justify-between items-baseline pt-1 text-sm font-bold">
            <span className="uppercase">TOTAL AMOUNT</span>
            <span className="text-lg tabular-nums">
              {formatMoney(transaction.amountMinor, currencySymbol, 'auto', countryCode)}
            </span>
          </div>

          <div className="flex justify-between text-xs text-black/70 pt-1">
            <span>Payment Mode:</span>
            <span className="uppercase font-semibold">{transaction.mode}</span>
          </div>

          {/* Footer */}
          <div className="text-center pt-4 border-t border-black/10 text-[11px] text-black/60 space-y-1">
            <p className="font-semibold uppercase tracking-wider">Thank you! Visit again.</p>
            <p className="text-[9px] text-black/40">Powered by Hisaab</p>
          </div>
        </div>

        {/* Action Buttons */}
        <div className="flex gap-3 max-w-[340px] mx-auto">
          <button
            type="button"
            onClick={handleShare}
            className="flex-1 h-12 rounded-2xl bg-[var(--accent)] text-white font-semibold flex items-center justify-center gap-2 active:scale-95 shadow-md"
          >
            <Share2 size={18} />
            Share
          </button>
          <button
            type="button"
            onClick={handleDownloadPdf}
            className="flex-1 h-12 rounded-2xl glass text-black dark:text-white font-semibold flex items-center justify-center gap-2 active:scale-95"
          >
            <Download size={18} />
            PDF
          </button>
        </div>
      </div>
    </Sheet>
  );
};
