import React, { useEffect, useState } from 'react';
import QRCode from 'qrcode';
import { QrCode, CheckCircle2, AlertCircle } from 'lucide-react';
import { Sheet } from '../common/Sheet.tsx';
import { formatMoney } from '../../utils/formatters.ts';
import { triggerHaptic } from '../../utils/haptics.ts';

interface UpiQrSheetProps {
  isOpen: boolean;
  onClose: () => void;
  amountMinor: number;
  upiId?: string;
  shopName?: string;
  currencySymbol: string;
  countryCode: string;
  onPaymentReceived: () => void;
}

export const UpiQrSheet: React.FC<UpiQrSheetProps> = ({
  isOpen,
  onClose,
  amountMinor,
  upiId,
  shopName = 'Hisaab Store',
  currencySymbol,
  countryCode,
  onPaymentReceived,
}) => {
  const [qrDataUrl, setQrDataUrl] = useState<string>('');

  useEffect(() => {
    if (!isOpen || !upiId) return;

    const majorAmt = (amountMinor / 100).toFixed(2);
    const cleanShop = encodeURIComponent(shopName);
    const upiUri = `upi://pay?pa=${encodeURIComponent(upiId)}&pn=${cleanShop}&am=${majorAmt}&cu=INR`;

    QRCode.toDataURL(upiUri, {
      width: 280,
      margin: 1.5,
      color: {
        dark: '#000000',
        light: '#FFFFFF',
      },
    })
      .then((url) => setQrDataUrl(url))
      .catch((err) => console.error(err));
  }, [isOpen, upiId, amountMinor, shopName]);

  const handleConfirm = () => {
    triggerHaptic('success');
    onPaymentReceived();
    onClose();
  };

  return (
    <Sheet isOpen={isOpen} onClose={onClose} title="UPI Payment QR">
      <div className="space-y-6 pb-12 flex flex-col items-center text-center">
        {!upiId ? (
          <div className="p-6 rounded-3xl glass max-w-[320px] space-y-3">
            <AlertCircle size={32} className="text-[#FF9500] mx-auto" />
            <h3 className="text-base font-bold text-black dark:text-white">
              No UPI ID configured
            </h3>
            <p className="text-xs text-black/60 dark:text-white/60">
              Please enter your shop's UPI ID in Settings to show instant payment QR codes for customers.
            </p>
          </div>
        ) : (
          <>
            <div className="space-y-1">
              <span className="text-xs text-black/50 dark:text-white/50 uppercase font-semibold">
                Scan to pay
              </span>
              <h2 className="text-3xl font-bold text-black dark:text-white tabular-nums">
                {formatMoney(amountMinor, currencySymbol, 'auto', countryCode)}
              </h2>
              <p className="text-xs text-black/60 dark:text-white/60 font-medium">
                UPI ID: {upiId}
              </p>
            </div>

            {/* QR Code Container */}
            <div className="p-4 rounded-3xl bg-white shadow-xl border border-black/10">
              {qrDataUrl ? (
                <img
                  src={qrDataUrl}
                  alt="UPI QR Code"
                  className="w-56 h-56 rounded-xl object-contain mx-auto"
                />
              ) : (
                <div className="w-56 h-56 flex items-center justify-center text-black/40 text-xs">
                  Generating QR…
                </div>
              )}
            </div>

            <p className="text-[11px] text-black/40 dark:text-white/40 max-w-[280px]">
              Customer can scan using Google Pay, PhonePe, Paytm, or any UPI app.
            </p>

            <button
              type="button"
              onClick={handleConfirm}
              className="w-full max-w-[320px] h-12 rounded-2xl bg-[#34C759] text-white font-semibold flex items-center justify-center gap-2 active:scale-95 transition-all shadow-md cursor-pointer"
            >
              <CheckCircle2 size={18} />
              Payment Received
            </button>
          </>
        )}
      </div>
    </Sheet>
  );
};
