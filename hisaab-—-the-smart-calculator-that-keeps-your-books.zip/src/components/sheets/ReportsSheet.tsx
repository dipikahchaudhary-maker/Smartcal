import React, { useState, useRef } from 'react';
import {
  Download,
  Upload,
  FileSpreadsheet,
  FileText,
  ShieldCheck,
  Check,
} from 'lucide-react';
import { Sheet } from '../common/Sheet.tsx';
import { exportBackupJson, restoreFromBackupJson, getHistoryTransactions } from '../../db/repo.ts';
import { formatFullDate, formatMoney } from '../../utils/formatters.ts';
import { triggerHaptic } from '../../utils/haptics.ts';

interface ReportsSheetProps {
  isOpen: boolean;
  onClose: () => void;
  currencySymbol: string;
  countryCode: string;
  onDataRestored: () => void;
}

export const ReportsSheet: React.FC<ReportsSheetProps> = ({
  isOpen,
  onClose,
  currencySymbol,
  countryCode,
  onDataRestored,
}) => {
  const [restoreModalOpen, setRestoreModalOpen] = useState(false);
  const [backupContentToRestore, setBackupContentToRestore] = useState<string | null>(null);
  const [successMsg, setSuccessMsg] = useState<string | null>(null);
  const fileInputRef = useRef<HTMLInputElement>(null);

  const handleExportCsv = async () => {
    triggerHaptic('success');
    const txs = await getHistoryTransactions('all', '', undefined, 10000);
    let csv = 'ID,Date,Time,Type,Category/Mode,Amount,Customer Count,Note\n';
    txs.forEach((t) => {
      csv += `"${t.id}","${t.dayKey}","${t.hour}:00","${t.type}","${t.categoryName || t.mode}","${t.amountMinor / 100}","${t.countsAsCustomer ? 1 : 0}","${t.note || ''}"\n`;
    });

    const blob = new Blob([csv], { type: 'text/csv;charset=utf-8;' });
    const url = URL.createObjectURL(blob);
    const link = document.createElement('a');
    link.href = url;
    link.download = `hisaab_full_transactions_${Date.now()}.csv`;
    link.click();
    showToast('Transactions exported as CSV');
  };

  const handleDownloadBackup = async () => {
    triggerHaptic('success');
    const jsonStr = await exportBackupJson();
    const blob = new Blob([jsonStr], { type: 'application/json' });
    const url = URL.createObjectURL(blob);
    const link = document.createElement('a');
    link.href = url;
    link.download = `hisaab_backup_${new Date().toISOString().slice(0, 10)}.json`;
    link.click();
    showToast('Backup saved successfully');
  };

  const handleFileSelected = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;

    const reader = new FileReader();
    reader.onload = (event) => {
      const content = event.target?.result as string;
      setBackupContentToRestore(content);
      setRestoreModalOpen(true);
    };
    reader.readAsText(file);
    e.target.value = '';
  };

  const handlePerformRestore = async (mode: 'replace' | 'merge') => {
    if (!backupContentToRestore) return;
    triggerHaptic('success');
    const ok = await restoreFromBackupJson(backupContentToRestore, mode);
    setRestoreModalOpen(false);
    setBackupContentToRestore(null);
    if (ok) {
      showToast(mode === 'replace' ? 'Data restored (Replaced)' : 'Data merged successfully');
      onDataRestored();
    } else {
      showToast('Failed to restore: Invalid backup file');
    }
  };

  const showToast = (msg: string) => {
    setSuccessMsg(msg);
    setTimeout(() => setSuccessMsg(null), 3000);
  };

  return (
    <Sheet isOpen={isOpen} onClose={onClose} title="Reports & Backup">
      <div className="space-y-6 pb-12">
        {successMsg && (
          <div className="p-3 rounded-2xl bg-[#34C759]/15 text-[#34C759] text-xs font-semibold flex items-center gap-2">
            <Check size={16} />
            <span>{successMsg}</span>
          </div>
        )}

        {/* Section 1: Exports */}
        <div className="space-y-2">
          <h4 className="text-xs font-bold text-black/50 dark:text-white/50 tracking-wider uppercase px-1">
            Data Exports
          </h4>
          <div className="p-4 rounded-3xl glass space-y-3">
            <p className="text-xs text-black/60 dark:text-white/60">
              Download your complete counter records, sales, expenses, and Udhar entries.
            </p>
            <button
              type="button"
              onClick={handleExportCsv}
              className="w-full h-11 rounded-2xl bg-black/5 dark:bg-white/10 hover:bg-black/10 text-black dark:text-white text-xs font-semibold flex items-center justify-center gap-2 active:scale-95 transition-all"
            >
              <FileSpreadsheet size={16} className="text-[#34C759]" />
              Export Full Transactions (CSV)
            </button>
          </div>
        </div>

        {/* Section 2: Backup & Restore */}
        <div className="space-y-2">
          <h4 className="text-xs font-bold text-black/50 dark:text-white/50 tracking-wider uppercase px-1">
            Backup & Restore
          </h4>
          <div className="p-4 rounded-3xl glass space-y-3">
            <div className="flex items-center gap-2 text-xs text-black/70 dark:text-white/70">
              <ShieldCheck size={16} className="text-[var(--accent)]" />
              <span>Keep an offline copy of your entire shop ledger.</span>
            </div>

            <div className="grid grid-cols-2 gap-3 pt-1">
              <button
                type="button"
                onClick={handleDownloadBackup}
                className="h-11 rounded-2xl bg-[var(--accent)] text-white text-xs font-semibold flex items-center justify-center gap-1.5 active:scale-95 shadow-sm"
              >
                <Download size={15} />
                Backup JSON
              </button>

              <button
                type="button"
                onClick={() => fileInputRef.current?.click()}
                className="h-11 rounded-2xl glass text-black dark:text-white text-xs font-semibold flex items-center justify-center gap-1.5 active:scale-95"
              >
                <Upload size={15} />
                Restore JSON
              </button>
              <input
                ref={fileInputRef}
                type="file"
                accept=".json"
                onChange={handleFileSelected}
                className="hidden"
              />
            </div>
          </div>
        </div>

        {/* Restore Confirmation Modal */}
        {restoreModalOpen && (
          <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/60 backdrop-blur-md">
            <div className="w-full max-w-[340px] rounded-3xl glass-strong p-5 border border-[var(--glass-stroke)] space-y-4">
              <h3 className="text-base font-bold text-black dark:text-white">
                Restore Ledger Backup
              </h3>
              <p className="text-xs text-black/70 dark:text-white/70 leading-relaxed">
                Choose how you want to restore this backup:
              </p>
              <div className="space-y-2 pt-1">
                <button
                  type="button"
                  onClick={() => handlePerformRestore('replace')}
                  className="w-full h-11 rounded-xl bg-[#FF3B30] text-white text-xs font-semibold active:scale-95"
                >
                  Replace All Existing Data
                </button>
                <button
                  type="button"
                  onClick={() => handlePerformRestore('merge')}
                  className="w-full h-11 rounded-xl bg-[var(--accent)] text-white text-xs font-semibold active:scale-95"
                >
                  Merge With Current Data
                </button>
                <button
                  type="button"
                  onClick={() => {
                    setRestoreModalOpen(false);
                    setBackupContentToRestore(null);
                  }}
                  className="w-full h-10 rounded-xl bg-black/10 dark:bg-white/10 text-xs text-black dark:text-white font-medium"
                >
                  Cancel
                </button>
              </div>
            </div>
          </div>
        )}
      </div>
    </Sheet>
  );
};
