import React, { useState, useEffect } from 'react';
import {
  Search,
  ArrowDownLeft,
  ArrowUpRight,
  UserCheck,
  Trash2,
  Edit2,
  FileText,
  Calendar,
  X,
} from 'lucide-react';
import { Sheet } from '../common/Sheet.tsx';
import { Transaction, PaymentMode } from '../../types/index.ts';
import {
  getHistoryTransactions,
  deleteTransaction,
  updateTransaction,
  getDailyRollup,
  getCategories,
} from '../../db/repo.ts';
import {
  formatFullDate,
  formatTimeOfDay,
  formatMoney,
} from '../../utils/formatters.ts';
import { triggerHaptic } from '../../utils/haptics.ts';

interface HistorySheetProps {
  isOpen: boolean;
  onClose: () => void;
  currencySymbol: string;
  countryCode: string;
  onOpenBill: (tx: Transaction) => void;
  initialDayKey?: string;
}

type FilterType = 'all' | 'cash_in' | 'cash_out' | 'udhar';

export const HistorySheet: React.FC<HistorySheetProps> = ({
  isOpen,
  onClose,
  currencySymbol,
  countryCode,
  onOpenBill,
  initialDayKey,
}) => {
  const [filter, setFilter] = useState<FilterType>('all');
  const [searchQuery, setSearchQuery] = useState('');
  const [selectedDate, setSelectedDate] = useState<string | undefined>(initialDayKey);
  const [transactions, setTransactions] = useState<Transaction[]>([]);
  const [daySummaries, setDaySummaries] = useState<Record<string, { customers: number; sales: number; expenses: number }>>({});
  const [editingTx, setEditingTx] = useState<Transaction | null>(null);
  const [editAmount, setEditAmount] = useState('');
  const [editNote, setEditNote] = useState('');
  const [editCountsAsCust, setEditCountsAsCust] = useState(true);

  useEffect(() => {
    if (!isOpen) return;
    loadTransactions();
  }, [isOpen, filter, searchQuery, selectedDate]);

  const loadTransactions = async () => {
    const data = await getHistoryTransactions(filter, searchQuery, selectedDate, 150);
    setTransactions(data);

    // Compute unique day summaries
    const uniqueDays = Array.from(new Set(data.map((t) => t.dayKey)));
    const summaries: Record<string, { customers: number; sales: number; expenses: number }> = {};
    for (const dk of uniqueDays) {
      const r = await getDailyRollup(dk);
      summaries[dk] = {
        customers: r.customers,
        sales: r.salesMinor,
        expenses: r.expensesMinor,
      };
    }
    setDaySummaries(summaries);
  };

  const handleDelete = async (tx: Transaction) => {
    triggerHaptic('warning');
    await deleteTransaction(tx.id);
    loadTransactions();
  };

  const handleStartEdit = (tx: Transaction) => {
    setEditingTx(tx);
    setEditAmount((tx.amountMinor / 100).toString());
    setEditNote(tx.note || '');
    setEditCountsAsCust(tx.countsAsCustomer);
  };

  const handleSaveEdit = async () => {
    if (!editingTx) return;
    const parsed = parseFloat(editAmount);
    if (isNaN(parsed) || parsed <= 0) return;

    await updateTransaction(editingTx.id, {
      amountMinor: Math.round(parsed * 100),
      note: editNote.trim() || undefined,
      countsAsCustomer: editCountsAsCust,
    });

    setEditingTx(null);
    loadTransactions();
  };

  // Group transactions by dayKey
  const groupedByDay: Record<string, Transaction[]> = {};
  transactions.forEach((tx) => {
    if (!groupedByDay[tx.dayKey]) groupedByDay[tx.dayKey] = [];
    groupedByDay[tx.dayKey].push(tx);
  });

  return (
    <Sheet isOpen={isOpen} onClose={onClose} title="History">
      <div className="space-y-4 pb-12">
        {/* Search Bar + Date Filter */}
        <div className="flex gap-2">
          <div className="relative flex-1">
            <Search
              size={16}
              className="absolute left-3.5 top-1/2 -translate-y-1/2 text-black/40 dark:text-white/40"
            />
            <input
              type="text"
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
              placeholder="Search category, note, amount…"
              className="w-full h-10 pl-9 pr-3 rounded-2xl glass text-xs text-black dark:text-white placeholder-black/40 dark:placeholder-white/40 focus:outline-none focus:ring-1 focus:ring-[var(--accent)]"
            />
          </div>

          {selectedDate && (
            <button
              type="button"
              onClick={() => setSelectedDate(undefined)}
              className="px-2.5 h-10 rounded-2xl bg-black/10 dark:bg-white/10 text-xs font-semibold text-black dark:text-white flex items-center gap-1"
            >
              Clear Date <X size={14} />
            </button>
          )}
        </div>

        {/* Filter Chips */}
        <div className="flex gap-2 overflow-x-auto pb-1 no-scrollbar">
          {(['all', 'cash_in', 'cash_out', 'udhar'] as FilterType[]).map((f) => (
            <button
              key={f}
              type="button"
              onClick={() => {
                triggerHaptic('selection');
                setFilter(f);
              }}
              className={`px-3.5 py-1.5 rounded-full text-xs font-semibold capitalize whitespace-nowrap transition-all cursor-pointer ${
                filter === f
                  ? 'bg-[var(--accent)] text-white shadow-sm'
                  : 'glass text-black/70 dark:text-white/70 hover:text-black dark:hover:text-white'
              }`}
            >
              {f.replace('_', ' ')}
            </button>
          ))}
        </div>

        {/* Grouped Transaction List */}
        {Object.keys(groupedByDay).length === 0 ? (
          <div className="py-16 text-center text-black/40 dark:text-white/40 space-y-2">
            <p className="text-sm font-medium">No entries yet.</p>
          </div>
        ) : (
          Object.entries(groupedByDay).map(([dayKey, dayTxs]) => {
            const summary = daySummaries[dayKey];
            return (
              <div key={dayKey} className="space-y-2">
                {/* Sticky Glass Header */}
                <div className="sticky top-0 z-10 py-1.5 px-3 rounded-2xl glass-strong border border-[var(--glass-stroke)] shadow-sm">
                  <div className="flex items-center justify-between">
                    <span className="text-xs font-bold text-black dark:text-white">
                      {formatFullDate(dayKey)}
                    </span>
                    {summary && (
                      <span className="text-[11px] text-black/60 dark:text-white/60 tabular-nums">
                        {summary.customers} customers · {formatMoney(summary.sales, currencySymbol, 'auto', countryCode)} sales
                      </span>
                    )}
                  </div>
                </div>

                {/* Day Rows */}
                <div className="rounded-3xl glass divide-y divide-[var(--separator)] overflow-hidden">
                  {dayTxs.map((tx) => {
                    const isCashIn = tx.type === 'cash_in';
                    const isCashOut = tx.type === 'cash_out';
                    const isUdhar = tx.type === 'udhar_sale' || tx.type === 'udhar_payment';

                    let icon = ArrowDownLeft;
                    let iconColor = '#34C759';
                    let iconBg = 'rgba(52,199,89,0.14)';
                    let sign = '+';
                    let amtColor = 'text-[#34C759]';

                    if (isCashOut) {
                      icon = ArrowUpRight;
                      iconColor = '#FF3B30';
                      iconBg = 'rgba(255,59,48,0.14)';
                      sign = '−';
                      amtColor = 'text-[#FF3B30] dark:text-[#FF453A]';
                    } else if (isUdhar) {
                      icon = UserCheck;
                      iconColor = '#007AFF';
                      iconBg = 'rgba(0,122,255,0.14)';
                      sign = tx.type === 'udhar_sale' ? '+' : '−';
                      amtColor = tx.type === 'udhar_sale' ? 'text-[#007AFF]' : 'text-black dark:text-white';
                    }

                    const IconComp = icon;

                    return (
                      <div
                        key={tx.id}
                        className="p-3.5 flex items-center justify-between hover:bg-black/5 dark:hover:bg-white/5 transition-colors"
                      >
                        <div className="flex items-center gap-3 min-w-0">
                          <div
                            className="w-10 h-10 rounded-full flex items-center justify-center flex-shrink-0"
                            style={{ backgroundColor: iconBg, color: iconColor }}
                          >
                            <IconComp size={20} strokeWidth={2.2} />
                          </div>

                          <div className="min-w-0">
                            <p className="text-sm font-semibold text-black dark:text-white truncate">
                              {isCashIn
                                ? `Sale · ${tx.mode.toUpperCase()}`
                                : isCashOut
                                ? tx.categoryName || 'Expense'
                                : `${tx.customerName || 'Customer'} · Udhar`}
                            </p>
                            <p className="text-[11px] text-black/50 dark:text-white/50 truncate">
                              {formatTimeOfDay(tx.ts)}
                              {tx.note ? ` · ${tx.note}` : tx.expr ? ` · ${tx.expr}` : ''}
                            </p>
                          </div>
                        </div>

                        <div className="flex items-center gap-2 flex-shrink-0 pl-2">
                          <span className={`text-sm font-bold tabular-nums ${amtColor}`}>
                            {sign}
                            {formatMoney(tx.amountMinor, currencySymbol, 'auto', countryCode)}
                          </span>

                          {/* Quick Actions */}
                          <div className="flex items-center gap-1">
                            {isCashIn && (
                              <button
                                type="button"
                                onClick={() => onOpenBill(tx)}
                                title="Share Bill"
                                className="p-1 rounded-lg text-black/50 dark:text-white/50 hover:text-black dark:hover:text-white"
                              >
                                <FileText size={15} />
                              </button>
                            )}
                            <button
                              type="button"
                              onClick={() => handleStartEdit(tx)}
                              title="Edit"
                              className="p-1 rounded-lg text-black/50 dark:text-white/50 hover:text-black dark:hover:text-white"
                            >
                              <Edit2 size={15} />
                            </button>
                            <button
                              type="button"
                              onClick={() => handleDelete(tx)}
                              title="Delete"
                              className="p-1 rounded-lg text-black/50 dark:text-white/50 hover:text-[#FF3B30]"
                            >
                              <Trash2 size={15} />
                            </button>
                          </div>
                        </div>
                      </div>
                    );
                  })}
                </div>
              </div>
            );
          })
        )}

        {/* Edit Transaction Modal */}
        {editingTx && (
          <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/60 backdrop-blur-md">
            <div className="w-full max-w-[340px] rounded-3xl glass-strong p-5 border border-[var(--glass-stroke)] space-y-4">
              <h3 className="text-base font-bold text-black dark:text-white">
                Edit Entry
              </h3>

              <div>
                <label className="text-xs text-black/60 dark:text-white/60 block mb-1">
                  Amount
                </label>
                <input
                  type="number"
                  step="0.01"
                  value={editAmount}
                  onChange={(e) => setEditAmount(e.target.value)}
                  className="w-full h-11 px-3 rounded-xl bg-black/5 dark:bg-white/10 text-black dark:text-white text-base font-bold focus:ring-1 focus:ring-[var(--accent)]"
                />
              </div>

              <div>
                <label className="text-xs text-black/60 dark:text-white/60 block mb-1">
                  Note
                </label>
                <input
                  type="text"
                  value={editNote}
                  onChange={(e) => setEditNote(e.target.value)}
                  placeholder="Optional note"
                  className="w-full h-10 px-3 rounded-xl bg-black/5 dark:bg-white/10 text-xs text-black dark:text-white focus:ring-1 focus:ring-[var(--accent)]"
                />
              </div>

              {editingTx.type === 'cash_in' && (
                <label className="flex items-center gap-2 text-xs text-black dark:text-white cursor-pointer">
                  <input
                    type="checkbox"
                    checked={editCountsAsCust}
                    onChange={(e) => setEditCountsAsCust(e.target.checked)}
                    className="rounded text-[var(--accent)]"
                  />
                  Counts as customer
                </label>
              )}

              <div className="flex gap-2 pt-2">
                <button
                  type="button"
                  onClick={() => setEditingTx(null)}
                  className="flex-1 h-10 rounded-xl bg-black/10 dark:bg-white/10 text-xs font-semibold text-black dark:text-white"
                >
                  Cancel
                </button>
                <button
                  type="button"
                  onClick={handleSaveEdit}
                  className="flex-1 h-10 rounded-xl bg-[var(--accent)] text-white text-xs font-semibold"
                >
                  Save
                </button>
              </div>
            </div>
          </div>
        )}
      </div>
    </Sheet>
  );
};
