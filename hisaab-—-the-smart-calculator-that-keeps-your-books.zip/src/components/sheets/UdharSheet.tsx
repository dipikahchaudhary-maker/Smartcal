import React, { useState, useEffect } from 'react';
import {
  Search,
  Plus,
  Phone,
  MessageCircle,
  ChevronRight,
  ChevronLeft,
  Calendar,
  AlertCircle,
  CheckCircle,
} from 'lucide-react';
import { Sheet } from '../common/Sheet.tsx';
import { UdharCustomer, Transaction, ShopProfile } from '../../types/index.ts';
import {
  getUdharCustomers,
  addUdharCustomer,
  getCustomerTransactions,
  addTransaction,
} from '../../db/repo.ts';
import { formatFullDate, formatMoney } from '../../utils/formatters.ts';
import { triggerHaptic } from '../../utils/haptics.ts';

interface UdharSheetProps {
  isOpen: boolean;
  onClose: () => void;
  currencySymbol: string;
  countryCode: string;
  profile: ShopProfile | null;
}

export const UdharSheet: React.FC<UdharSheetProps> = ({
  isOpen,
  onClose,
  currencySymbol,
  countryCode,
  profile,
}) => {
  const [customers, setCustomers] = useState<UdharCustomer[]>([]);
  const [searchQuery, setSearchQuery] = useState('');
  const [selectedCustomer, setSelectedCustomer] = useState<UdharCustomer | null>(null);
  const [customerTxs, setCustomerTxs] = useState<Transaction[]>([]);

  // Add Udhar modal state
  const [showAddModal, setShowAddModal] = useState(false);
  const [name, setName] = useState('');
  const [phone, setPhone] = useState('');
  const [address, setAddress] = useState('');
  const [item, setItem] = useState('');
  const [amount, setAmount] = useState('');
  const [dueDate, setDueDate] = useState('');
  const [note, setNote] = useState('');

  // Receive money modal state
  const [showReceiveModal, setShowReceiveModal] = useState(false);
  const [receiveAmount, setReceiveAmount] = useState('');

  useEffect(() => {
    if (!isOpen) return;
    loadCustomers();
  }, [isOpen]);

  const loadCustomers = async () => {
    const list = await getUdharCustomers();
    setCustomers(list);
  };

  const handleSelectCustomer = async (cust: UdharCustomer) => {
    triggerHaptic('selection');
    setSelectedCustomer(cust);
    const txs = await getCustomerTransactions(cust.id);
    setCustomerTxs(txs);
  };

  const handleCreateUdharSale = async (e: React.FormEvent) => {
    e.preventDefault();
    const parsedAmt = parseFloat(amount);
    if (!name.trim() || isNaN(parsedAmt) || parsedAmt <= 0) return;

    // Find or create customer
    let cust = customers.find((c) => c.name.toLowerCase() === name.trim().toLowerCase());
    if (!cust) {
      cust = await addUdharCustomer(name.trim(), phone.trim(), address.trim());
    }

    const amountMinor = Math.round(parsedAmt * 100);

    // Save as udhar_sale
    await addTransaction({
      type: 'udhar_sale',
      amountMinor,
      mode: 'udhar',
      countsAsCustomer: true,
      udharCustomerId: cust.id,
      customerName: cust.name,
      item: item.trim() || undefined,
      dueDate: dueDate || undefined,
      note: note.trim() || undefined,
    });

    triggerHaptic('success');
    setShowAddModal(false);
    resetAddForm();
    await loadCustomers();
    if (selectedCustomer?.id === cust.id) {
      handleSelectCustomer(cust);
    }
  };

  const handleReceiveMoney = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!selectedCustomer) return;
    const parsedAmt = parseFloat(receiveAmount);
    if (isNaN(parsedAmt) || parsedAmt <= 0) return;

    const amountMinor = Math.round(parsedAmt * 100);

    // Save as udhar_payment (reduces pending, doesn't count as new customer or sales)
    await addTransaction({
      type: 'udhar_payment',
      amountMinor,
      mode: 'cash',
      countsAsCustomer: false,
      udharCustomerId: selectedCustomer.id,
      customerName: selectedCustomer.name,
      note: 'Udhar payment received',
    });

    triggerHaptic('success');
    setShowReceiveModal(false);
    setReceiveAmount('');
    await loadCustomers();
    // Refresh current customer
    const updated = await getUdharCustomers();
    const c = updated.find((x) => x.id === selectedCustomer.id);
    if (c) handleSelectCustomer(c);
  };

  const resetAddForm = () => {
    setName('');
    setPhone('');
    setAddress('');
    setItem('');
    setAmount('');
    setDueDate('');
    setNote('');
  };

  const handleWhatsAppRemind = (cust: UdharCustomer) => {
    const rawPhone = cust.phone.replace(/[^0-9]/g, '');
    const cleanPhone = rawPhone.length === 10 ? `91${rawPhone}` : rawPhone;
    const pendingFormatted = formatMoney(cust.pendingMinor, currencySymbol, 'auto', countryCode);
    const shop = profile?.shopName || 'Hisaab';
    const message = encodeURIComponent(
      `Hello ${cust.name}, this is a gentle reminder from ${shop} regarding your pending balance of ${pendingFormatted}. Kindly settle it at your earliest convenience. Thank you!`
    );
    window.open(`https://wa.me/${cleanPhone}?text=${message}`, '_blank');
  };

  const filteredCustomers = customers.filter(
    (c) =>
      c.name.toLowerCase().includes(searchQuery.toLowerCase()) ||
      c.phone.includes(searchQuery)
  );

  const totalToReceiveMinor = customers.reduce((acc, c) => acc + (c.pendingMinor || 0), 0);

  return (
    <Sheet
      isOpen={isOpen}
      onClose={onClose}
      title={selectedCustomer ? selectedCustomer.name : 'Udhar'}
      onBack={selectedCustomer ? () => setSelectedCustomer(null) : undefined}
      rightAction={
        !selectedCustomer ? (
          <button
            type="button"
            onClick={() => {
              triggerHaptic('selection');
              setShowAddModal(true);
            }}
            className="w-8 h-8 rounded-full bg-[var(--accent)] text-white flex items-center justify-center cursor-pointer active:scale-90"
          >
            <Plus size={18} strokeWidth={2.5} />
          </button>
        ) : undefined
      }
    >
      <div className="space-y-4 pb-12">
        {!selectedCustomer ? (
          <>
            {/* Top Glass Card: Total to receive */}
            <div className="p-5 rounded-3xl glass text-center space-y-1">
              <span className="text-xs font-semibold tracking-wider text-black/50 dark:text-white/50 uppercase">
                Total to receive
              </span>
              <h2 className="text-3xl font-bold text-[#007AFF] tabular-nums">
                {formatMoney(totalToReceiveMinor, currencySymbol, 'auto', countryCode)}
              </h2>
              <p className="text-xs text-black/50 dark:text-white/50">
                {customers.length} people owe you money
              </p>
            </div>

            {/* Search Input */}
            <div className="relative">
              <Search
                size={16}
                className="absolute left-3.5 top-1/2 -translate-y-1/2 text-black/40 dark:text-white/40"
              />
              <input
                type="text"
                value={searchQuery}
                onChange={(e) => setSearchQuery(e.target.value)}
                placeholder="Search person or mobile…"
                className="w-full h-10 pl-9 pr-3 rounded-2xl glass text-xs text-black dark:text-white placeholder-black/40 focus:outline-none focus:ring-1 focus:ring-[var(--accent)]"
              />
            </div>

            {/* Customer List */}
            {filteredCustomers.length === 0 ? (
              <div className="py-12 text-center text-black/40 dark:text-white/40">
                <p className="text-sm font-medium">No Udhar records found.</p>
              </div>
            ) : (
              <div className="rounded-3xl glass divide-y divide-[var(--separator)] overflow-hidden">
                {filteredCustomers.map((cust) => {
                  const initials = cust.name
                    .split(' ')
                    .map((n) => n[0])
                    .join('')
                    .toUpperCase()
                    .slice(0, 2);

                  return (
                    <button
                      key={cust.id}
                      type="button"
                      onClick={() => handleSelectCustomer(cust)}
                      className="w-full p-3.5 flex items-center justify-between text-left hover:bg-black/5 dark:hover:bg-white/5 active:scale-[0.99] transition-all cursor-pointer"
                    >
                      <div className="flex items-center gap-3 min-w-0">
                        {/* Initials disc */}
                        <div className="w-10 h-10 rounded-full bg-[#007AFF]/15 text-[#007AFF] font-bold text-xs flex items-center justify-center flex-shrink-0">
                          {initials}
                        </div>
                        <div className="min-w-0">
                          <p className="text-sm font-semibold text-black dark:text-white truncate">
                            {cust.name}
                          </p>
                          <p className="text-[11px] text-black/50 dark:text-white/50 truncate">
                            {cust.phone || 'No phone'} · Last: {formatFullDate(cust.lastActivityTs)}
                          </p>
                        </div>
                      </div>

                      <div className="flex items-center gap-2 pl-2">
                        <span className="text-sm font-bold text-black dark:text-white tabular-nums">
                          {formatMoney(cust.pendingMinor, currencySymbol, 'auto', countryCode)}
                        </span>
                        <ChevronRight size={16} className="text-black/30 dark:text-white/30" />
                      </div>
                    </button>
                  );
                })}
              </div>
            )}
          </>
        ) : (
          /* Customer Detail View */
          <div className="space-y-4">
            {/* Balance Card */}
            <div className="p-5 rounded-3xl glass text-center space-y-1">
              <span className="text-xs font-semibold text-black/50 dark:text-white/50 uppercase">
                Pending Balance
              </span>
              <h2 className="text-4xl font-bold text-[#007AFF] tabular-nums">
                {formatMoney(selectedCustomer.pendingMinor, currencySymbol, 'auto', countryCode)}
              </h2>
              {selectedCustomer.phone && (
                <p className="text-xs text-black/60 dark:text-white/60">
                  {selectedCustomer.phone}
                </p>
              )}
            </div>

            {/* Actions Grid */}
            <div className="grid grid-cols-3 gap-2">
              <button
                type="button"
                onClick={() => setShowReceiveModal(true)}
                className="h-11 rounded-2xl bg-[#34C759] text-white text-xs font-semibold flex items-center justify-center gap-1 active:scale-95 shadow-sm"
              >
                <CheckCircle size={15} />
                Received
              </button>
              <button
                type="button"
                onClick={() => handleWhatsAppRemind(selectedCustomer)}
                className="h-11 rounded-2xl bg-[#25D366] text-white text-xs font-semibold flex items-center justify-center gap-1 active:scale-95 shadow-sm"
              >
                <MessageCircle size={15} />
                Remind
              </button>
              <a
                href={`tel:${selectedCustomer.phone}`}
                className="h-11 rounded-2xl glass text-black dark:text-white text-xs font-semibold flex items-center justify-center gap-1 active:scale-95"
              >
                <Phone size={15} />
                Call
              </a>
            </div>

            {/* Timeline */}
            <div className="space-y-2">
              <h4 className="text-xs font-bold text-black/50 dark:text-white/50 tracking-wider uppercase px-1">
                Timeline
              </h4>
              <div className="rounded-3xl glass divide-y divide-[var(--separator)] overflow-hidden">
                {customerTxs.map((tx) => (
                  <div key={tx.id} className="p-3.5 flex justify-between items-center text-xs">
                    <div>
                      <p className="font-semibold text-black dark:text-white">
                        {tx.type === 'udhar_sale' ? (tx.item || 'Sale on credit') : 'Payment received'}
                      </p>
                      <p className="text-[11px] text-black/50 dark:text-white/50">
                        {formatFullDate(tx.ts)}
                      </p>
                    </div>
                    <span
                      className={`font-bold tabular-nums text-sm ${
                        tx.type === 'udhar_sale' ? 'text-[#FF3B30]' : 'text-[#34C759]'
                      }`}
                    >
                      {tx.type === 'udhar_sale' ? '+' : '−'}
                      {formatMoney(tx.amountMinor, currencySymbol, 'auto', countryCode)}
                    </span>
                  </div>
                ))}
              </div>
            </div>
          </div>
        )}

        {/* Add Udhar Modal */}
        {showAddModal && (
          <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/60 backdrop-blur-md">
            <div className="w-full max-w-[340px] rounded-3xl glass-strong p-5 border border-[var(--glass-stroke)] space-y-3">
              <h3 className="text-base font-bold text-black dark:text-white">Add Udhar</h3>
              <form onSubmit={handleCreateUdharSale} className="space-y-3">
                <input
                  type="text"
                  placeholder="Customer Name *"
                  value={name}
                  onChange={(e) => setName(e.target.value)}
                  className="w-full h-10 px-3 rounded-xl bg-black/5 dark:bg-white/10 text-xs text-black dark:text-white"
                  required
                />
                <input
                  type="tel"
                  placeholder="Mobile number"
                  value={phone}
                  onChange={(e) => setPhone(e.target.value)}
                  className="w-full h-10 px-3 rounded-xl bg-black/5 dark:bg-white/10 text-xs text-black dark:text-white"
                />
                <input
                  type="number"
                  step="0.01"
                  placeholder="Amount *"
                  value={amount}
                  onChange={(e) => setAmount(e.target.value)}
                  className="w-full h-10 px-3 rounded-xl bg-black/5 dark:bg-white/10 text-xs text-black dark:text-white font-bold"
                  required
                />
                <input
                  type="text"
                  placeholder="Item / Description (Optional)"
                  value={item}
                  onChange={(e) => setItem(e.target.value)}
                  className="w-full h-10 px-3 rounded-xl bg-black/5 dark:bg-white/10 text-xs text-black dark:text-white"
                />
                <div>
                  <label className="text-[10px] text-black/50 dark:text-white/50 block mb-0.5">
                    Due Date (Optional)
                  </label>
                  <input
                    type="date"
                    value={dueDate}
                    onChange={(e) => setDueDate(e.target.value)}
                    className="w-full h-10 px-3 rounded-xl bg-black/5 dark:bg-white/10 text-xs text-black dark:text-white"
                  />
                </div>
                <div className="flex gap-2 pt-2">
                  <button
                    type="button"
                    onClick={() => setShowAddModal(false)}
                    className="flex-1 h-10 rounded-xl bg-black/10 dark:bg-white/10 text-xs font-semibold text-black dark:text-white"
                  >
                    Cancel
                  </button>
                  <button
                    type="submit"
                    className="flex-1 h-10 rounded-xl bg-[var(--accent)] text-white text-xs font-semibold"
                  >
                    Save
                  </button>
                </div>
              </form>
            </div>
          </div>
        )}

        {/* Receive Payment Modal */}
        {showReceiveModal && (
          <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/60 backdrop-blur-md">
            <div className="w-full max-w-[320px] rounded-3xl glass-strong p-5 border border-[var(--glass-stroke)] space-y-3">
              <h3 className="text-base font-bold text-black dark:text-white">Receive Money</h3>
              <form onSubmit={handleReceiveMoney} className="space-y-3">
                <input
                  type="number"
                  step="0.01"
                  placeholder="Amount received *"
                  value={receiveAmount}
                  onChange={(e) => setReceiveAmount(e.target.value)}
                  className="w-full h-11 px-3 rounded-xl bg-black/5 dark:bg-white/10 text-sm font-bold text-black dark:text-white"
                  required
                  autoFocus
                />
                <div className="flex gap-2 pt-2">
                  <button
                    type="button"
                    onClick={() => setShowReceiveModal(false)}
                    className="flex-1 h-10 rounded-xl bg-black/10 dark:bg-white/10 text-xs font-semibold text-black dark:text-white"
                  >
                    Cancel
                  </button>
                  <button
                    type="submit"
                    className="flex-1 h-10 rounded-xl bg-[#34C759] text-white text-xs font-semibold"
                  >
                    Confirm
                  </button>
                </div>
              </form>
            </div>
          </div>
        )}
      </div>
    </Sheet>
  );
};
