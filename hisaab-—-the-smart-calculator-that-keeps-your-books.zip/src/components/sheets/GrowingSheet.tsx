import React, { useState, useEffect } from 'react';
import {
  TrendingUp,
  TrendingDown,
  Minus,
  ChevronLeft,
  ChevronRight,
  Info,
} from 'lucide-react';
import {
  LineChart,
  Line,
  XAxis,
  YAxis,
  Tooltip,
  ResponsiveContainer,
} from 'recharts';
import { Sheet } from '../common/Sheet.tsx';
import { SegmentedControl } from '../common/SegmentedControl.tsx';
import { DailyRollup } from '../../types/index.ts';
import { getRollupsRange } from '../../db/repo.ts';
import {
  formatFullDate,
  formatMonthYear,
  formatYearOnly,
  formatMoney,
} from '../../utils/formatters.ts';
import { triggerHaptic } from '../../utils/haptics.ts';

interface GrowingSheetProps {
  isOpen: boolean;
  onClose: () => void;
  currencySymbol: string;
  countryCode: string;
}

type Period = 'day' | 'month' | 'year';

export const GrowingSheet: React.FC<GrowingSheetProps> = ({
  isOpen,
  onClose,
  currencySymbol,
  countryCode,
}) => {
  const [period, setPeriod] = useState<Period>('month');
  const [currentDate, setCurrentDate] = useState<Date>(new Date());
  const [currentRollups, setCurrentRollups] = useState<DailyRollup[]>([]);
  const [prevRollups, setPrevRollups] = useState<DailyRollup[]>([]);

  useEffect(() => {
    if (!isOpen) return;
    loadComparisonData();
  }, [isOpen, period, currentDate]);

  const loadComparisonData = async () => {
    if (period === 'day') {
      const todayKey = currentDate.toISOString().slice(0, 10);
      const prevDate = new Date(currentDate);
      prevDate.setDate(prevDate.getDate() - 1);
      const prevKey = prevDate.toISOString().slice(0, 10);

      const cur = await getRollupsRange(todayKey, todayKey);
      const prev = await getRollupsRange(prevKey, prevKey);
      setCurrentRollups(cur);
      setPrevRollups(prev);
    } else if (period === 'month') {
      const mPrefix = currentDate.toISOString().slice(0, 7);
      const prevDate = new Date(currentDate);
      prevDate.setMonth(prevDate.getMonth() - 1);
      const prevPrefix = prevDate.toISOString().slice(0, 7);

      // Like-for-like comparison up to the same day of month
      const maxDay = currentDate.getDate();
      const cur = await getRollupsRange(`${mPrefix}-01`, `${mPrefix}-${String(maxDay).padStart(2, '0')}`);
      const prev = await getRollupsRange(`${prevPrefix}-01`, `${prevPrefix}-${String(maxDay).padStart(2, '0')}`);
      setCurrentRollups(cur);
      setPrevRollups(prev);
    } else {
      // Year like-for-like
      const yPrefix = currentDate.toISOString().slice(0, 4);
      const prevDate = new Date(currentDate);
      prevDate.setFullYear(prevDate.getFullYear() - 1);
      const prevYear = prevDate.toISOString().slice(0, 4);

      const mm = String(currentDate.getMonth() + 1).padStart(2, '0');
      const dd = String(currentDate.getDate()).padStart(2, '0');

      const cur = await getRollupsRange(`${yPrefix}-01-01`, `${yPrefix}-${mm}-${dd}`);
      const prev = await getRollupsRange(`${prevYear}-01-01`, `${prevYear}-${mm}-${dd}`);
      setCurrentRollups(cur);
      setPrevRollups(prev);
    }
  };

  const sumTotals = (rollups: DailyRollup[]) => {
    let sales = 0, expenses = 0, customers = 0;
    rollups.forEach((r) => {
      sales += r.salesMinor;
      expenses += r.expensesMinor;
      customers += r.customers;
    });
    const profit = sales - expenses;
    const avgBill = customers > 0 ? Math.round(sales / customers) : 0;
    return { sales, expenses, profit, customers, avgBill };
  };

  const cur = sumTotals(currentRollups);
  const prev = sumTotals(prevRollups);

  // Verdict calculation according to §8.4
  const salesChangePct = prev.sales > 0 ? ((cur.sales - prev.sales) / prev.sales) * 100 : cur.sales > 0 ? 100 : 0;
  const profitChange = cur.profit - prev.profit;

  let verdictHeadline = "Not enough history yet";
  let verdictColor = '#8E8E93';
  let VerdictIcon = Minus;

  if (prev.sales === 0 && cur.sales === 0) {
    verdictHeadline = "Not enough history yet";
  } else if (prev.sales === 0) {
    verdictHeadline = "Great start!";
    verdictColor = '#34C759';
    VerdictIcon = TrendingUp;
  } else if (salesChangePct >= 3 && profitChange >= 0) {
    verdictHeadline = "Yes, you're growing";
    verdictColor = '#34C759';
    VerdictIcon = TrendingUp;
  } else if (salesChangePct >= 3 && profitChange < 0) {
    verdictHeadline = "Sales are up, profit is down";
    verdictColor = '#FF9500';
    VerdictIcon = TrendingUp;
  } else if (salesChangePct >= -3 && salesChangePct <= 3) {
    verdictHeadline = "About the same";
    verdictColor = '#8E8E93';
    VerdictIcon = Minus;
  } else {
    verdictHeadline = `Slower than last ${period}`;
    verdictColor = '#FF3B30';
    VerdictIcon = TrendingDown;
  }

  // Cumulative pace chart data
  let cumulativeCur = 0;
  let cumulativePrev = 0;
  const paceData: any[] = [];
  const maxPoints = Math.max(currentRollups.length, prevRollups.length);

  for (let i = 0; i < maxPoints; i++) {
    if (currentRollups[i]) cumulativeCur += currentRollups[i].salesMinor / 100;
    if (prevRollups[i]) cumulativePrev += prevRollups[i].salesMinor / 100;
    paceData.push({
      step: i + 1,
      current: cumulativeCur,
      previous: cumulativePrev,
    });
  }

  const comparisonRows = [
    { label: 'Sales', cur: cur.sales, prev: prev.sales, isGoodWhenUp: true },
    { label: 'Expenses', cur: cur.expenses, prev: prev.expenses, isGoodWhenUp: false },
    { label: 'Profit', cur: cur.profit, prev: prev.profit, isGoodWhenUp: true },
    { label: 'Customers', cur: cur.customers, prev: prev.customers, isGoodWhenUp: true, isNumber: true },
    { label: 'Average bill', cur: cur.avgBill, prev: prev.avgBill, isGoodWhenUp: true },
  ];

  return (
    <Sheet isOpen={isOpen} onClose={onClose} title="Is my business growing?">
      <div className="space-y-6 pb-12">
        <SegmentedControl<Period>
          value={period}
          onChange={setPeriod}
          options={[
            { id: 'day', label: 'Day' },
            { id: 'month', label: 'Month' },
            { id: 'year', label: 'Year' },
          ]}
        />

        {/* Verdict Card (Large) */}
        <div className="p-6 rounded-3xl glass text-center flex flex-col items-center">
          <div
            className="w-14 h-14 rounded-full flex items-center justify-center mb-3"
            style={{ backgroundColor: `${verdictColor}20`, color: verdictColor }}
          >
            <VerdictIcon size={28} strokeWidth={2.5} />
          </div>

          <h2 className="text-[26px] font-bold text-black dark:text-white leading-tight">
            {verdictHeadline}
          </h2>

          <p className="text-sm text-black/70 dark:text-white/70 mt-2 max-w-[280px]">
            {prev.sales > 0 ? (
              <>
                You sold {formatMoney(cur.sales, currencySymbol, 'auto', countryCode)} so far —{' '}
                {formatMoney(Math.abs(cur.sales - prev.sales), currencySymbol, 'auto', countryCode)} (
                {Math.abs(salesChangePct).toFixed(1)}%){' '}
                {cur.sales >= prev.sales ? 'more' : 'less'} than the same days of the previous period.
              </>
            ) : (
              'Record more daily transactions to compare like-for-like business growth.'
            )}
          </p>

          <span className="text-[11px] text-black/40 dark:text-white/40 mt-3">
            Like-for-like elapsed period comparison
          </span>
        </div>

        {/* Five Comparison Rows */}
        <div className="p-4 rounded-3xl glass divide-y divide-[var(--separator)]">
          {comparisonRows.map((row) => {
            const diff = row.cur - row.prev;
            const pct = row.prev > 0 ? (diff / Math.abs(row.prev)) * 100 : row.cur > 0 ? 100 : 0;
            const isUp = diff > 0;
            const isGood = row.isGoodWhenUp ? isUp : !isUp;
            const pillColor = diff === 0 ? 'text-[#8E8E93]' : isGood ? 'text-[#34C759]' : 'text-[#FF3B30]';

            return (
              <div key={row.label} className="py-2.5 flex items-center justify-between text-xs">
                <div>
                  <span className="font-semibold text-black dark:text-white text-sm block">
                    {row.label}
                  </span>
                  <span className="text-[11px] text-black/50 dark:text-white/50 tabular-nums">
                    Prev: {row.isNumber ? row.prev : formatMoney(row.prev, currencySymbol, 'auto', countryCode)}
                  </span>
                </div>

                <div className="text-right">
                  <span className="font-bold text-sm text-black dark:text-white tabular-nums block">
                    {row.isNumber ? row.cur : formatMoney(row.cur, currencySymbol, 'auto', countryCode)}
                  </span>
                  <span className={`text-[11px] font-semibold tabular-nums ${pillColor}`}>
                    {row.prev === 0 ? 'New' : `${isUp ? '▲' : '▼'} ${Math.abs(pct).toFixed(1)}%`}
                  </span>
                </div>
              </div>
            );
          })}
        </div>

        {/* Pace Chart: Cumulative Sales vs Previous */}
        {paceData.length > 0 && (
          <div className="p-4 rounded-3xl glass space-y-2">
            <h4 className="text-xs font-bold text-black/50 dark:text-white/50 tracking-wider uppercase">
              Pace (Cumulative Sales)
            </h4>
            <div className="h-44 w-full pt-2">
              <ResponsiveContainer width="100%" height="100%">
                <LineChart data={paceData}>
                  <XAxis dataKey="step" stroke="#8E8E93" fontSize={10} tickLine={false} />
                  <YAxis stroke="#8E8E93" fontSize={10} tickLine={false} axisLine={false} />
                  <Tooltip
                    contentStyle={{
                      backgroundColor: 'rgba(255,255,255,0.85)',
                      borderRadius: 14,
                    }}
                  />
                  <Line
                    type="monotone"
                    dataKey="current"
                    stroke="#34C759"
                    strokeWidth={2.5}
                    dot={false}
                  />
                  <Line
                    type="monotone"
                    dataKey="previous"
                    stroke="#8E8E93"
                    strokeWidth={1.5}
                    strokeDasharray="4 4"
                    dot={false}
                  />
                </LineChart>
              </ResponsiveContainer>
            </div>
          </div>
        )}

        {/* Explanatory note */}
        <div className="flex items-start gap-2 p-3 rounded-2xl bg-black/5 dark:bg-white/5 text-xs text-black/60 dark:text-white/60">
          <Info size={16} className="text-[var(--accent)] mt-0.5 flex-shrink-0" />
          <p>
            Like-for-like comparison matches the exact elapsed days of the current period with the same elapsed days of the previous period.
          </p>
        </div>
      </div>
    </Sheet>
  );
};
