import React, { useState } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import {
  Hand,
  Timer,
  RotateCcw,
  Receipt,
  Copy,
  MessageCircle,
  Keyboard,
  ShieldCheck,
  Sparkles,
  ChevronRight,
  ChevronDown,
  ArrowDownLeft,
  ArrowUpRight,
  Search,
} from 'lucide-react';
import { Sheet } from '../common/Sheet.tsx';
import { triggerHaptic } from '../../utils/haptics.ts';

interface ProTipsSheetProps {
  isOpen: boolean;
  onClose: () => void;
  currencySymbol: string;
}

interface TipItem {
  id: string;
  title: string;
  badge: string;
  badgeColor: string;
  icon: React.ElementType;
  iconColor: string;
  summary: string;
  detail: string;
  shortcut?: string;
  category: 'gestures' | 'counter' | 'bills' | 'system';
}

const TIPS: TipItem[] = [
  {
    id: 'swipe-delete',
    title: 'Swipe to Delete Digits',
    badge: 'Gesture',
    badgeColor: '#007AFF',
    icon: Hand,
    iconColor: '#007AFF',
    summary: 'Swipe left or right across the numbers to erase the last digit.',
    detail:
      'Just like on iOS, if you mistype a digit, you do not need to hit AC. Simply swipe your thumb across the big display numbers to backspace one digit at a time.',
    shortcut: 'Swipe Left / Right',
    category: 'gestures',
  },
  {
    id: 'hold-cash-in',
    title: 'The 4-Second Hold Cash-In Trick',
    badge: 'Counter Speed',
    badgeColor: '#34C759',
    icon: Timer,
    iconColor: '#34C759',
    summary: 'Touch & hold the green Cash In button to pick UPI, Card, or Udhar.',
    detail:
      'Normally, tapping Cash In records a quick cash sale in 1 tap. If the customer is paying by UPI, Card, or wants credit (Udhar), press and hold Cash In for 400ms to open the quick payment selector menu right at your thumb.',
    shortcut: 'Long-press [Cash In]',
    category: 'counter',
  },
  {
    id: 'one-tap-undo',
    title: '5-Second Safety Undo',
    badge: 'Safety Net',
    badgeColor: '#FF9500',
    icon: RotateCcw,
    iconColor: '#FF9500',
    summary: 'Recorded the wrong amount? Tap Undo on the toast within 5 seconds.',
    detail:
      'Whenever you record Cash In or Cash Out, a toast capsule slides in at the top. Tapping "Undo" immediately deletes the ledger entry and restores your exact calculator formula back onto the screen so you can correct it.',
    shortcut: 'Tap "Undo" on Toast',
    category: 'counter',
  },
  {
    id: 'instant-receipts',
    title: 'Instant Thermal Receipts & WhatsApp Share',
    badge: 'Customer Bills',
    badgeColor: '#5856D6',
    icon: Receipt,
    iconColor: '#5856D6',
    summary: 'Turn your counter calculation into a clean receipt slip in 1 tap.',
    detail:
      'If you added multiple items (e.g., 120 + 45 + 300), Hisaab splits them into itemized lines on a clean monochrome thermal slip. Tap "Bill" from the toast or History, then tap "Share" to send it to the customer via WhatsApp or print it.',
    shortcut: 'Tap "Bill" after sale',
    category: 'bills',
  },
  {
    id: 'copy-answer',
    title: 'Long-Press to Copy Answer',
    badge: 'Productivity',
    badgeColor: '#30B0C7',
    icon: Copy,
    iconColor: '#30B0C7',
    summary: 'Touch & hold the main calculation answer to copy the number.',
    detail:
      'Touch and hold the large final result on the display. A soft haptic tap will trigger and the clean numeric value is copied to your clipboard, ready to paste into any messaging app or invoice.',
    shortcut: 'Long-press Result',
    category: 'gestures',
  },
  {
    id: 'whatsapp-reminders',
    title: '1-Tap WhatsApp Udhar Reminders',
    badge: 'Cash Flow',
    badgeColor: '#25D366',
    icon: MessageCircle,
    iconColor: '#25D366',
    summary: 'Send polite balance reminders directly to customer WhatsApp.',
    detail:
      'In the Udhar sheet, tap "Remind" next to any customer. Hisaab automatically writes a professional, polite reminder message mentioning your shop name and their exact pending balance with a direct WhatsApp chat link.',
    shortcut: 'Tap "Remind" in Udhar',
    category: 'bills',
  },
  {
    id: 'keyboard-pos',
    title: 'Counter Keyboard & POS Shortcuts',
    badge: 'Desktop / Numpad',
    badgeColor: '#AF52DE',
    icon: Keyboard,
    iconColor: '#AF52DE',
    summary: 'Full hardware keyboard support for computers and Bluetooth numpads.',
    detail:
      'Use standard number keys 0-9, +, -, *, /, and Enter for =. Press Backspace to delete. In addition, you can press "C" for Clear/AC, "I" for Cash In, and "O" for Cash Out.',
    shortcut: 'Numpad + Enter',
    category: 'system',
  },
  {
    id: 'offline-private',
    title: '100% Offline & Private',
    badge: 'Security',
    badgeColor: '#34C759',
    icon: ShieldCheck,
    iconColor: '#34C759',
    summary: 'All shop data stays on your local device with zero cloud tracking.',
    detail:
      'Hisaab runs locally in your browser using IndexedDB. Even without Wi-Fi or cellular signal, all counter calculations, history, daily analytics, and Udhar ledgers function seamlessly.',
    shortcut: 'Always available offline',
    category: 'system',
  },
];

export const ProTipsSheet: React.FC<ProTipsSheetProps> = ({
  isOpen,
  onClose,
  currencySymbol,
}) => {
  const [activeCategory, setActiveCategory] = useState<string>('all');
  const [searchQuery, setSearchQuery] = useState('');
  const [expandedId, setExpandedId] = useState<string | null>('swipe-delete');

  const filteredTips = TIPS.filter((tip) => {
    const matchesCategory =
      activeCategory === 'all' || tip.category === activeCategory;
    const matchesSearch =
      tip.title.toLowerCase().includes(searchQuery.toLowerCase()) ||
      tip.summary.toLowerCase().includes(searchQuery.toLowerCase()) ||
      tip.detail.toLowerCase().includes(searchQuery.toLowerCase()) ||
      tip.badge.toLowerCase().includes(searchQuery.toLowerCase());
    return matchesCategory && matchesSearch;
  });

  const toggleExpand = (id: string) => {
    triggerHaptic('selection');
    setExpandedId((prev) => (prev === id ? null : id));
  };

  return (
    <Sheet isOpen={isOpen} onClose={onClose} title="Pro Tips & Tricks">
      <div className="space-y-5 pb-12">
        {/* Header Hero Banner */}
        <div className="p-4 rounded-3xl glass-strong border border-[var(--glass-stroke)] flex items-center gap-3.5 shadow-sm">
          <div className="w-11 h-11 rounded-2xl bg-[var(--accent)]/15 text-[var(--accent)] flex items-center justify-center flex-shrink-0">
            <Sparkles size={22} />
          </div>
          <div className="min-w-0 flex-1">
            <h3 className="text-sm font-bold text-black dark:text-white leading-tight">
              Master Counter Efficiency
            </h3>
            <p className="text-[11px] text-black/60 dark:text-white/60 leading-normal mt-0.5">
              Hidden shortcuts and tricks designed for fast-paced shopkeeping.
            </p>
          </div>
        </div>

        {/* Search Bar */}
        <div className="relative">
          <Search
            size={16}
            className="absolute left-3.5 top-1/2 -translate-y-1/2 text-black/40 dark:text-white/40 pointer-events-none"
          />
          <input
            type="text"
            value={searchQuery}
            onChange={(e) => setSearchQuery(e.target.value)}
            placeholder="Search shortcuts or features…"
            className="w-full h-10 pl-9 pr-3 rounded-2xl glass text-xs text-black dark:text-white placeholder-black/40 dark:placeholder-white/40 focus:outline-none focus:ring-1 focus:ring-[var(--accent)]"
          />
        </div>

        {/* Category Pill Filters */}
        <div className="flex gap-2 overflow-x-auto pb-1 no-scrollbar">
          {[
            { id: 'all', label: 'All Tips' },
            { id: 'counter', label: 'Counter Speed' },
            { id: 'gestures', label: 'Gestures' },
            { id: 'bills', label: 'Bills & Udhar' },
            { id: 'system', label: 'POS & Privacy' },
          ].map((cat) => (
            <button
              key={cat.id}
              type="button"
              onClick={() => {
                triggerHaptic('selection');
                setActiveCategory(cat.id);
              }}
              className={`px-3 py-1.5 rounded-full text-xs font-semibold whitespace-nowrap transition-all cursor-pointer ${
                activeCategory === cat.id
                  ? 'bg-[var(--accent)] text-white shadow-sm'
                  : 'glass text-black/70 dark:text-white/70 hover:text-black dark:hover:text-white'
              }`}
            >
              {cat.label}
            </button>
          ))}
        </div>

        {/* Tips Accordion Cards */}
        <div className="space-y-3">
          {filteredTips.map((tip) => {
            const IconComp = tip.icon;
            const isExpanded = expandedId === tip.id;

            return (
              <motion.div
                key={tip.id}
                layout
                className="rounded-3xl glass border border-[var(--glass-stroke)] overflow-hidden transition-shadow"
              >
                <button
                  type="button"
                  onClick={() => toggleExpand(tip.id)}
                  className="w-full p-4 flex items-start justify-between text-left cursor-pointer active:bg-black/5 dark:active:bg-white/5 transition-colors"
                >
                  <div className="flex items-start gap-3 min-w-0 pr-2">
                    <div
                      className="w-10 h-10 rounded-2xl flex items-center justify-center flex-shrink-0 mt-0.5"
                      style={{
                        backgroundColor: `${tip.iconColor}18`,
                        color: tip.iconColor,
                      }}
                    >
                      <IconComp size={20} strokeWidth={2.2} />
                    </div>

                    <div className="min-w-0">
                      <div className="flex items-center gap-2 flex-wrap mb-1">
                        <span
                          className="px-2 py-0.5 rounded-full text-[10px] font-bold uppercase tracking-wider"
                          style={{
                            backgroundColor: `${tip.badgeColor}20`,
                            color: tip.badgeColor,
                          }}
                        >
                          {tip.badge}
                        </span>
                        {tip.shortcut && (
                          <span className="text-[10px] text-black/50 dark:text-white/50 font-mono bg-black/5 dark:bg-white/10 px-1.5 py-0.5 rounded">
                            {tip.shortcut}
                          </span>
                        )}
                      </div>

                      <h4 className="text-sm font-semibold text-black dark:text-white leading-snug">
                        {tip.title}
                      </h4>
                      <p className="text-xs text-black/60 dark:text-white/60 mt-1 line-clamp-2">
                        {tip.summary}
                      </p>
                    </div>
                  </div>

                  <div className="text-black/40 dark:text-white/40 pt-1">
                    {isExpanded ? <ChevronDown size={18} /> : <ChevronRight size={18} />}
                  </div>
                </button>

                <AnimatePresence>
                  {isExpanded && (
                    <motion.div
                      initial={{ height: 0, opacity: 0 }}
                      animate={{ height: 'auto', opacity: 1 }}
                      exit={{ height: 0, opacity: 0 }}
                      transition={{ duration: 0.2 }}
                      className="px-4 pb-4 pt-1 border-t border-[var(--separator)]"
                    >
                      <p className="text-xs text-black/70 dark:text-white/70 leading-relaxed pt-2">
                        {tip.detail}
                      </p>

                      {/* Visual demonstration pill */}
                      {tip.id === 'hold-cash-in' && (
                        <div className="mt-3 p-3 rounded-2xl bg-black/5 dark:bg-white/5 flex items-center justify-between text-xs font-semibold">
                          <span className="flex items-center gap-1.5 text-[#34C759]">
                            <ArrowDownLeft size={16} /> Tap = Instant Cash
                          </span>
                          <span className="text-black/30 dark:text-white/30">•</span>
                          <span className="text-[var(--accent)]">
                            Hold = UPI / Card / Udhar
                          </span>
                        </div>
                      )}

                      {tip.id === 'swipe-delete' && (
                        <div className="mt-3 p-3 rounded-2xl bg-black/5 dark:bg-white/5 text-center text-xs text-black/70 dark:text-white/70">
                          <span className="font-mono text-sm tracking-widest font-bold text-black dark:text-white">
                            1 2 5 0 → 1 2 5
                          </span>
                          <p className="text-[10px] text-black/50 dark:text-white/50 mt-1">
                            Swipe finger horizontally on the numbers
                          </p>
                        </div>
                      )}
                    </motion.div>
                  )}
                </AnimatePresence>
              </motion.div>
            );
          })}
        </div>
      </div>
    </Sheet>
  );
};
