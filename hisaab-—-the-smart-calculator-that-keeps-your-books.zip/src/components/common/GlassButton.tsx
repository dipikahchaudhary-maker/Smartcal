import React from 'react';
import { motion, HTMLMotionProps } from 'motion/react';
import { triggerHaptic } from '../../utils/haptics.ts';

interface GlassButtonProps extends HTMLMotionProps<'button'> {
  variant?: 'neutral' | 'accent' | 'cashIn' | 'cashOut' | 'danger';
  size?: 'sm' | 'md' | 'lg' | 'capsule';
  enableHaptics?: boolean;
}

export const GlassButton: React.FC<GlassButtonProps> = ({
  variant = 'neutral',
  size = 'md',
  enableHaptics = true,
  className = '',
  children,
  onClick,
  disabled,
  ...props
}) => {
  let variantStyles = '';
  switch (variant) {
    case 'accent':
      variantStyles = 'bg-[#007AFF] dark:bg-[#0A84FF] text-white font-semibold shadow-md active:bg-[#0062CC]';
      break;
    case 'cashIn':
      variantStyles =
        'bg-[rgba(52,199,89,0.18)] dark:bg-[rgba(48,209,88,0.22)] border-[0.5px] border-[#34C759]/40 text-[#1E8E3E] dark:text-[#30D158] font-semibold';
      break;
    case 'cashOut':
      variantStyles =
        'bg-[rgba(255,59,48,0.18)] dark:bg-[rgba(255,69,58,0.22)] border-[0.5px] border-[#FF3B30]/40 text-[#D70015] dark:text-[#FF453A] font-semibold';
      break;
    case 'danger':
      variantStyles = 'bg-[#FF3B30] dark:bg-[#FF453A] text-white font-semibold';
      break;
    case 'neutral':
    default:
      variantStyles = 'glass text-black dark:text-white font-medium';
      break;
  }

  let sizeStyles = '';
  switch (size) {
    case 'sm':
      sizeStyles = 'h-9 px-3.5 text-xs rounded-xl';
      break;
    case 'lg':
      sizeStyles = 'h-14 px-6 text-lg rounded-2xl';
      break;
    case 'capsule':
      sizeStyles = 'h-11 px-5 text-sm rounded-full';
      break;
    case 'md':
    default:
      sizeStyles = 'h-12 px-5 text-base rounded-2xl';
      break;
  }

  const handleClick = (e: React.MouseEvent<HTMLButtonElement>) => {
    if (disabled) return;
    if (enableHaptics) {
      triggerHaptic('key');
    }
    onClick?.(e);
  };

  return (
    <motion.button
      whileTap={disabled ? undefined : { scale: 0.95 }}
      transition={{ type: 'spring', stiffness: 520, damping: 34, mass: 0.9 }}
      onClick={handleClick}
      disabled={disabled}
      className={`relative inline-flex items-center justify-center transition-opacity select-none cursor-pointer disabled:opacity-40 disabled:cursor-not-allowed ${variantStyles} ${sizeStyles} ${className}`}
      {...props}
    >
      {children}
    </motion.button>
  );
};
