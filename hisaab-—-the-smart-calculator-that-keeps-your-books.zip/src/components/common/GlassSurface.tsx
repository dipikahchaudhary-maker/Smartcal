import React from 'react';

interface GlassSurfaceProps extends React.HTMLAttributes<HTMLDivElement> {
  variant?: 'normal' | 'strong' | 'subtle';
  className?: string;
  children?: React.ReactNode;
}

export const GlassSurface: React.FC<GlassSurfaceProps> = ({
  variant = 'normal',
  className = '',
  children,
  ...props
}) => {
  const variantClass =
    variant === 'strong'
      ? 'glass-strong'
      : variant === 'subtle'
      ? 'bg-[var(--glass-fill)] border-[0.5px] border-[var(--glass-stroke)] shadow-sm'
      : 'glass';

  return (
    <div
      className={`rounded-3xl ${variantClass} ${className}`}
      {...props}
    >
      {children}
    </div>
  );
};
