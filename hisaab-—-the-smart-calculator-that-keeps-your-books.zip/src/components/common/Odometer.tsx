import React, { useEffect, useState } from 'react';
import { motion, AnimatePresence } from 'motion/react';

interface OdometerProps {
  value: string;
  className?: string;
  reduceMotion?: boolean;
}

export const Odometer: React.FC<OdometerProps> = ({
  value,
  className = '',
  reduceMotion = false,
}) => {
  const characters = value.split('');

  if (reduceMotion) {
    return <span className={`tabular-nums ${className}`}>{value}</span>;
  }

  return (
    <span className={`inline-flex items-baseline tabular-nums overflow-hidden ${className}`}>
      {characters.map((char, index) => {
        // If it's a digit, roll it smoothly
        if (/[0-9]/.test(char)) {
          return <OdometerDigit key={`${index}-${char}`} digit={char} />;
        }
        return <span key={index}>{char}</span>;
      })}
    </span>
  );
};

const OdometerDigit: React.FC<{ digit: string }> = ({ digit }) => {
  return (
    <span className="relative inline-block h-[1.15em] overflow-hidden leading-none">
      <AnimatePresence mode="popLayout" initial={false}>
        <motion.span
          key={digit}
          initial={{ y: '70%', opacity: 0 }}
          animate={{ y: '0%', opacity: 1 }}
          exit={{ y: '-70%', opacity: 0 }}
          transition={{ type: 'spring', stiffness: 520, damping: 36, mass: 0.8 }}
          className="inline-block"
        >
          {digit}
        </motion.span>
      </AnimatePresence>
    </span>
  );
};
