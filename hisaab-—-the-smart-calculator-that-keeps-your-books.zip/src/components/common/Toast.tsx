import React, { useEffect, useState } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import { RotateCcw, FileText, X } from 'lucide-react';

export interface ToastData {
  id: string;
  title: string;
  subtitle?: string;
  onUndo?: () => void;
  onBill?: () => void;
  duration?: number; // ms, default 5000
}

interface ToastProps {
  toast: ToastData | null;
  onDismiss: () => void;
}

export const Toast: React.FC<ToastProps> = ({ toast, onDismiss }) => {
  const [progress, setProgress] = useState(1);

  useEffect(() => {
    if (!toast) return;

    const duration = toast.duration || 5000;
    const startTime = Date.now();

    const interval = setInterval(() => {
      const elapsed = Date.now() - startTime;
      const remaining = Math.max(0, 1 - elapsed / duration);
      setProgress(remaining);
      if (remaining <= 0) {
        clearInterval(interval);
        onDismiss();
      }
    }, 50);

    return () => clearInterval(interval);
  }, [toast, onDismiss]);

  return (
    <AnimatePresence>
      {toast && (
        <motion.div
          key={toast.id}
          initial={{ y: -60, opacity: 0, scale: 0.95 }}
          animate={{ y: 0, opacity: 1, scale: 1 }}
          exit={{ y: -60, opacity: 0, scale: 0.95 }}
          drag="y"
          dragConstraints={{ top: 0, bottom: 0 }}
          onDragEnd={(_, info) => {
            if (info.offset.y < -20) {
              onDismiss();
            }
          }}
          transition={{ type: 'spring', stiffness: 520, damping: 34, mass: 0.9 }}
          className="fixed top-16 left-4 right-4 z-50 flex items-center justify-between p-3.5 rounded-2xl glass-strong shadow-xl border-[0.5px] border-[var(--glass-stroke)] max-w-[400px] mx-auto select-none"
        >
          <div className="flex-1 pr-3 truncate">
            <p className="text-sm font-semibold text-black dark:text-white truncate">
              {toast.title}
            </p>
            {toast.subtitle && (
              <p className="text-xs text-black/60 dark:text-white/60 truncate mt-0.5">
                {toast.subtitle}
              </p>
            )}
          </div>

          <div className="flex items-center gap-2">
            {toast.onBill && (
              <button
                type="button"
                onClick={() => {
                  toast.onBill?.();
                  onDismiss();
                }}
                className="flex items-center gap-1.5 px-3 py-1.5 rounded-xl bg-black/5 dark:bg-white/10 text-xs font-semibold text-black dark:text-white hover:bg-black/10 active:scale-95 transition-all cursor-pointer"
              >
                <FileText size={14} strokeWidth={2} />
                Bill
              </button>
            )}

            {toast.onUndo && (
              <button
                type="button"
                onClick={() => {
                  toast.onUndo?.();
                  onDismiss();
                }}
                className="relative flex items-center gap-1.5 px-3 py-1.5 rounded-xl bg-[var(--accent)] text-white text-xs font-semibold active:scale-95 transition-all cursor-pointer overflow-hidden"
              >
                <RotateCcw size={13} strokeWidth={2.2} />
                Undo
                {/* 5s Countdown stroke progress indicator */}
                <svg className="absolute inset-0 w-full h-full pointer-events-none" preserveAspectRatio="none">
                  <rect
                    x="1"
                    y="1"
                    width="96%"
                    height="90%"
                    rx="10"
                    fill="none"
                    stroke="rgba(255,255,255,0.4)"
                    strokeWidth="2"
                    strokeDasharray="160"
                    strokeDashoffset={160 * (1 - progress)}
                  />
                </svg>
              </button>
            )}

            <button
              type="button"
              onClick={onDismiss}
              className="p-1 text-black/40 dark:text-white/40 hover:text-black dark:hover:text-white"
            >
              <X size={16} />
            </button>
          </div>
        </motion.div>
      )}
    </AnimatePresence>
  );
};
