import React from 'react';
import { motion } from 'motion/react';
import { triggerHaptic } from '../../utils/haptics.ts';

interface SegmentOption<T extends string> {
  id: T;
  label: string;
}

interface SegmentedControlProps<T extends string> {
  options: SegmentOption<T>[];
  value: T;
  onChange: (val: T) => void;
  className?: string;
  enableHaptics?: boolean;
}

export function SegmentedControl<T extends string>({
  options,
  value,
  onChange,
  className = '',
  enableHaptics = true,
}: SegmentedControlProps<T>) {
  return (
    <div
      className={`relative flex items-center p-1 rounded-full bg-[rgba(120,120,128,0.14)] dark:bg-[rgba(120,120,128,0.26)] backdrop-blur-md ${className}`}
    >
      {options.map((option) => {
        const isSelected = option.id === value;
        return (
          <button
            key={option.id}
            type="button"
            onClick={() => {
              if (enableHaptics && option.id !== value) {
                triggerHaptic('selection');
              }
              onChange(option.id);
            }}
            className={`relative flex-1 py-1.5 px-3 text-xs sm:text-sm font-semibold text-center select-none cursor-pointer z-10 transition-colors ${
              isSelected
                ? 'text-black dark:text-white'
                : 'text-black/60 dark:text-white/60 hover:text-black dark:hover:text-white'
            }`}
          >
            {isSelected && (
              <motion.div
                layoutId="segmented-pill"
                transition={{ type: 'spring', stiffness: 520, damping: 34, mass: 0.9 }}
                className="absolute inset-0 rounded-full bg-white dark:bg-[#636366] shadow-[0_1px_3px_rgba(0,0,0,0.12),0_1px_2px_rgba(0,0,0,0.06)] z-[-1]"
              />
            )}
            {option.label}
          </button>
        );
      })}
    </div>
  );
}
