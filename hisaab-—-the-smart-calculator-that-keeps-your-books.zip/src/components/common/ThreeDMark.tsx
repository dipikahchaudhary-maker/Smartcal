import React, { useEffect, useRef } from 'react';
import * as THREE from 'three';

interface ThreeDMarkProps {
  className?: string;
  size?: number;
  interactive?: boolean;
}

export const ThreeDMark: React.FC<ThreeDMarkProps> = ({
  className = '',
  size = 110,
  interactive = true,
}) => {
  const containerRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    const container = containerRef.current;
    if (!container) return;

    // Scene
    const scene = new THREE.Scene();

    // Camera
    const camera = new THREE.PerspectiveCamera(40, 1, 0.1, 1000);
    camera.position.z = 3.6;

    // Renderer
    const renderer = new THREE.WebGLRenderer({ alpha: true, antialias: true });
    renderer.setSize(size, size);
    renderer.setPixelRatio(Math.min(window.devicePixelRatio, 2));
    renderer.shadowMap.enabled = true;
    container.appendChild(renderer.domElement);

    // Group holding the 3D Apple Glass token
    const group = new THREE.Group();
    scene.add(group);

    // Rounded Box / Glass Token
    // We create a custom smooth squircle bevel shape
    const shape = new THREE.Shape();
    const width = 1.35;
    const height = 1.35;
    const radius = 0.38;
    const x = -width / 2;
    const y = -height / 2;

    shape.moveTo(x + radius, y);
    shape.lineTo(x + width - radius, y);
    shape.quadraticCurveTo(x + width, y, x + width, y + radius);
    shape.lineTo(x + width, y + height - radius);
    shape.quadraticCurveTo(x + width, y + height, x + width - radius, y + height);
    shape.lineTo(x + radius, y + height);
    shape.quadraticCurveTo(x, y + height, x, y + height - radius);
    shape.lineTo(x, y + radius);
    shape.quadraticCurveTo(x, y, x + radius, y);

    const extrudeSettings = {
      steps: 2,
      depth: 0.28,
      bevelEnabled: true,
      bevelThickness: 0.08,
      bevelSize: 0.08,
      bevelSegments: 5,
    };

    const geometry = new THREE.ExtrudeGeometry(shape, extrudeSettings);
    geometry.center();

    // Physical Glass Material (Liquid Glass look)
    const glassMaterial = new THREE.MeshPhysicalMaterial({
      color: 0xffffff,
      transmission: 0.88,
      opacity: 1,
      transparent: true,
      roughness: 0.06,
      ior: 1.52,
      reflectivity: 0.5,
      metalness: 0.02,
      clearcoat: 1.0,
      clearcoatRoughness: 0.04,
    });

    const mesh = new THREE.Mesh(geometry, glassMaterial);
    group.add(mesh);

    // Add glowing keypad glyph inside: 2x2 grid of dots with bold '='
    const dotGeo = new THREE.CylinderGeometry(0.06, 0.06, 0.04, 16);
    dotGeo.rotateX(Math.PI / 2);
    const glyphMaterial = new THREE.MeshStandardMaterial({
      color: 0x007aff,
      roughness: 0.2,
      metalness: 0.1,
    });

    // 2x2 dots
    const dotPositions = [
      [-0.22, 0.20],
      [0.22, 0.20],
      [-0.22, -0.02],
      [0.22, -0.02],
    ];

    dotPositions.forEach(([dx, dy]) => {
      const dot = new THREE.Mesh(dotGeo, glyphMaterial);
      dot.position.set(dx, dy, 0.16);
      group.add(dot);
    });

    // Bold '=' bar meshes
    const barGeo = new THREE.BoxGeometry(0.48, 0.08, 0.04);
    const bar1 = new THREE.Mesh(barGeo, glyphMaterial);
    bar1.position.set(0, -0.22, 0.16);
    group.add(bar1);

    const bar2 = new THREE.Mesh(barGeo, glyphMaterial);
    bar2.position.set(0, -0.34, 0.16);
    group.add(bar2);

    // Lights for pristine specular rim
    const ambientLight = new THREE.AmbientLight(0xffffff, 0.9);
    scene.add(ambientLight);

    const keyLight = new THREE.DirectionalLight(0xffffff, 1.8);
    keyLight.position.set(3, 4, 5);
    scene.add(keyLight);

    const rimLight = new THREE.DirectionalLight(0x007aff, 1.4);
    rimLight.position.set(-3, -3, 2);
    scene.add(rimLight);

    const topSpecular = new THREE.PointLight(0xffffff, 1.2, 10);
    topSpecular.position.set(0, 3, 2);
    scene.add(topSpecular);

    // Idle drifting motion & interactive tilt
    let mouseX = 0;
    let mouseY = 0;
    let targetRotX = 0;
    let targetRotY = 0;
    let clock = new THREE.Clock();

    const handlePointerMove = (e: PointerEvent) => {
      if (!interactive) return;
      const rect = container.getBoundingClientRect();
      const xNorm = ((e.clientX - rect.left) / rect.width) * 2 - 1;
      const yNorm = -(((e.clientY - rect.top) / rect.height) * 2 - 1);
      mouseX = xNorm;
      mouseY = yNorm;
    };

    if (interactive) {
      window.addEventListener('pointermove', handlePointerMove);
    }

    let animFrame: number;
    const animate = () => {
      animFrame = requestAnimationFrame(animate);
      const elapsedTime = clock.getElapsedTime();

      // Gentle floating / breathing
      const idleY = Math.sin(elapsedTime * 1.2) * 0.14;
      const idleX = Math.cos(elapsedTime * 0.9) * 0.10;
      const idleScale = 1 + Math.sin(elapsedTime * 0.8) * 0.02;

      targetRotY = mouseX * 0.45 + idleY;
      targetRotX = -mouseY * 0.45 + idleX;

      group.rotation.y += (targetRotY - group.rotation.y) * 0.08;
      group.rotation.x += (targetRotX - group.rotation.x) * 0.08;
      group.scale.set(idleScale, idleScale, idleScale);

      renderer.render(scene, camera);
    };

    animate();

    return () => {
      cancelAnimationFrame(animFrame);
      if (interactive) {
        window.removeEventListener('pointermove', handlePointerMove);
      }
      geometry.dispose();
      glassMaterial.dispose();
      glyphMaterial.dispose();
      renderer.dispose();
      if (container.contains(renderer.domElement)) {
        container.removeChild(renderer.domElement);
      }
    };
  }, [size, interactive]);

  return (
    <div
      ref={containerRef}
      className={`relative flex items-center justify-center select-none ${className}`}
      style={{ width: size, height: size }}
    />
  );
};
