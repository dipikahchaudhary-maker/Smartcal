import React, { useRef, useState } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import { ChevronLeft } from 'lucide-react';
import { triggerHaptic } from '../../utils/haptics.ts';

interface SheetProps {
  isOpen: boolean;
  onClose: () => void;
  title: string;
  onBack?: () => void;
  rightAction?: React.ReactNode;
  children: React.ReactNode;
  maxHeight?: string;
  enableHaptics?: boolean;
}

export const Sheet: React.FC<SheetProps> = ({
  isOpen,
  onClose,
  title,
  onBack,
  rightAction,
  children,
  maxHeight = 'h-[92dvh]',
  enableHaptics = true,
}) => {
  const [isScrolled, setIsScrolled] = useState(false);
  const scrollRef = useRef<HTMLDivElement>(null);

  const handleScroll = (e: React.UIEvent<HTMLDivElement>) => {
    const scrollTop = e.currentTarget.scrollTop;
    if (scrollTop > 38 && !isScrolled) {
      setIsScrolled(true);
    } else if (scrollTop <= 38 && isScrolled) {
      setIsScrolled(false);
    }
  };

  const handleClose = () => {
    if (enableHaptics) triggerHaptic('selection');
    onClose();
  };

  return (
    <AnimatePresence>
      {isOpen && (
        <div className="fixed inset-0 z-50 flex items-end justify-center pointer-events-auto">
          {/* Dimmed backdrop */}
          <motion.div
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            exit={{ opacity: 0 }}
            onClick={handleClose}
            className="fixed inset-0 bg-black/40 backdrop-blur-sm"
          />

          {/* Interactive Sheet Container */}
          <motion.div
            initial={{ y: '100%' }}
            animate={{ y: 0 }}
            exit={{ y: '100%' }}
            drag="y"
            dragConstraints={{ top: 0 }}
            dragElastic={0.18}
            onDragEnd={(_, info) => {
              if (info.offset.y > 100 || info.velocity.y > 450) {
                handleClose();
              }
            }}
            transition={{ type: 'spring', stiffness: 300, damping: 32 }}
            className={`relative w-full max-w-[430px] ${maxHeight} rounded-t-[36px] glass-strong shadow-2xl flex flex-col overflow-hidden border-t border-[var(--glass-stroke)] pb-[env(safe-area-inset-bottom,16px)]`}
          >
            {/* Grabber Bar */}
            <div className="w-full flex items-center justify-center pt-3 pb-1 cursor-grab active:cursor-grabbing">
              <div className="w-10 h-1.5 rounded-full bg-black/25 dark:bg-white/30" />
            </div>

            {/* Collapsing Glass Top Bar */}
            <div
              className={`sticky top-0 z-20 flex items-center justify-between px-5 py-2.5 transition-all duration-200 ${
                isScrolled
                  ? 'bg-[var(--glass-fill-strong)] backdrop-blur-xl border-b border-[var(--separator)]'
                  : 'bg-transparent'
              }`}
            >
              <div className="flex items-center gap-2">
                {onBack && (
                  <button
                    type="button"
                    onClick={() => {
                      if (enableHaptics) triggerHaptic('selection');
                      onBack();
                    }}
                    className="p-1 -ml-2 rounded-full text-[var(--accent)] hover:bg-black/5 dark:hover:bg-white/10"
                  >
                    <ChevronLeft size={24} strokeWidth={2.2} />
                  </button>
                )}
                {/* Collapsed inline title */}
                <h3
                  className={`text-[17px] font-semibold text-black dark:text-white transition-opacity duration-200 ${
                    isScrolled ? 'opacity-100' : 'opacity-0'
                  }`}
                >
                  {title}
                </h3>
              </div>

              {/* Right Action: Done or custom */}
              <div>
                {rightAction ? (
                  rightAction
                ) : (
                  <button
                    type="button"
                    onClick={handleClose}
                    className="text-[17px] font-semibold text-[var(--accent)] hover:opacity-80 active:scale-95 transition-all cursor-pointer px-1 py-0.5"
                  >
                    Done
                  </button>
                )}
              </div>
            </div>

            {/* Scrollable Content */}
            <div
              ref={scrollRef}
              onScroll={handleScroll}
              className="flex-1 overflow-y-auto px-5 pb-8 overscroll-contain no-scrollbar"
            >
              {/* Large Title Header */}
              <div className="pt-1 pb-4">
                <h1 className="text-[32px] font-bold tracking-tight text-black dark:text-white">
                  {title}
                </h1>
              </div>

              {children}
            </div>
          </motion.div>
        </div>
      )}
    </AnimatePresence>
  );
};
