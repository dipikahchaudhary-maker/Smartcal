export type TransactionType = 'cash_in' | 'cash_out' | 'udhar_sale' | 'udhar_payment';
export type PaymentMode = 'cash' | 'upi' | 'card' | 'udhar';

export interface Transaction {
  id: string;
  type: TransactionType;
  amountMinor: number; // exact integer minor units (paise / cents)
  ts: number;
  dayKey: string; // YYYY-MM-DD
  hour: number; // 0-23
  categoryId?: string;
  categoryName?: string;
  mode: PaymentMode;
  note?: string;
  expr?: string;
  countsAsCustomer: boolean;
  udharCustomerId?: string;
  customerName?: string;
  item?: string;
  dueDate?: string; // YYYY-MM-DD
  deleted?: boolean;
  isSample?: boolean;
  createdAt: number;
  updatedAt: number;
}

export interface Category {
  id: string;
  name: string;
  icon: string;
  color: string;
  order: number;
  archived: boolean;
  createdAt: number;
  lastUsedAt?: number;
  recentAmountsMinor: number[];
}

export interface UdharCustomer {
  id: string;
  name: string;
  phone: string;
  address?: string;
  createdAt: number;
  lastActivityTs: number;
  pendingMinor: number;
}

export interface DailyRollup {
  dayKey: string; // YYYY-MM-DD
  salesMinor: number;
  expensesMinor: number;
  customers: number;
  txCount: number;
  udharGivenMinor: number;
  udharReceivedMinor: number;
  byCategory: Record<string, number>;
  byHour: Record<number, { salesMinor: number; customers: number }>;
  byMode: Record<PaymentMode, number>;
}

export interface ShopProfile {
  name: string;
  age: number;
  shopName: string;
  businessType: string;
  mobileE164: string;
  country: string;
  countryCode: string;
  state: string;
  city: string;
  address?: string;
  upiId?: string;
  currency: string;
  currencySymbol: string;
  createdAt: number;
  onboardingDone: boolean;
}

export interface UserSettings {
  theme: 'dark';
  haptics: boolean;
  sounds: boolean;
  keepAwake: boolean;
  dayStartMinutes: number; // e.g. 0 = 12:00 AM, 240 = 4:00 AM
  chipMode: 'sales' | 'profit';
  hideEarnings: boolean;
  dailyGoalMinor: number | null;
  numberFormat: 'auto' | 'indian' | 'international';
  reduceMotion: boolean;
  hintsShown: {
    holdCashIn?: boolean;
  };
}

export type SheetType = 
  | null
  | 'menu'
  | 'cash_out_picker'
  | 'analytics'
  | 'growing'
  | 'money_made'
  | 'history'
  | 'udhar'
  | 'categories_manager'
  | 'reports'
  | 'settings'
  | 'pro_tips'
  | 'bill_view'
  | 'upi_qr'
  | 'udhar_add'
  | 'udhar_detail'
  | 'transaction_edit';
