export const APP_NAME = 'Hisaab';
export const APP_TAGLINE = 'The calculator that keeps your books.';

export const STRINGS = {
  appName: APP_NAME,
  tagline: APP_TAGLINE,
  getStarted: 'Get Started',
  noAccountNeeded: 'No account needed.',
  onboardingBenefit1: 'Tap Cash In or Cash Out — we keep the hisaab.',
  onboardingBenefit2: 'See sales, expenses and customers at a glance.',
  onboardingBenefit3: 'Private to you. Works without internet.',
  
  setupTitle: 'Set up your shop',
  setupSubtitle: 'Takes about 30 seconds.',
  continue: 'Continue',
  settingUp: 'Setting up your shop…',
  
  cashIn: 'Cash In',
  cashOut: 'Cash Out',
  today: 'TODAY',
  customers: 'Customers',
  sales: 'Sales',
  expenses: 'Expenses',
  profit: 'Profit',
  averageBill: 'Avg. Bill',
  
  copied: 'Copied',
  cantDivideByZero: "Can't divide by zero",
  
  holdHint: 'Hold Cash In for UPI, Card or Udhar',
  
  whatWasThisFor: 'What was this for?',
  addNote: 'Add a note',
  usual: 'Usual',
  newOption: 'New',
  edit: 'Edit',
  done: 'Done',
  
  analytics: 'Analytics',
  history: 'History',
  menu: 'Menu',
  udhar: 'Udhar',
  options: 'Cash Out options',
  reports: 'Reports & Backup',
  settings: 'Settings',
  
  isMyBusinessGrowing: 'Is my business growing?',
  howMuchMoneyDidIMake: 'How much money did I make?',
  
  daily: 'Daily',
  monthly: 'Monthly',
  yearly: 'Yearly',
  compare: 'Compare',
  snapshot: 'Snapshot',
  salesVsExpenses: 'Sales vs Expenses',
  whereTheMoneyWent: 'Where the money went',
  busiestHours: 'Busiest hours',
  paymentMethods: 'Payment methods',
  bestDays: 'Best days',
  exportCsv: 'Export this view (CSV)',
  
  undo: 'Undo',
  bill: 'Bill',
  shareBill: 'Share bill',
  remindWhatsApp: 'Remind on WhatsApp',
  call: 'Call',
  receivedMoney: 'Received money',
  addUdhar: 'Add Udhar',
  totalToReceive: 'Total to receive',
  
  eraseAllData: 'Erase All Data',
  useSampleData: 'Use sample data',
  removeSampleData: 'Remove sample data',
  backup: 'Backup',
  restore: 'Restore',
  
  privacyNote: 'Your data stays on your device and syncs securely. No third parties have access.',
};
