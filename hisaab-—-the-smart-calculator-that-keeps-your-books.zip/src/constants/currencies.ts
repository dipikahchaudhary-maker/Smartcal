export interface CurrencyOption {
  code: string;
  symbol: string;
  name: string;
  flag: string;
  defaultCountryCode: string;
}

export const SUPPORTED_CURRENCIES: CurrencyOption[] = [
  { code: 'INR', symbol: '₹', name: 'Indian Rupee (INR)', flag: '🇮🇳', defaultCountryCode: 'IN' },
  { code: 'USD', symbol: '$', name: 'US Dollar (USD)', flag: '🇺🇸', defaultCountryCode: 'US' },
  { code: 'CAD', symbol: 'CA$', name: 'Canadian Dollar (CAD)', flag: '🇨🇦', defaultCountryCode: 'CA' },
  { code: 'GBP', symbol: '£', name: 'British Pound (GBP)', flag: '🇬🇧', defaultCountryCode: 'GB' },
  { code: 'EUR', symbol: '€', name: 'Euro (EUR)', flag: '🇪🇺', defaultCountryCode: 'EU' },
  { code: 'AED', symbol: 'AED ', name: 'UAE Dirham (AED)', flag: '🇦🇪', defaultCountryCode: 'AE' },
];

export const COUNTRY_DEFAULTS: Record<
  string,
  { countryCode: string; currency: string; symbol: string; state: string; city: string }
> = {
  India: {
    countryCode: 'IN',
    currency: 'INR',
    symbol: '₹',
    state: 'Maharashtra',
    city: 'Mumbai',
  },
  'United States': {
    countryCode: 'US',
    currency: 'USD',
    symbol: '$',
    state: 'California',
    city: 'San Francisco',
  },
  Canada: {
    countryCode: 'CA',
    currency: 'CAD',
    symbol: 'CA$',
    state: 'Ontario',
    city: 'Toronto',
  },
  'United Kingdom': {
    countryCode: 'GB',
    currency: 'GBP',
    symbol: '£',
    state: 'England',
    city: 'London',
  },
  'United Arab Emirates': {
    countryCode: 'AE',
    currency: 'AED',
    symbol: 'AED ',
    state: 'Dubai',
    city: 'Dubai',
  },
};
