import { Category } from '../types/index.ts';

export interface DefaultCategoryTemplate {
  name: string;
  icon: string;
  color: string; // one of 8 muted Apple colors: 'blue' | 'green' | 'indigo' | 'teal' | 'purple' | 'pink' | 'yellow' | 'mint' | 'orange'
}

export const BASE_CATEGORIES: DefaultCategoryTemplate[] = [
  { name: 'Staff Salary', icon: 'Users', color: 'indigo' },
  { name: 'Light Bill', icon: 'Zap', color: 'yellow' },
  { name: 'Packing', icon: 'Package', color: 'orange' },
  { name: 'Rent', icon: 'Building', color: 'blue' },
  { name: 'Transport', icon: 'Truck', color: 'teal' },
  { name: 'Tea & Snacks', icon: 'Coffee', color: 'mint' },
  { name: 'Repairs', icon: 'Wrench', color: 'pink' },
  { name: 'Phone & Internet', icon: 'Wifi', color: 'purple' },
  { name: 'Other', icon: 'MoreHorizontal', color: 'neutral' },
];

export const BUSINESS_TYPE_CATEGORIES: Record<string, DefaultCategoryTemplate[]> = {
  'Grocery / Kirana': [
    { name: 'Stock / Inventory', icon: 'ShoppingBag', color: 'teal' },
  ],
  'General Store': [
    { name: 'Stock / Inventory', icon: 'ShoppingBag', color: 'teal' },
  ],
  'Restaurant / Café': [
    { name: 'Ingredients', icon: 'Utensils', color: 'orange' },
    { name: 'Gas / Fuel', icon: 'Flame', color: 'pink' },
  ],
  'Bakery & Sweets': [
    { name: 'Ingredients', icon: 'Cookie', color: 'orange' },
    { name: 'Gas / Fuel', icon: 'Flame', color: 'pink' },
  ],
  'Clothing & Fashion': [
    { name: 'Stock / Inventory', icon: 'Tag', color: 'purple' },
    { name: 'Alterations', icon: 'Scissors', color: 'indigo' },
  ],
  'Pharmacy': [
    { name: 'Stock / Medicines', icon: 'Pill', color: 'mint' },
  ],
  'Electronics & Mobile': [
    { name: 'Stock / Inventory', icon: 'Smartphone', color: 'blue' },
    { name: 'Spare Parts', icon: 'Cpu', color: 'indigo' },
  ],
  'Salon & Beauty': [
    { name: 'Products & Supplies', icon: 'Sparkles', color: 'pink' },
  ],
  'Vegetables & Fruits': [
    { name: 'Mandi Purchase', icon: 'Apple', color: 'green' },
  ],
  'Stationery & Books': [
    { name: 'Stock / Inventory', icon: 'BookOpen', color: 'teal' },
  ],
  'Hardware': [
    { name: 'Stock / Inventory', icon: 'Hammer', color: 'orange' },
  ],
  'Other': [
    { name: 'Stock / Inventory', icon: 'Layers', color: 'teal' },
  ],
};

export const COLOR_OPTIONS = [
  { id: 'indigo', lightBg: '#EEF0FD', lightColor: '#5856D6', darkBg: '#2A294A', darkColor: '#5E5CE6' },
  { id: 'teal', lightBg: '#E8F7FA', lightColor: '#30B0C7', darkBg: '#1B3B42', darkColor: '#40C8E0' },
  { id: 'purple', lightBg: '#F6ECFA', lightColor: '#AF52DE', darkBg: '#3C2547', darkColor: '#BF5AF2' },
  { id: 'pink', lightBg: '#FFEBF0', lightColor: '#FF2D55', darkBg: '#471B26', darkColor: '#FF375F' },
  { id: 'yellow', lightBg: '#FEF9E6', lightColor: '#E5B800', darkBg: '#473E1B', darkColor: '#FFD60A' },
  { id: 'mint', lightBg: '#E6FAF8', lightColor: '#00B5AD', darkBg: '#18423F', darkColor: '#63E6E2' },
  { id: 'orange', lightBg: '#FFF4E5', lightColor: '#FF9500', darkBg: '#472F18', darkColor: '#FF9F0A' },
  { id: 'blue', lightBg: '#EBF4FF', lightColor: '#007AFF', darkBg: '#1B2E4A', darkColor: '#0A84FF' },
];

export const AVAILABLE_ICONS = [
  'Users', 'Zap', 'Package', 'Building', 'Truck', 'Coffee', 'Wrench', 'Wifi',
  'ShoppingBag', 'Utensils', 'Flame', 'Cookie', 'Tag', 'Scissors', 'Pill',
  'Smartphone', 'Cpu', 'Sparkles', 'Apple', 'BookOpen', 'Hammer', 'Layers',
  'FileText', 'CreditCard'
];

export function getInitialCategoriesForBusinessType(businessType: string): Category[] {
  const specific = BUSINESS_TYPE_CATEGORIES[businessType] || BUSINESS_TYPE_CATEGORIES['Other'];
  const allTemplates = [...specific, ...BASE_CATEGORIES];
  
  return allTemplates.map((item, idx) => ({
    id: `cat_${idx + 1}_${item.name.toLowerCase().replace(/[^a-z0-9]/g, '_')}`,
    name: item.name,
    icon: item.icon,
    color: item.color,
    order: idx,
    archived: false,
    createdAt: Date.now(),
    recentAmountsMinor: [],
  }));
}
