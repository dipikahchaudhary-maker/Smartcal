import Decimal from 'decimal.js';

// Configure decimal.js for financial precision
Decimal.set({ precision: 28, rounding: Decimal.ROUND_HALF_UP });

export type Operator = '+' | '−' | '×' | '÷';

export interface CalcState {
  expression: string; // Internal expression representation
  displayExpression: string; // Pretty formatted expression for user
  currentInput: string; // The active number being typed
  pendingOperator: Operator | null;
  result: string; // Live or final result
  isResultCalculated: boolean; // True after '=' is pressed
  hasError: boolean;
  errorMessage: string;
}

export const INITIAL_CALC_STATE: CalcState = {
  expression: '',
  displayExpression: '',
  currentInput: '0',
  pendingOperator: null,
  result: '0',
  isResultCalculated: false,
  hasError: false,
  errorMessage: '',
};

const MAX_DIGITS = 15;

/**
 * Evaluates mathematical expression with correct operator precedence and iOS percent behavior.
 * Uses decimal.js for exact precision without floating point errors.
 */
export function evaluateExpression(exprStr: string): { value: Decimal | null; error: string | null } {
  if (!exprStr || exprStr.trim() === '') {
    return { value: new Decimal(0), error: null };
  }

  try {
    // Normalize string: convert unicode operators to standard
    let s = exprStr.replace(/×/g, '*').replace(/÷/g, '/').replace(/−/g, '-').trim();

    // Remove any trailing operator or trailing decimal point for live evaluation
    while (/[\+\-\*\/]$/.test(s)) {
      s = s.slice(0, -1).trim();
    }
    if (s.endsWith('.')) {
      s = s.slice(0, -1);
    }
    if (!s) {
      return { value: new Decimal(0), error: null };
    }

    // Tokenize
    const tokens: string[] = [];
    let i = 0;
    while (i < s.length) {
      const char = s[i];
      if (/\s/.test(char)) {
        i++;
        continue;
      }

      // Check for unary minus at start or after an operator
      if (char === '-' && (tokens.length === 0 || ['+', '-', '*', '/'].includes(tokens[tokens.length - 1]))) {
        let numStr = '-';
        i++;
        while (i < s.length && /[0-9.]/.test(s[i])) {
          numStr += s[i];
          i++;
        }
        if (i < s.length && s[i] === '%') {
          numStr += '%';
          i++;
        }
        tokens.push(numStr);
        continue;
      }

      if (['+', '-', '*', '/'].includes(char)) {
        tokens.push(char);
        i++;
        continue;
      }

      // Number or number with %
      if (/[0-9.]/.test(char)) {
        let numStr = '';
        while (i < s.length && /[0-9.]/.test(s[i])) {
          numStr += s[i];
          i++;
        }
        if (i < s.length && s[i] === '%') {
          numStr += '%';
          i++;
        }
        tokens.push(numStr);
        continue;
      }

      i++;
    }

    if (tokens.length === 0) {
      return { value: new Decimal(0), error: null };
    }

    // Resolve iOS style percentages:
    // If token has '%':
    // If preceded by '+' or '-', it means (preceding accumulated value * (pct / 100))
    // If preceded by '*' or '/', or at start, it means (pct / 100)
    const resolvedTokens: string[] = [];
    for (let k = 0; k < tokens.length; k++) {
      const tok = tokens[k];
      if (tok.endsWith('%')) {
        const rawNum = tok.slice(0, -1);
        const pctDec = new Decimal(rawNum).div(100);
        const prevOp = k > 0 ? tokens[k - 1] : null;

        if (prevOp === '+' || prevOp === '-') {
          // Calculate the accumulated value of everything before prevOp
          const prefixTokens = tokens.slice(0, k - 1);
          if (prefixTokens.length > 0) {
            const prefixVal = evaluateSimpleTokens(prefixTokens);
            if (prefixVal.error) return prefixVal;
            const absoluteVal = prefixVal.value!.mul(pctDec);
            resolvedTokens.push(absoluteVal.toString());
          } else {
            resolvedTokens.push(pctDec.toString());
          }
        } else {
          resolvedTokens.push(pctDec.toString());
        }
      } else {
        resolvedTokens.push(tok);
      }
    }

    return evaluateSimpleTokens(resolvedTokens);
  } catch (err: any) {
    if (err && err.message && err.message.includes('Division by zero')) {
      return { value: null, error: "Can't divide by zero" };
    }
    return { value: null, error: 'Error' };
  }
}

/**
 * Standard Shunting-Yard algorithm + RPN evaluator for operators +, -, *, /
 */
function evaluateSimpleTokens(tokens: string[]): { value: Decimal | null; error: string | null } {
  if (tokens.length === 0) {
    return { value: new Decimal(0), error: null };
  }

  const precedence: Record<string, number> = {
    '+': 1,
    '-': 1,
    '*': 2,
    '/': 2,
  };

  const outputQueue: string[] = [];
  const operatorStack: string[] = [];

  for (const token of tokens) {
    if (['+', '-', '*', '/'].includes(token)) {
      while (
        operatorStack.length > 0 &&
        precedence[operatorStack[operatorStack.length - 1]] >= precedence[token]
      ) {
        outputQueue.push(operatorStack.pop()!);
      }
      operatorStack.push(token);
    } else {
      outputQueue.push(token);
    }
  }

  while (operatorStack.length > 0) {
    outputQueue.push(operatorStack.pop()!);
  }

  // Evaluate RPN
  const valStack: Decimal[] = [];

  for (const token of outputQueue) {
    if (['+', '-', '*', '/'].includes(token)) {
      if (valStack.length < 2) {
        return { value: null, error: 'Error' };
      }
      const b = valStack.pop()!;
      const a = valStack.pop()!;

      let res: Decimal;
      if (token === '+') {
        res = a.plus(b);
      } else if (token === '-') {
        res = a.minus(b);
      } else if (token === '*') {
        res = a.mul(b);
      } else if (token === '/') {
        if (b.isZero()) {
          return { value: null, error: "Can't divide by zero" };
        }
        res = a.div(b);
      } else {
        return { value: null, error: 'Error' };
      }
      valStack.push(res);
    } else {
      try {
        valStack.push(new Decimal(token));
      } catch {
        return { value: null, error: 'Error' };
      }
    }
  }

  if (valStack.length === 1) {
    return { value: valStack[0], error: null };
  }

  return { value: null, error: 'Error' };
}

/**
 * Format Decimal or string to readable output string (up to 8 decimal places, removing trailing zeros)
 */
export function formatResultString(val: Decimal): string {
  if (!val.isFinite()) return 'Error';
  // Check if integer
  if (val.isInteger()) {
    return val.toFixed(0);
  }
  // Up to 8 decimals
  const str = val.toFixed(8);
  // Strip trailing zeros
  return str.replace(/\.?0+$/, '');
}

/**
 * State machine handler for calculator button presses
 */
export function handleCalculatorAction(state: CalcState, action: string): CalcState {
  // If in error state and pressing anything other than AC, clear error first or handle AC
  if (state.hasError && action !== 'AC') {
    state = { ...INITIAL_CALC_STATE };
  }

  switch (action) {
    case 'AC': {
      return { ...INITIAL_CALC_STATE };
    }

    case '⌫': {
      if (state.hasError) return { ...INITIAL_CALC_STATE };
      if (state.isResultCalculated) {
        // Allow backspacing the calculated result into an editable number
        const clean = state.result.replace(/,/g, '');
        const next = clean.slice(0, -1);
        const newNum = next === '' || next === '-' ? '0' : next;
        return {
          ...INITIAL_CALC_STATE,
          isResultCalculated: false,
          currentInput: newNum,
          expression: newNum === '0' ? '' : newNum,
          displayExpression: newNum === '0' ? '' : newNum,
          result: newNum,
        };
      }

      if (state.currentInput.length > 0 && state.currentInput !== '0') {
        const next = state.currentInput.slice(0, -1);
        const base = state.expression.slice(0, state.expression.length - state.currentInput.length);
        const isBaseAfterOp = base.endsWith(' ');
        const newInput = next === '' || next === '-' ? (isBaseAfterOp ? '' : '0') : next;
        
        // Rebuild expression
        const newExpr = base + (newInput === '0' && base.length > 0 ? '' : newInput);
        const evalRes = evaluateExpression(newExpr || '0');

        return {
          ...state,
          currentInput: newInput,
          expression: newExpr,
          displayExpression: newExpr,
          result: evalRes.error ? 'Error' : evalRes.value ? formatResultString(evalRes.value) : '0',
          hasError: !!evalRes.error,
          errorMessage: evalRes.error || '',
        };
      }

      // If currentInput is empty and expression ends with an operator, backspace the operator
      if (state.expression.length > 0) {
        const trimmed = state.expression.trimEnd();
        const lastChar = trimmed[trimmed.length - 1];
        if (['+', '−', '×', '÷'].includes(lastChar)) {
          const newExpr = trimmed.slice(0, -1).trimEnd();
          const evalRes = evaluateExpression(newExpr || '0');
          // Find previous number
          const parts = newExpr.split(/\s*[\+−×÷]\s*/);
          const prevNumber = parts[parts.length - 1] || '0';

          return {
            ...state,
            expression: newExpr,
            displayExpression: newExpr,
            pendingOperator: null,
            currentInput: prevNumber,
            result: evalRes.error ? 'Error' : evalRes.value ? formatResultString(evalRes.value) : '0',
            hasError: !!evalRes.error,
            errorMessage: evalRes.error || '',
          };
        }
      }

      return state;
    }

    case '%': {
      if (state.hasError) return state;
      // Add % to current input
      if (state.currentInput === '0' || state.currentInput === '') return state;
      if (state.currentInput.endsWith('%')) return state;

      const newInput = state.currentInput + '%';
      const base = state.expression.slice(0, state.expression.length - state.currentInput.length);
      const newExpr = base + newInput;
      const evalRes = evaluateExpression(newExpr);

      return {
        ...state,
        currentInput: newInput,
        expression: newExpr,
        displayExpression: newExpr,
        result: evalRes.error ? 'Error' : evalRes.value ? formatResultString(evalRes.value) : '0',
        hasError: !!evalRes.error,
        errorMessage: evalRes.error || '',
      };
    }

    case '+':
    case '−':
    case '×':
    case '÷': {
      const op = action as Operator;
      if (state.hasError) return state;

      // Leading minus starts a negative number
      if (
        op === '−' &&
        (state.expression === '' || state.expression === '0') &&
        (state.currentInput === '0' || state.currentInput === '') &&
        !state.isResultCalculated
      ) {
        return {
          ...state,
          expression: '−',
          displayExpression: '−',
          currentInput: '-',
          pendingOperator: null,
          result: '0',
        };
      }

      // If user just pressed '=', continue calculation with the result
      if (state.isResultCalculated) {
        return {
          ...state,
          isResultCalculated: false,
          expression: `${state.result} ${op} `,
          displayExpression: `${state.result} ${op} `,
          pendingOperator: op,
          currentInput: '',
        };
      }

      // If expression ends with an operator and current input is empty, replace the operator
      const trimmed = state.expression.trimEnd();
      const lastChar = trimmed[trimmed.length - 1];
      if (state.currentInput === '' && ['+', '−', '×', '÷'].includes(lastChar)) {
        const withoutOp = trimmed.slice(0, -1).trimEnd();
        const newExpr = `${withoutOp} ${op} `;
        return {
          ...state,
          expression: newExpr,
          displayExpression: newExpr,
          pendingOperator: op,
        };
      }

      // Otherwise append operator
      const newExpr = `${state.expression || state.currentInput} ${op} `;
      return {
        ...state,
        expression: newExpr,
        displayExpression: newExpr,
        pendingOperator: op,
        currentInput: '',
      };
    }

    case '=': {
      if (state.hasError || state.expression === '') return state;

      const evalRes = evaluateExpression(state.expression);
      if (evalRes.error) {
        return {
          ...state,
          hasError: true,
          errorMessage: evalRes.error,
          result: 'Error',
        };
      }

      const formatted = formatResultString(evalRes.value!);
      return {
        ...state,
        isResultCalculated: true,
        displayExpression: `${state.expression} =`,
        result: formatted,
        currentInput: formatted,
        pendingOperator: null,
      };
    }

    case '.': {
      if (state.hasError) return state;
      // If result calculated, reset
      if (state.isResultCalculated) {
        return {
          ...INITIAL_CALC_STATE,
          currentInput: '0.',
          expression: '0.',
          displayExpression: '0.',
          result: '0',
        };
      }

      if (state.currentInput.includes('.')) {
        return state; // Only one decimal point per number
      }

      const newInput = state.currentInput === '' ? '0.' : state.currentInput + '.';
      const base = state.expression.slice(0, state.expression.length - state.currentInput.length);
      const newExpr = base + newInput;

      return {
        ...state,
        currentInput: newInput,
        expression: newExpr,
        displayExpression: newExpr,
        pendingOperator: null,
      };
    }

    case '00': {
      if (state.hasError) return state;
      if (state.isResultCalculated) {
        return { ...INITIAL_CALC_STATE };
      }
      // Ignored on empty or 0 entry
      if (state.currentInput === '0' || state.currentInput === '') {
        return state;
      }
      // Max digit check
      const digitCount = state.currentInput.replace(/[^0-9]/g, '').length;
      if (digitCount + 2 > MAX_DIGITS) return state;

      const newInput = state.currentInput + '00';
      const base = state.expression.slice(0, state.expression.length - state.currentInput.length);
      const newExpr = base + newInput;
      const evalRes = evaluateExpression(newExpr);

      return {
        ...state,
        currentInput: newInput,
        expression: newExpr,
        displayExpression: newExpr,
        pendingOperator: null,
        result: evalRes.error ? 'Error' : evalRes.value ? formatResultString(evalRes.value) : '0',
        hasError: !!evalRes.error,
        errorMessage: evalRes.error || '',
      };
    }

    default: {
      // Digit 0-9
      if (!/^[0-9]$/.test(action)) return state;

      if (state.isResultCalculated) {
        // After '=', digit starts brand new calculation
        return {
          ...INITIAL_CALC_STATE,
          currentInput: action,
          expression: action,
          displayExpression: action,
          result: action,
        };
      }

      // Max digit limit
      const digitCount = state.currentInput.replace(/[^0-9]/g, '').length;
      if (digitCount >= MAX_DIGITS) return state;

      let newInput = state.currentInput;
      if (newInput === '0') {
        newInput = action;
      } else {
        newInput = newInput + action;
      }

      const base = state.expression.slice(0, state.expression.length - state.currentInput.length);
      const newExpr = base + newInput;
      const evalRes = evaluateExpression(newExpr);

      return {
        ...state,
        currentInput: newInput,
        expression: newExpr,
        displayExpression: newExpr,
        pendingOperator: null,
        result: evalRes.error ? 'Error' : evalRes.value ? formatResultString(evalRes.value) : '0',
        hasError: !!evalRes.error,
        errorMessage: evalRes.error || '',
      };
    }
  }
}
