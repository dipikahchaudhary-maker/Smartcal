import { evaluateExpression, handleCalculatorAction, INITIAL_CALC_STATE, formatResultString } from './calcEngine.ts';

export function runAllCalculatorTests(): { passed: number; failed: number; results: Array<{ name: string; success: boolean; error?: string }> } {
  const tests: Array<{ name: string; run: () => void }> = [
    {
      name: '0.1 + 0.2 = 0.3 (no floating point artifact)',
      run: () => {
        const res = evaluateExpression('0.1 + 0.2');
        if (!res.value || formatResultString(res.value) !== '0.3') {
          throw new Error(`Expected 0.3 but got ${res.value?.toString()}`);
        }
      },
    },
    {
      name: '100 + 10% = 110 (iOS additive percent)',
      run: () => {
        const res = evaluateExpression('100 + 10%');
        if (!res.value || formatResultString(res.value) !== '110') {
          throw new Error(`Expected 110 but got ${res.value?.toString()}`);
        }
      },
    },
    {
      name: '200 − 10% = 180 (iOS subtractive percent)',
      run: () => {
        const res = evaluateExpression('200 − 10%');
        if (!res.value || formatResultString(res.value) !== '180') {
          throw new Error(`Expected 180 but got ${res.value?.toString()}`);
        }
      },
    },
    {
      name: '50 × 10% = 5 (iOS multiplicative percent)',
      run: () => {
        const res = evaluateExpression('50 × 10%');
        if (!res.value || formatResultString(res.value) !== '5') {
          throw new Error(`Expected 5 but got ${res.value?.toString()}`);
        }
      },
    },
    {
      name: '5 ÷ 0 -> error (division by zero)',
      run: () => {
        const res = evaluateExpression('5 ÷ 0');
        if (!res.error || !res.error.includes("divide by zero")) {
          throw new Error(`Expected division by zero error, got ${JSON.stringify(res)}`);
        }
      },
    },
    {
      name: '2 + 3 × 4 = 14 (operator precedence)',
      run: () => {
        const res = evaluateExpression('2 + 3 × 4');
        if (!res.value || formatResultString(res.value) !== '14') {
          throw new Error(`Expected 14 but got ${res.value?.toString()}`);
        }
      },
    },
    {
      name: '1000 − 1 = 999',
      run: () => {
        const res = evaluateExpression('1000 − 1');
        if (!res.value || formatResultString(res.value) !== '999') {
          throw new Error(`Expected 999 but got ${res.value?.toString()}`);
        }
      },
    },
    {
      name: '12.5 × 8 = 100',
      run: () => {
        const res = evaluateExpression('12.5 × 8');
        if (!res.value || formatResultString(res.value) !== '100') {
          throw new Error(`Expected 100 but got ${res.value?.toString()}`);
        }
      },
    },
    {
      name: '00 on empty entry stays 0',
      run: () => {
        let state = INITIAL_CALC_STATE;
        state = handleCalculatorAction(state, '00');
        if (state.currentInput !== '0') {
          throw new Error(`Expected currentInput to remain '0', got '${state.currentInput}'`);
        }
      },
    },
    {
      name: 'leading zeros collapse (0 then 5 becomes 5)',
      run: () => {
        let state = INITIAL_CALC_STATE;
        state = handleCalculatorAction(state, '5');
        if (state.currentInput !== '5') {
          throw new Error(`Expected '5', got '${state.currentInput}'`);
        }
      },
    },
    {
      name: 'operator replacement (+ replaced by ×)',
      run: () => {
        let state = INITIAL_CALC_STATE;
        state = handleCalculatorAction(state, '8');
        state = handleCalculatorAction(state, '+');
        state = handleCalculatorAction(state, '×');
        if (!state.expression.includes('×') || state.expression.includes('+')) {
          throw new Error(`Expected expression to end with × and not +, got '${state.expression}'`);
        }
      },
    },
    {
      name: '= then digit starts a new calculation',
      run: () => {
        let state = INITIAL_CALC_STATE;
        state = handleCalculatorAction(state, '4');
        state = handleCalculatorAction(state, '+');
        state = handleCalculatorAction(state, '6');
        state = handleCalculatorAction(state, '=');
        if (state.result !== '10') throw new Error(`Expected 10, got ${state.result}`);
        state = handleCalculatorAction(state, '7');
        if (state.currentInput !== '7' || state.result !== '7') {
          throw new Error(`Expected new calculation starting with 7, got ${state.currentInput}`);
        }
      },
    },
    {
      name: '= then operator continues from result',
      run: () => {
        let state = INITIAL_CALC_STATE;
        state = handleCalculatorAction(state, '1');
        state = handleCalculatorAction(state, '0');
        state = handleCalculatorAction(state, '=');
        state = handleCalculatorAction(state, '+');
        state = handleCalculatorAction(state, '5');
        if (state.result !== '15') {
          throw new Error(`Expected 15, got ${state.result}`);
        }
      },
    },
    {
      name: 'max digit limit (stops at 15 digits)',
      run: () => {
        let state = INITIAL_CALC_STATE;
        for (let i = 0; i < 20; i++) {
          state = handleCalculatorAction(state, '9');
        }
        if (state.currentInput.length > 15) {
          throw new Error(`Expected max 15 digits, got ${state.currentInput.length}`);
        }
      },
    },
    {
      name: 'backspace across an operator',
      run: () => {
        let state = INITIAL_CALC_STATE;
        state = handleCalculatorAction(state, '1');
        state = handleCalculatorAction(state, '2');
        state = handleCalculatorAction(state, '+');
        state = handleCalculatorAction(state, '⌫');
        if (state.expression.includes('+')) {
          throw new Error(`Expected + to be removed, got '${state.expression}'`);
        }
      },
    },
    {
      name: 'decimal point once per number',
      run: () => {
        let state = INITIAL_CALC_STATE;
        state = handleCalculatorAction(state, '3');
        state = handleCalculatorAction(state, '.');
        state = handleCalculatorAction(state, '1');
        state = handleCalculatorAction(state, '.');
        state = handleCalculatorAction(state, '4');
        if (state.currentInput !== '3.14') {
          throw new Error(`Expected '3.14', got '${state.currentInput}'`);
        }
      },
    },
    {
      name: 'live evaluation without pressing =',
      run: () => {
        let state = INITIAL_CALC_STATE;
        state = handleCalculatorAction(state, '1');
        state = handleCalculatorAction(state, '2');
        state = handleCalculatorAction(state, '0');
        state = handleCalculatorAction(state, '+');
        state = handleCalculatorAction(state, '4');
        state = handleCalculatorAction(state, '5');
        if (state.result !== '165') {
          throw new Error(`Expected live result '165', got '${state.result}'`);
        }
      },
    },
    {
      name: 'trailing operator ignored in live result',
      run: () => {
        const res = evaluateExpression('50 + 25 +');
        if (!res.value || formatResultString(res.value) !== '75') {
          throw new Error(`Expected 75, got ${res.value?.toString()}`);
        }
      },
    },
    {
      name: 'negative number start: −5 + 10 = 5',
      run: () => {
        const res = evaluateExpression('−5 + 10');
        if (!res.value || formatResultString(res.value) !== '5') {
          throw new Error(`Expected 5, got ${res.value?.toString()}`);
        }
      },
    },
    {
      name: 'complex order of operations: 10 + 20 ÷ 4 − 2 × 3 = 9',
      run: () => {
        const res = evaluateExpression('10 + 20 ÷ 4 − 2 × 3');
        // 10 + 5 - 6 = 9
        if (!res.value || formatResultString(res.value) !== '9') {
          throw new Error(`Expected 9, got ${res.value?.toString()}`);
        }
      },
    },
    {
      name: 'percentage after multiplication: 200 × 5% = 10',
      run: () => {
        const res = evaluateExpression('200 × 5%');
        if (!res.value || formatResultString(res.value) !== '10') {
          throw new Error(`Expected 10, got ${res.value?.toString()}`);
        }
      },
    },
    {
      name: 'chained addition: 120 + 45 + 300 = 465',
      run: () => {
        const res = evaluateExpression('120 + 45 + 300');
        if (!res.value || formatResultString(res.value) !== '465') {
          throw new Error(`Expected 465, got ${res.value?.toString()}`);
        }
      },
    },
    {
      name: 'decimal multiplication precision: 0.25 × 0.5 = 0.125',
      run: () => {
        const res = evaluateExpression('0.25 × 0.5');
        if (!res.value || formatResultString(res.value) !== '0.125') {
          throw new Error(`Expected 0.125, got ${res.value?.toString()}`);
        }
      },
    },
    {
      name: 'AC clears all state back to initial',
      run: () => {
        let state = INITIAL_CALC_STATE;
        state = handleCalculatorAction(state, '9');
        state = handleCalculatorAction(state, '+');
        state = handleCalculatorAction(state, '9');
        state = handleCalculatorAction(state, 'AC');
        if (state.result !== '0' || state.expression !== '' || state.currentInput !== '0') {
          throw new Error(`Expected reset to 0, got ${JSON.stringify(state)}`);
        }
      },
    },
    {
      name: 'large integer multiplication: 100000 × 50 = 5000000',
      run: () => {
        const res = evaluateExpression('100000 × 50');
        if (!res.value || formatResultString(res.value) !== '5000000') {
          throw new Error(`Expected 5000000, got ${res.value?.toString()}`);
        }
      },
    },
    {
      name: 'swipe-to-delete / backspace slices digits: 125 -> 12 -> 1 -> 0',
      run: () => {
        let state = INITIAL_CALC_STATE;
        state = handleCalculatorAction(state, '1');
        state = handleCalculatorAction(state, '2');
        state = handleCalculatorAction(state, '5');
        if (state.result !== '125') throw new Error(`Expected 125, got ${state.result}`);

        state = handleCalculatorAction(state, '⌫');
        if (state.result !== '12') throw new Error(`Expected 12 after backspace, got ${state.result}`);

        state = handleCalculatorAction(state, '⌫');
        if (state.result !== '1') throw new Error(`Expected 1 after backspace, got ${state.result}`);

        state = handleCalculatorAction(state, '⌫');
        if (state.result !== '0') throw new Error(`Expected 0 after backspace, got ${state.result}`);
      },
    },
    {
      name: 'backspace on calculated result allows editing: 465 -> 46',
      run: () => {
        let state = INITIAL_CALC_STATE;
        state = handleCalculatorAction(state, '4');
        state = handleCalculatorAction(state, '0');
        state = handleCalculatorAction(state, '+');
        state = handleCalculatorAction(state, '6');
        state = handleCalculatorAction(state, '5');
        state = handleCalculatorAction(state, '=');
        if (state.result !== '105') throw new Error(`Expected 105, got ${state.result}`);

        state = handleCalculatorAction(state, '⌫');
        if (state.result !== '10') throw new Error(`Expected 10 after backspace on result, got ${state.result}`);
      },
    },
  ];

  let passed = 0;
  let failed = 0;
  const results: Array<{ name: string; success: boolean; error?: string }> = [];

  for (const t of tests) {
    try {
      t.run();
      passed++;
      results.push({ name: t.name, success: true });
    } catch (err: any) {
      failed++;
      results.push({ name: t.name, success: false, error: err?.message || String(err) });
    }
  }

  return { passed, failed, results };
}
