import { format, parseISO } from 'date-fns';

/**
 * Format date fully: "Sunday, 18 October 2026"
 */
export function formatFullDate(date: Date | number | string): string {
  const d = typeof date === 'string' && date.length === 10 ? parseISO(date) : new Date(date);
  return format(d, 'EEEE, d MMMM yyyy');
}

/**
 * Short month & year: "October 2026"
 */
export function formatMonthYear(date: Date | number | string): string {
  const d = typeof date === 'string' && date.length === 10 ? parseISO(date) : new Date(date);
  return format(d, 'MMMM yyyy');
}

/**
 * Year only: "2026"
 */
export function formatYearOnly(date: Date | number | string): string {
  const d = typeof date === 'string' && date.length === 10 ? parseISO(date) : new Date(date);
  return format(d, 'yyyy');
}

/**
 * Today chip date label: "TODAY · 18 OCT 2026"
 */
export function formatTodayChipDate(date: Date | number = new Date()): string {
  const d = new Date(date);
  return `TODAY · ${format(d, 'd MMM yyyy').toUpperCase()}`;
}

/**
 * Format time of day: "10:45 AM"
 */
export function formatTimeOfDay(date: Date | number): string {
  return format(new Date(date), 'h:mm a');
}

/**
 * Calculate business dayKey (YYYY-MM-DD) and hour (0-23) based on custom business day start offset
 * @param ts timestamp in ms
 * @param dayStartMinutes minutes from midnight, e.g. 0 = 12:00 AM, 240 = 4:00 AM
 */
export function getBusinessDayKeyAndHour(ts: number, dayStartMinutes = 0): { dayKey: string; hour: number } {
  const dateObj = new Date(ts);
  const hour = dateObj.getHours();

  // Shift timestamp backwards by dayStartMinutes
  const shiftedTs = ts - dayStartMinutes * 60 * 1000;
  const shiftedDate = new Date(shiftedTs);

  const yyyy = shiftedDate.getFullYear();
  const mm = String(shiftedDate.getMonth() + 1).padStart(2, '0');
  const dd = String(shiftedDate.getDate()).padStart(2, '0');

  return {
    dayKey: `${yyyy}-${mm}-${dd}`,
    hour,
  };
}

/**
 * Indian numbering system formatter (Lakh / Crore)
 * e.g. 1234567 -> "12,34,567"
 */
export function formatIndianNumber(val: number): string {
  const isNeg = val < 0;
  const absVal = Math.abs(Math.round(val));
  const s = absVal.toString();
  if (s.length <= 3) return (isNeg ? '-' : '') + s;

  const lastThree = s.substring(s.length - 3);
  const otherNumbers = s.substring(0, s.length - 3);
  const formatted = otherNumbers.replace(/\B(?=(\d{2})+(?!\d))/g, ',') + ',' + lastThree;
  return (isNeg ? '-' : '') + formatted;
}

/**
 * Format money with exact minor units (e.g. 100 minor units = 1.00 major units)
 * @param amountMinor integer minor units
 * @param currencySymbol currency symbol e.g. '₹' or '$'
 * @param numberFormat 'indian' | 'international' | 'auto'
 * @param countryCode e.g. 'IN'
 * @param showDecimals optional boolean (defaults to false for clean counter numbers if integer)
 */
export function formatMoney(
  amountMinor: number,
  currencySymbol = '₹',
  numberFormat: 'auto' | 'indian' | 'international' = 'auto',
  countryCode = 'IN',
  showDecimals = false
): string {
  const isNegative = amountMinor < 0;
  const absMinor = Math.abs(amountMinor);
  const major = absMinor / 100;

  const isIndian = numberFormat === 'indian' || (numberFormat === 'auto' && (countryCode === 'IN' || currencySymbol === '₹'));

  let formattedNum = '';
  if (showDecimals || !Number.isInteger(major)) {
    const parts = major.toFixed(2).split('.');
    const intPart = parseInt(parts[0], 10);
    const intFormatted = isIndian ? formatIndianNumber(intPart) : intPart.toLocaleString('en-US');
    formattedNum = `${intFormatted}.${parts[1]}`;
  } else {
    formattedNum = isIndian ? formatIndianNumber(major) : major.toLocaleString('en-US');
  }

  // True minus sign per requirement: "−₹1,200"
  if (isNegative) {
    return `−${currencySymbol}${formattedNum}`;
  }
  return `${currencySymbol}${formattedNum}`;
}

/**
 * Compact numbers once past 5 digits:
 * India: ₹1.25L / ₹1.2Cr
 * Elsewhere: $125K / $1.25M
 */
export function formatCompactMoney(
  amountMinor: number,
  currencySymbol = '₹',
  countryCode = 'IN'
): string {
  const isNegative = amountMinor < 0;
  const absMinor = Math.abs(amountMinor);
  const major = absMinor / 100;
  const prefix = isNegative ? '−' : '';

  const isIndia = countryCode === 'IN' || currencySymbol === '₹';

  if (isIndia) {
    if (major >= 10000000) {
      // Crores
      const cr = (major / 10000000).toFixed(2).replace(/\.?0+$/, '');
      return `${prefix}${currencySymbol}${cr}Cr`;
    } else if (major >= 100000) {
      // Lakhs
      const l = (major / 100000).toFixed(2).replace(/\.?0+$/, '');
      return `${prefix}${currencySymbol}${l}L`;
    }
  } else {
    if (major >= 1000000) {
      const m = (major / 1000000).toFixed(2).replace(/\.?0+$/, '');
      return `${prefix}${currencySymbol}${m}M`;
    } else if (major >= 1000) {
      const k = (major / 1000).toFixed(1).replace(/\.?0+$/, '');
      return `${prefix}${currencySymbol}${k}K`;
    }
  }

  // Under limit: standard format
  return formatMoney(amountMinor, currencySymbol, isIndia ? 'indian' : 'international', countryCode);
}
