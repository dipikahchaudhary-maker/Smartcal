// Vibration API helper with subtle iOS-like haptic feedback timings
export function triggerHaptic(type: 'key' | 'success' | 'error' | 'selection' | 'warning', enabled = true) {
  if (!enabled) return;
  if (typeof navigator === 'undefined' || !navigator.vibrate) return;

  try {
    switch (type) {
      case 'key':
        navigator.vibrate(8);
        break;
      case 'selection':
        navigator.vibrate(10);
        break;
      case 'success':
        // Soft double-tick
        navigator.vibrate([12, 35, 14]);
        break;
      case 'error':
        // Triple short
        navigator.vibrate([10, 25, 10, 25, 10]);
        break;
      case 'warning':
        navigator.vibrate([15, 40, 20]);
        break;
    }
  } catch {
    // Graceful fallback
  }
}
