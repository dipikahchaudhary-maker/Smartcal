import Dexie, { type Table } from 'dexie';
import {
  Transaction,
  Category,
  UdharCustomer,
  DailyRollup,
  ShopProfile,
  UserSettings,
  PaymentMode,
} from '../types/index.ts';
import { getBusinessDayKeyAndHour } from '../utils/formatters.ts';
import { getInitialCategoriesForBusinessType } from '../constants/categories.ts';

export class HisaabDatabase extends Dexie {
  transactions!: Table<Transaction, string>;
  dailyRollups!: Table<DailyRollup, string>;
  categories!: Table<Category, string>;
  udharCustomers!: Table<UdharCustomer, string>;
  appState!: Table<{ key: string; value: any }, string>;

  constructor() {
    super('HisaabAppDB');
    this.version(1).stores({
      transactions: 'id, ts, dayKey, type, mode, deleted, isSample, categoryId, udharCustomerId',
      dailyRollups: 'dayKey',
      categories: 'id, order, archived',
      udharCustomers: 'id, lastActivityTs, pendingMinor',
      appState: 'key',
    });
  }
}

export const db = new HisaabDatabase();

export const DEFAULT_SETTINGS: UserSettings = {
  theme: 'dark',
  haptics: true,
  sounds: true,
  keepAwake: false,
  dayStartMinutes: 0, // 12:00 AM
  chipMode: 'sales',
  hideEarnings: false,
  dailyGoalMinor: null,
  numberFormat: 'auto',
  reduceMotion: false,
  hintsShown: {
    holdCashIn: false,
  },
};

/**
 * Initialize or get user settings
 */
export async function getSettings(): Promise<UserSettings> {
  const row = await db.appState.get('settings');
  if (row) {
    return { ...DEFAULT_SETTINGS, ...row.value, theme: 'dark' };
  }
  await db.appState.put({ key: 'settings', value: DEFAULT_SETTINGS });
  return DEFAULT_SETTINGS;
}

export async function saveSettings(settings: Partial<UserSettings>): Promise<UserSettings> {
  const current = await getSettings();
  const updated = { ...current, ...settings };
  await db.appState.put({ key: 'settings', value: updated });
  return updated;
}

/**
 * Profile operations
 */
export async function getProfile(): Promise<ShopProfile | null> {
  const row = await db.appState.get('profile');
  return row ? (row.value as ShopProfile) : null;
}

export async function saveProfile(profile: ShopProfile): Promise<void> {
  await db.appState.put({ key: 'profile', value: profile });
}

/**
 * Category operations
 */
export async function getCategories(): Promise<Category[]> {
  const all = await db.categories.orderBy('order').toArray();
  return all.filter((c) => !c.archived);
}

export async function getAllCategoriesIncludingArchived(): Promise<Category[]> {
  return await db.categories.orderBy('order').toArray();
}

export async function saveCategory(cat: Category): Promise<void> {
  await db.categories.put(cat);
}

export async function initCategoriesForShop(businessType: string): Promise<Category[]> {
  const existing = await db.categories.count();
  if (existing > 0) {
    return getCategories();
  }
  const defaults = getInitialCategoriesForBusinessType(businessType);
  await db.categories.bulkPut(defaults);
  return defaults;
}

export async function updateCategoriesOrder(categories: Category[]): Promise<void> {
  await db.transaction('rw', db.categories, async () => {
    for (let i = 0; i < categories.length; i++) {
      await db.categories.update(categories[i].id, { order: i });
    }
  });
}

/**
 * Helper to compute an empty daily rollup
 */
function createEmptyRollup(dayKey: string): DailyRollup {
  return {
    dayKey,
    salesMinor: 0,
    expensesMinor: 0,
    customers: 0,
    txCount: 0,
    udharGivenMinor: 0,
    udharReceivedMinor: 0,
    byCategory: {},
    byHour: {},
    byMode: { cash: 0, upi: 0, card: 0, udhar: 0 },
  };
}

/**
 * Recompute or update a daily rollup with an added, modified or removed transaction
 */
export async function recomputeDailyRollup(dayKey: string): Promise<DailyRollup> {
  const txs = await db.transactions
    .where('dayKey')
    .equals(dayKey)
    .and((t) => !t.deleted)
    .toArray();

  const rollup = createEmptyRollup(dayKey);

  for (const t of txs) {
    rollup.txCount += 1;

    if (t.type === 'cash_in' || t.type === 'udhar_sale') {
      rollup.salesMinor += t.amountMinor;
      if (t.countsAsCustomer) {
        rollup.customers += 1;
      }
      if (t.type === 'udhar_sale') {
        rollup.udharGivenMinor += t.amountMinor;
      }
    } else if (t.type === 'cash_out') {
      rollup.expensesMinor += t.amountMinor;
      if (t.categoryId) {
        rollup.byCategory[t.categoryId] = (rollup.byCategory[t.categoryId] || 0) + t.amountMinor;
      }
    } else if (t.type === 'udhar_payment') {
      rollup.udharReceivedMinor += t.amountMinor;
    }

    // Payment mode breakdown
    if (t.mode) {
      rollup.byMode[t.mode] = (rollup.byMode[t.mode] || 0) + t.amountMinor;
    }

    // Hourly breakdown
    if (!rollup.byHour[t.hour]) {
      rollup.byHour[t.hour] = { salesMinor: 0, customers: 0 };
    }
    if (t.type === 'cash_in' || t.type === 'udhar_sale') {
      rollup.byHour[t.hour].salesMinor += t.amountMinor;
      if (t.countsAsCustomer) {
        rollup.byHour[t.hour].customers += 1;
      }
    }
  }

  await db.dailyRollups.put(rollup);
  return rollup;
}

/**
 * Add a new transaction (Cash In, Cash Out, Udhar Sale, Udhar Payment)
 */
export async function addTransaction(
  txData: Omit<Transaction, 'id' | 'createdAt' | 'updatedAt' | 'dayKey' | 'hour' | 'ts'> & {
    id?: string;
    ts?: number;
    dayKey?: string;
    hour?: number;
  }
): Promise<Transaction> {
  const settings = await getSettings();
  const ts = txData.ts || Date.now();
  const dayHour = getBusinessDayKeyAndHour(ts, settings.dayStartMinutes);
  const dayKey = txData.dayKey || dayHour.dayKey;
  const hour = txData.hour !== undefined ? txData.hour : dayHour.hour;

  const id = txData.id || `tx_${Date.now()}_${Math.random().toString(36).substring(2, 8)}`;
  const now = Date.now();

  const newTx: Transaction = {
    ...txData,
    id,
    ts,
    dayKey,
    hour,
    createdAt: now,
    updatedAt: now,
  };

  await db.transaction('rw', [db.transactions, db.dailyRollups, db.categories, db.udharCustomers], async () => {
    // 1. Save transaction
    await db.transactions.put(newTx);

    // 2. Update category recent amounts & lastUsedAt if cash_out
    if (newTx.type === 'cash_out' && newTx.categoryId) {
      const cat = await db.categories.get(newTx.categoryId);
      if (cat) {
        const recentAmounts = [newTx.amountMinor, ...(cat.recentAmountsMinor || []).filter((a) => a !== newTx.amountMinor)].slice(0, 5);
        await db.categories.update(cat.id, {
          lastUsedAt: now,
          recentAmountsMinor: recentAmounts,
        });
      }
    }

    // 3. Update Udhar Customer balance if applicable
    if (newTx.udharCustomerId) {
      const cust = await db.udharCustomers.get(newTx.udharCustomerId);
      if (cust) {
        let pending = cust.pendingMinor;
        if (newTx.type === 'udhar_sale') {
          pending += newTx.amountMinor;
        } else if (newTx.type === 'udhar_payment') {
          pending = Math.max(0, pending - newTx.amountMinor);
        }
        await db.udharCustomers.update(cust.id, {
          pendingMinor: pending,
          lastActivityTs: now,
        });
      }
    }
  });

  // Recompute daily rollup atomically
  await recomputeDailyRollup(dayKey);

  return newTx;
}

/**
 * Undo / Delete a transaction
 */
export async function deleteTransaction(txId: string): Promise<Transaction | null> {
  const tx = await db.transactions.get(txId);
  if (!tx || tx.deleted) return null;

  await db.transaction('rw', [db.transactions, db.dailyRollups, db.udharCustomers], async () => {
    await db.transactions.update(txId, { deleted: true, updatedAt: Date.now() });

    // Reverse Udhar customer balance if applicable
    if (tx.udharCustomerId) {
      const cust = await db.udharCustomers.get(tx.udharCustomerId);
      if (cust) {
        let pending = cust.pendingMinor;
        if (tx.type === 'udhar_sale') {
          pending = Math.max(0, pending - tx.amountMinor);
        } else if (tx.type === 'udhar_payment') {
          pending += tx.amountMinor;
        }
        await db.udharCustomers.update(cust.id, {
          pendingMinor: pending,
          lastActivityTs: Date.now(),
        });
      }
    }
  });

  await recomputeDailyRollup(tx.dayKey);
  return tx;
}

/**
 * Restore a deleted transaction (Undo the delete)
 */
export async function restoreTransaction(txId: string): Promise<Transaction | null> {
  const tx = await db.transactions.get(txId);
  if (!tx || !tx.deleted) return null;

  await db.transaction('rw', [db.transactions, db.dailyRollups, db.udharCustomers], async () => {
    await db.transactions.update(txId, { deleted: false, updatedAt: Date.now() });

    if (tx.udharCustomerId) {
      const cust = await db.udharCustomers.get(tx.udharCustomerId);
      if (cust) {
        let pending = cust.pendingMinor;
        if (tx.type === 'udhar_sale') {
          pending += tx.amountMinor;
        } else if (tx.type === 'udhar_payment') {
          pending = Math.max(0, pending - tx.amountMinor);
        }
        await db.udharCustomers.update(cust.id, {
          pendingMinor: pending,
          lastActivityTs: Date.now(),
        });
      }
    }
  });

  await recomputeDailyRollup(tx.dayKey);
  return tx;
}

/**
 * Update an existing transaction (edit amount, note, date, customer count, mode, etc.)
 */
export async function updateTransaction(
  txId: string,
  updates: Partial<Transaction>
): Promise<Transaction | null> {
  const current = await db.transactions.get(txId);
  if (!current) return null;

  const oldDayKey = current.dayKey;
  const newDayKey = updates.dayKey || oldDayKey;

  const updatedTx = { ...current, ...updates, updatedAt: Date.now() };

  await db.transaction('rw', [db.transactions, db.dailyRollups, db.udharCustomers], async () => {
    await db.transactions.put(updatedTx);

    // If Udhar customer and amount changed
    if (updatedTx.udharCustomerId && updates.amountMinor !== undefined && updates.amountMinor !== current.amountMinor) {
      const diff = updates.amountMinor - current.amountMinor;
      const cust = await db.udharCustomers.get(updatedTx.udharCustomerId);
      if (cust) {
        let pending = cust.pendingMinor;
        if (updatedTx.type === 'udhar_sale') {
          pending += diff;
        } else if (updatedTx.type === 'udhar_payment') {
          pending = Math.max(0, pending - diff);
        }
        await db.udharCustomers.update(cust.id, {
          pendingMinor: pending,
          lastActivityTs: Date.now(),
        });
      }
    }
  });

  // Recompute rollups for both old and new day keys
  await recomputeDailyRollup(oldDayKey);
  if (newDayKey !== oldDayKey) {
    await recomputeDailyRollup(newDayKey);
  }

  return updatedTx;
}

/**
 * Get daily rollup for a given dayKey
 */
export async function getDailyRollup(dayKey: string): Promise<DailyRollup> {
  const r = await db.dailyRollups.get(dayKey);
  if (r) return r;
  return createEmptyRollup(dayKey);
}

/**
 * Get rollups across a date range [startDayKey, endDayKey] inclusive
 */
export async function getRollupsRange(startDayKey: string, endDayKey: string): Promise<DailyRollup[]> {
  return await db.dailyRollups
    .where('dayKey')
    .between(startDayKey, endDayKey, true, true)
    .toArray();
}

/**
 * History queries: paginated transactions
 */
export async function getHistoryTransactions(
  filterType: 'all' | 'cash_in' | 'cash_out' | 'udhar' = 'all',
  searchQuery = '',
  selectedDayKey?: string,
  limit = 100
): Promise<Transaction[]> {
  let collection = db.transactions.orderBy('ts').reverse().filter((t) => !t.deleted);

  if (selectedDayKey) {
    collection = collection.filter((t) => t.dayKey === selectedDayKey);
  }

  if (filterType === 'cash_in') {
    collection = collection.filter((t) => t.type === 'cash_in');
  } else if (filterType === 'cash_out') {
    collection = collection.filter((t) => t.type === 'cash_out');
  } else if (filterType === 'udhar') {
    collection = collection.filter((t) => t.type === 'udhar_sale' || t.type === 'udhar_payment');
  }

  if (searchQuery.trim()) {
    const q = searchQuery.toLowerCase().trim();
    collection = collection.filter((t) => {
      const matchCat = t.categoryName?.toLowerCase().includes(q);
      const matchNote = t.note?.toLowerCase().includes(q);
      const matchExpr = t.expr?.toLowerCase().includes(q);
      const matchCust = t.customerName?.toLowerCase().includes(q);
      const matchMode = t.mode?.toLowerCase().includes(q);
      const matchAmt = (t.amountMinor / 100).toString().includes(q);
      return !!(matchCat || matchNote || matchExpr || matchCust || matchMode || matchAmt);
    });
  }

  return await collection.limit(limit).toArray();
}

/**
 * Udhar Customer Operations
 */
export async function getUdharCustomers(): Promise<UdharCustomer[]> {
  return await db.udharCustomers.orderBy('pendingMinor').reverse().toArray();
}

export async function getUdharCustomer(id: string): Promise<UdharCustomer | null> {
  const c = await db.udharCustomers.get(id);
  return c || null;
}

export async function addUdharCustomer(name: string, phone: string, address = ''): Promise<UdharCustomer> {
  const id = `cust_${Date.now()}_${Math.random().toString(36).substring(2, 7)}`;
  const now = Date.now();
  const customer: UdharCustomer = {
    id,
    name,
    phone,
    address,
    createdAt: now,
    lastActivityTs: now,
    pendingMinor: 0,
  };
  await db.udharCustomers.put(customer);
  return customer;
}

export async function getCustomerTransactions(customerId: string): Promise<Transaction[]> {
  return await db.transactions
    .where('udharCustomerId')
    .equals(customerId)
    .and((t) => !t.deleted)
    .reverse()
    .sortBy('ts');
}

/**
 * Sample Data Generator (~120 days of realistic shopkeeper transactions)
 */
export async function generateSampleData(profile: ShopProfile): Promise<void> {
  const categories = await getCategories();
  const catMap = new Map(categories.map((c) => [c.name, c]));

  // Create sample udhar customers
  const sampleCustomers: UdharCustomer[] = [
    { id: 'sc_1', name: 'Ramesh Sharma', phone: '+919876543210', address: 'Flat 402, Sai Apts', createdAt: Date.now() - 60 * 86400000, lastActivityTs: Date.now() - 2 * 86400000, pendingMinor: 245000 },
    { id: 'sc_2', name: 'Sunita Verma', phone: '+919823456789', address: 'B-12, Sector 4', createdAt: Date.now() - 45 * 86400000, lastActivityTs: Date.now() - 5 * 86400000, pendingMinor: 120000 },
    { id: 'sc_3', name: 'Amit Patel', phone: '+919811223344', address: 'Near Bus Stand', createdAt: Date.now() - 30 * 86400000, lastActivityTs: Date.now() - 1 * 86400000, pendingMinor: 65000 },
  ];

  await db.udharCustomers.bulkPut(sampleCustomers);

  const sampleTransactions: Transaction[] = [];
  const now = Date.now();
  const affectedDayKeys = new Set<string>();

  // Generate 120 days of data
  for (let d = 119; d >= 0; d--) {
    const dayDate = new Date(now - d * 86400000);
    const yyyy = dayDate.getFullYear();
    const mm = String(dayDate.getMonth() + 1).padStart(2, '0');
    const dd = String(dayDate.getDate()).padStart(2, '0');
    const dayKey = `${yyyy}-${mm}-${dd}`;
    affectedDayKeys.add(dayKey);

    const isWeekend = dayDate.getDay() === 0 || dayDate.getDay() === 6;
    const baseCust = isWeekend ? 22 : 14;
    const numCustomers = baseCust + Math.floor(Math.sin(d * 0.1) * 6 + Math.random() * 8);

    // Daily Sales
    for (let c = 0; c < numCustomers; c++) {
      const hour = 9 + Math.floor(Math.random() * 12); // 9 AM to 9 PM
      const minute = Math.floor(Math.random() * 60);
      const ts = new Date(dayDate).setHours(hour, minute, 0, 0);

      // Random bill size (e.g. ₹45 to ₹1,800)
      const major = Math.floor(30 + Math.random() * 450 + (Math.random() > 0.8 ? Math.random() * 1200 : 0));
      const amountMinor = major * 100;

      // Mode: mostly cash & upi
      const randMode = Math.random();
      const mode: PaymentMode = randMode < 0.55 ? 'cash' : randMode < 0.9 ? 'upi' : 'card';

      sampleTransactions.push({
        id: `sample_sale_${d}_${c}`,
        type: 'cash_in',
        amountMinor,
        ts,
        dayKey,
        hour,
        mode,
        expr: `${Math.round(major * 0.6)} + ${Math.round(major * 0.4)}`,
        countsAsCustomer: true,
        isSample: true,
        createdAt: ts,
        updatedAt: ts,
      });
    }

    // Daily and recurring expenses
    // 1. Tea & Snacks almost every day
    if (Math.random() > 0.3) {
      const teaCat = catMap.get('Tea & Snacks') || categories[0];
      const teaHour = 11;
      const ts = new Date(dayDate).setHours(teaHour, 30, 0, 0);
      sampleTransactions.push({
        id: `sample_exp_tea_${d}`,
        type: 'cash_out',
        amountMinor: 8000, // ₹80
        ts,
        dayKey,
        hour: teaHour,
        categoryId: teaCat.id,
        categoryName: teaCat.name,
        mode: 'cash',
        note: 'Afternoon chai & biscuits',
        countsAsCustomer: false,
        isSample: true,
        createdAt: ts,
        updatedAt: ts,
      });
    }

    // 2. Weekly Stock or Inventory
    if (dayDate.getDay() === 2) {
      const stockCat = catMap.get('Stock / Inventory') || catMap.get('Packing') || categories[0];
      const ts = new Date(dayDate).setHours(14, 0, 0, 0);
      sampleTransactions.push({
        id: `sample_exp_stock_${d}`,
        type: 'cash_out',
        amountMinor: Math.floor(2500 + Math.random() * 3000) * 100, // ~₹2,500 - ₹5,500
        ts,
        dayKey,
        hour: 14,
        categoryId: stockCat.id,
        categoryName: stockCat.name,
        mode: 'upi',
        note: 'Weekly wholesale supply',
        countsAsCustomer: false,
        isSample: true,
        createdAt: ts,
        updatedAt: ts,
      });
    }

    // 3. Monthly Staff Salary on the 1st
    if (dayDate.getDate() === 1) {
      const salCat = catMap.get('Staff Salary') || categories[0];
      const ts = new Date(dayDate).setHours(18, 0, 0, 0);
      sampleTransactions.push({
        id: `sample_exp_sal_${d}`,
        type: 'cash_out',
        amountMinor: 1800000, // ₹18,000
        ts,
        dayKey,
        hour: 18,
        categoryId: salCat.id,
        categoryName: salCat.name,
        mode: 'upi',
        note: 'Counter staff salary',
        countsAsCustomer: false,
        isSample: true,
        createdAt: ts,
        updatedAt: ts,
      });
    }

    // 4. Monthly Light Bill around the 10th
    if (dayDate.getDate() === 10) {
      const lightCat = catMap.get('Light Bill') || categories[0];
      const ts = new Date(dayDate).setHours(12, 0, 0, 0);
      sampleTransactions.push({
        id: `sample_exp_light_${d}`,
        type: 'cash_out',
        amountMinor: Math.floor(1800 + Math.random() * 800) * 100,
        ts,
        dayKey,
        hour: 12,
        categoryId: lightCat.id,
        categoryName: lightCat.name,
        mode: 'upi',
        note: 'Electricity bill',
        countsAsCustomer: false,
        isSample: true,
        createdAt: ts,
        updatedAt: ts,
      });
    }
  }

  // Bulk put all transactions
  await db.transactions.bulkPut(sampleTransactions);

  // Compute rollups for all affected days
  for (const dayKey of affectedDayKeys) {
    await recomputeDailyRollup(dayKey);
  }
}

/**
 * Remove Sample Data
 */
export async function removeSampleData(): Promise<void> {
  const sampleTxs = await db.transactions.where('isSample').equals(1).toArray();
  const sampleIds = sampleTxs.map((t) => t.id);
  const dayKeys = new Set(sampleTxs.map((t) => t.dayKey));

  await db.transactions.bulkDelete(sampleIds);

  // Delete sample udhar customers
  await db.udharCustomers.bulkDelete(['sc_1', 'sc_2', 'sc_3']);

  for (const dk of dayKeys) {
    await recomputeDailyRollup(dk);
  }
}

/**
 * Erase All Data (Factory Reset)
 */
export async function eraseAllData(): Promise<void> {
  await db.transaction('rw', [db.transactions, db.dailyRollups, db.categories, db.udharCustomers, db.appState], async () => {
    await db.transactions.clear();
    await db.dailyRollups.clear();
    await db.categories.clear();
    await db.udharCustomers.clear();
    await db.appState.clear();
  });
}

/**
 * Export full backup as JSON
 */
export async function exportBackupJson(): Promise<string> {
  const profile = await getProfile();
  const settings = await getSettings();
  const categories = await db.categories.toArray();
  const transactions = await db.transactions.toArray();
  const udharCustomers = await db.udharCustomers.toArray();
  const dailyRollups = await db.dailyRollups.toArray();

  const backupData = {
    version: 1,
    exportedAt: Date.now(),
    profile,
    settings,
    categories,
    transactions,
    udharCustomers,
    dailyRollups,
  };

  return JSON.stringify(backupData, null, 2);
}

/**
 * Restore from JSON
 */
export async function restoreFromBackupJson(jsonString: string, mode: 'replace' | 'merge'): Promise<boolean> {
  try {
    const data = JSON.parse(jsonString);
    if (!data || !Array.isArray(data.transactions) || !Array.isArray(data.categories)) {
      throw new Error('Invalid backup format');
    }

    if (mode === 'replace') {
      await eraseAllData();
      if (data.profile) await saveProfile(data.profile);
      if (data.settings) await saveSettings(data.settings);
      if (data.categories?.length) await db.categories.bulkPut(data.categories);
      if (data.udharCustomers?.length) await db.udharCustomers.bulkPut(data.udharCustomers);
      if (data.transactions?.length) await db.transactions.bulkPut(data.transactions);
      if (data.dailyRollups?.length) await db.dailyRollups.bulkPut(data.dailyRollups);
    } else {
      // Merge
      if (data.categories?.length) await db.categories.bulkPut(data.categories);
      if (data.udharCustomers?.length) await db.udharCustomers.bulkPut(data.udharCustomers);
      if (data.transactions?.length) await db.transactions.bulkPut(data.transactions);
      // Recompute affected rollups
      const dayKeys = new Set<string>(data.transactions.map((t: any) => t.dayKey));
      for (const dk of dayKeys) {
        if (dk) await recomputeDailyRollup(dk);
      }
    }
    return true;
  } catch (err) {
    console.error('Failed to restore backup:', err);
    return false;
  }
}
